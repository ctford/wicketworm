This zip archive contains data files from Cricsheet in JSON format. This
archive contains 2546 matches of all types from 2025. A further 23 matches
have been withheld due to either featuring the Afghanistan men's team or being
played in the Afghanistan Premier League, due to the Cricsheet policy to no
longer feature matches involving Afghanistan men or played in Afghanistan
Premier League (see https://cricsheet.org/withheld-matches for more
information).


The JSON data files contained in this zip file are version 1.0.0, and 1.1.0
files. You can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/2025_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2025-12-31 - club - SSM - male - 1499633 - Wellington vs Northern Districts
2025-12-31 - club - SSM - female - 1499665 - Wellington vs Northern Districts
2025-12-31 - club - SAT - male - 1494260 - Pretoria Capitals vs MI Cape Town
2025-12-31 - club - SAT - male - 1494259 - Sunrisers Eastern Cape vs Paarl Royals
2025-12-31 - club - BBL - male - 1493254 - Brisbane Heat vs Adelaide Strikers
2025-12-30 - international - T20 - female - 1513739 - India vs Sri Lanka
2025-12-30 - club - SSM - male - 1499632 - Otago vs Central Districts
2025-12-30 - club - SSM - female - 1499664 - Central Districts vs Otago
2025-12-30 - club - SAT - male - 1494258 - Durban's Super Giants vs Joburg Super Kings
2025-12-30 - club - ILT - male - 1501348 - Desert Vipers vs MI Emirates
2025-12-30 - club - BBL - male - 1493253 - Perth Scorchers vs Sydney Thunder
2025-12-29 - international - T20 - male - 1515549 - Cambodia vs Indonesia
2025-12-29 - international - T20 - male - 1515014 - Bhutan vs Myanmar
2025-12-29 - club - SSM - male - 1499631 - Wellington vs Auckland
2025-12-29 - club - SSM - female - 1499663 - Wellington vs Auckland
2025-12-29 - club - SAT - male - 1494257 - Sunrisers Eastern Cape vs Pretoria Capitals
2025-12-29 - club - BPL - male - 1516542 - Noakhali Express vs Rajshahi Warriors
2025-12-29 - club - BPL - male - 1516541 - Chattogram Royals vs Rangpur Riders
2025-12-29 - club - BBL - male - 1493252 - Melbourne Renegades vs Hobart Hurricanes
2025-12-28 - international - T20 - female - 1513738 - India vs Sri Lanka
2025-12-28 - club - SSM - male - 1499630 - Canterbury vs Otago
2025-12-28 - club - SSM - female - 1499662 - Canterbury vs Otago
2025-12-28 - club - SAT - male - 1494256 - Durban's Super Giants vs MI Cape Town
2025-12-28 - club - ILT - male - 1501347 - Abu Dhabi Knight Riders vs Gulf Giants
2025-12-28 - club - BBL - male - 1493251 - Sydney Thunder vs Melbourne Stars
2025-12-27 - international - T20 - male - 1515548 - Cambodia vs Indonesia
2025-12-27 - international - T20 - male - 1515547 - Cambodia vs Indonesia
2025-12-27 - international - T20 - male - 1515013 - Bhutan vs Myanmar
2025-12-27 - club - SSM - male - 1499629 - Central Districts vs Wellington
2025-12-27 - club - SSM - female - 1499661 - Wellington vs Central Districts
2025-12-27 - club - SAT - male - 1494255 - Sunrisers Eastern Cape vs Paarl Royals
2025-12-27 - club - SAT - male - 1494254 - Joburg Super Kings vs Pretoria Capitals
2025-12-27 - club - MLT - male - 1511656 - Ace Capital Cricket Club vs Moors Sports Club
2025-12-27 - club - MLT - male - 1511655 - Badureliya Sports Club vs Burgher Recreation Club
2025-12-27 - club - MLT - male - 1511654 - Kurunegala Youth Cricket Club vs Nondescripts Cricket Club
2025-12-27 - club - MLT - male - 1511653 - Colombo Cricket Club vs Colts Cricket Club
2025-12-27 - club - MLT - male - 1511652 - Chilaw Marians Cricket Club vs Panadura Sports Club
2025-12-27 - club - MLT - male - 1511651 - Bloomfield Cricket and Athletic Club vs Nugegoda Sports Welfare Club
2025-12-27 - club - ILT - male - 1501346 - Dubai Capitals vs MI Emirates
2025-12-27 - club - BPL - male - 1516540 - Noakhali Express vs Sylhet Titans
2025-12-27 - club - BPL - male - 1516539 - Rajshahi Warriors vs Dhaka Capitals
2025-12-27 - club - BBL - male - 1493250 - Brisbane Heat vs Adelaide Strikers
2025-12-26 - international - Test - male - 1455614 - Australia vs England
2025-12-26 - international - T20 - male - 1517208 - Cambodia vs Indonesia
2025-12-26 - international - T20 - male - 1515546 - Cambodia vs Indonesia
2025-12-26 - international - T20 - male - 1515012 - Bhutan vs Myanmar
2025-12-26 - international - T20 - female - 1513737 - Sri Lanka vs India
2025-12-26 - club - SSM - male - 1499628 - Auckland vs Northern Districts
2025-12-26 - club - SSM - female - 1499660 - Auckland vs Northern Districts
2025-12-26 - club - SAT - male - 1494253 - Durban's Super Giants vs MI Cape Town
2025-12-26 - club - ILT - male - 1501345 - Sharjah Warriorz vs Desert Vipers
2025-12-26 - club - BPL - male - 1516538 - Chattogram Royals vs Noakhali Express
2025-12-26 - club - BPL - male - 1516537 - Sylhet Titans vs Rajshahi Warriors
2025-12-26 - club - BBL - male - 1493249 - Perth Scorchers vs Hobart Hurricanes
2025-12-26 - club - BBL - male - 1493248 - Sydney Sixers vs Melbourne Stars
2025-12-25 - international - T20 - male - 1515545 - Indonesia vs Cambodia
2025-12-24 - international - T20 - male - 1515544 - Cambodia vs Indonesia
2025-12-24 - international - T20 - male - 1515011 - Bhutan vs Myanmar
2025-12-24 - club - ILT - male - 1501344 - Sharjah Warriorz vs Dubai Capitals
2025-12-23 - international - T20 - male - 1515543 - Indonesia vs Cambodia
2025-12-23 - international - T20 - male - 1515542 - Indonesia vs Cambodia
2025-12-23 - international - T20 - male - 1515010 - Myanmar vs Bhutan
2025-12-23 - international - T20 - female - 1513736 - Sri Lanka vs India
2025-12-23 - club - ILT - male - 1501343 - Gulf Giants vs MI Emirates
2025-12-23 - club - BBL - male - 1493247 - Adelaide Strikers vs Melbourne Stars
2025-12-22 - club - ILT - male - 1501342 - Abu Dhabi Knight Riders vs Sharjah Warriorz
2025-12-22 - club - BBL - male - 1493246 - Sydney Thunder vs Brisbane Heat
2025-12-21 - international - T20 - female - 1513735 - Sri Lanka vs India
2025-12-21 - club - ILT - male - 1501341 - Desert Vipers vs MI Emirates
2025-12-21 - club - ILT - male - 1501340 - Gulf Giants vs Dubai Capitals
2025-12-21 - club - BBL - male - 1493245 - Melbourne Renegades vs Hobart Hurricanes
2025-12-20 - club - ILT - male - 1501339 - Sharjah Warriorz vs Desert Vipers
2025-12-20 - club - ILT - male - 1501338 - MI Emirates vs Abu Dhabi Knight Riders
2025-12-20 - club - BBL - male - 1493244 - Sydney Sixers vs Sydney Thunder
2025-12-19 - international - T20 - male - 1479580 - India vs South Africa
2025-12-19 - international - T20 - female - 1514529 - Oman vs United Arab Emirates
2025-12-19 - international - T20 - female - 1513764 - Malaysia vs Thailand
2025-12-19 - international - T20 - female - 1513763 - Myanmar vs Indonesia
2025-12-19 - international - ODI - female - 1477596 - Ireland vs South Africa
2025-12-19 - club - MLT - male - 1511650 - Badureliya Sports Club vs Kurunegala Youth Cricket Club
2025-12-19 - club - MLT - male - 1511649 - Tamil Union Cricket and Athletic Club vs Burgher Recreation Club
2025-12-19 - club - MLT - male - 1511648 - Nondescripts Cricket Club vs Moors Sports Club
2025-12-19 - club - MLT - male - 1511647 - Panadura Sports Club vs Nugegoda Sports Welfare Club
2025-12-19 - club - MLT - male - 1511646 - Police Sports Club vs Chilaw Marians Cricket Club
2025-12-19 - club - MLT - male - 1511645 - Bloomfield Cricket and Athletic Club vs Colts Cricket Club
2025-12-19 - club - ILT - male - 1501337 - Dubai Capitals vs Sharjah Warriorz
2025-12-19 - club - BBL - male - 1493243 - Perth Scorchers vs Brisbane Heat
2025-12-18 - international - Test - male - 1491734 - New Zealand vs West Indies
2025-12-18 - international - T20 - female - 1514528 - Qatar vs Oman
2025-12-18 - international - T20 - female - 1514527 - United Arab Emirates vs Bahrain
2025-12-18 - international - T20 - female - 1514526 - Saudi Arabia vs Kuwait
2025-12-18 - international - T20 - female - 1513762 - Malaysia vs Myanmar
2025-12-18 - international - T20 - female - 1513761 - Thailand vs Indonesia
2025-12-18 - club - ILT - male - 1501336 - Gulf Giants vs Abu Dhabi Knight Riders
2025-12-18 - club - BBL - male - 1493242 - Hobart Hurricanes vs Melbourne Stars
2025-12-17 - international - Test - male - 1455613 - Australia vs England
2025-12-17 - international - T20 - female - 1513760 - Myanmar vs Singapore
2025-12-17 - international - T20 - female - 1513759 - Philippines vs Malaysia
2025-12-17 - club - ILT - male - 1501335 - MI Emirates vs Dubai Capitals
2025-12-17 - club - BBL - male - 1493241 - Sydney Sixers vs Adelaide Strikers
2025-12-16 - international - T20 - female - 1514525 - Kuwait vs Oman
2025-12-16 - international - T20 - female - 1514524 - United Arab Emirates vs Saudi Arabia
2025-12-16 - international - T20 - female - 1514523 - Qatar vs Bahrain
2025-12-16 - international - T20 - female - 1513758 - Thailand vs Singapore
2025-12-16 - international - T20 - female - 1513757 - Indonesia vs Philippines
2025-12-16 - international - ODI - female - 1477595 - South Africa vs Ireland
2025-12-16 - club - ILT - male - 1501334 - Abu Dhabi Knight Riders vs Desert Vipers
2025-12-16 - club - BBL - male - 1493240 - Sydney Thunder vs Hobart Hurricanes
2025-12-15 - international - T20 - female - 1514522 - Kuwait vs United Arab Emirates
2025-12-15 - international - T20 - female - 1514521 - Saudi Arabia vs Qatar
2025-12-15 - international - T20 - female - 1514520 - Bahrain vs Oman
2025-12-15 - international - T20 - female - 1513756 - Malaysia vs Indonesia
2025-12-15 - international - T20 - female - 1513755 - Myanmar vs Thailand
2025-12-15 - club - ILT - male - 1501333 - Sharjah Warriorz vs Gulf Giants
2025-12-15 - club - BBL - male - 1493239 - Melbourne Renegades vs Brisbane Heat
2025-12-14 - international - T20 - male - 1513304 - Nigeria vs Rwanda
2025-12-14 - international - T20 - male - 1513303 - Zambia vs Sierra Leone
2025-12-14 - international - T20 - male - 1479578 - South Africa vs India
2025-12-14 - club - ILT - male - 1501332 - Dubai Capitals vs Desert Vipers
2025-12-14 - club - ILT - male - 1501331 - Sharjah Warriorz vs MI Emirates
2025-12-14 - club - BBL - male - 1493238 - Sydney Sixers vs Perth Scorchers
2025-12-13 - international - T20 - male - 1513833 - Singapore vs Malaysia
2025-12-13 - international - T20 - male - 1513832 - Thailand vs Philippines
2025-12-13 - international - T20 - male - 1513302 - Zambia vs Sierra Leone
2025-12-13 - international - T20 - male - 1513301 - Nigeria vs Rwanda
2025-12-13 - international - T20 - male - 1513102 - Bhutan vs Bahrain
2025-12-13 - international - T20 - female - 1514519 - Bahrain vs Kuwait
2025-12-13 - international - T20 - female - 1514518 - Oman vs Saudi Arabia
2025-12-13 - international - T20 - female - 1514517 - United Arab Emirates vs Qatar
2025-12-13 - international - ODI - female - 1477594 - Ireland vs South Africa
2025-12-13 - club - WBB - female - 1494568 - Perth Scorchers vs Hobart Hurricanes
2025-12-13 - club - PKS - male - 1499335 - Otago Volts vs Central Stags
2025-12-13 - club - PKS - male - 1499334 - Auckland Aces vs Canterbury
2025-12-13 - club - PKS - male - 1499333 - Wellington Firebirds vs Northern Districts
2025-12-13 - club - NPL - male - 1511008 - Sudur Paschim Royals vs Lumbini Lions
2025-12-13 - club - ILT - male - 1501330 - Dubai Capitals vs Abu Dhabi Knight Riders
2025-12-12 - international - T20 - male - 1513831 - Thailand vs Malaysia
2025-12-12 - international - T20 - male - 1513830 - Indonesia vs Singapore
2025-12-12 - international - T20 - male - 1513300 - Rwanda vs Sierra Leone
2025-12-12 - international - T20 - male - 1513299 - Nigeria vs Zambia
2025-12-12 - international - T20 - male - 1513101 - Bahrain vs Bhutan
2025-12-12 - international - T20 - female - 1514516 - Bahrain vs Saudi Arabia
2025-12-12 - international - T20 - female - 1514515 - Oman vs United Arab Emirates
2025-12-12 - international - T20 - female - 1514514 - Kuwait vs Qatar
2025-12-12 - club - MLT - male - 1511644 - Kurunegala Youth Cricket Club vs Burgher Recreation Club
2025-12-12 - club - MLT - male - 1511643 - Moors Sports Club vs Tamil Union Cricket and Athletic Club
2025-12-12 - club - MLT - male - 1511642 - Nondescripts Cricket Club vs Ace Capital Cricket Club
2025-12-12 - club - MLT - male - 1511641 - Chilaw Marians Cricket Club vs Nugegoda Sports Welfare Club
2025-12-12 - club - MLT - male - 1511640 - Police Sports Club vs Colts Cricket Club
2025-12-12 - club - MLT - male - 1511639 - Colombo Cricket Club vs Bloomfield Cricket and Athletic Club
2025-12-12 - club - ILT - male - 1501329 - Gulf Giants vs Desert Vipers
2025-12-11 - international - T20 - male - 1513829 - Philippines vs Indonesia
2025-12-11 - international - T20 - male - 1513828 - Singapore vs Thailand
2025-12-11 - international - T20 - male - 1513298 - Nigeria vs Sierra Leone
2025-12-11 - international - T20 - male - 1513100 - Bahrain vs Bhutan
2025-12-11 - international - T20 - male - 1513097 - Zambia vs Rwanda
2025-12-11 - international - T20 - male - 1479577 - South Africa vs India
2025-12-11 - club - WBB - female - 1494567 - Perth Scorchers vs Sydney Sixers
2025-12-11 - club - NPL - male - 1511007 - Lumbini Lions vs Biratnagar Kings
2025-12-11 - club - ILT - male - 1501328 - Abu Dhabi Knight Riders vs MI Emirates
2025-12-10 - international - Test - male - 1491733 - West Indies vs New Zealand
2025-12-10 - international - T20 - male - 1513827 - Philippines vs Singapore
2025-12-10 - international - T20 - male - 1513826 - Indonesia vs Malaysia
2025-12-10 - international - T20 - female - 1514513 - Oman vs Qatar
2025-12-10 - club - NPL - male - 1511006 - Kathmandu Gorkhas vs Lumbini Lions
2025-12-10 - club - ILT - male - 1501327 - Sharjah Warriorz vs Gulf Giants
2025-12-09 - international - T20 - male - 1513825 - Malaysia vs Philippines
2025-12-09 - international - T20 - male - 1513824 - Thailand vs Indonesia
2025-12-09 - international - T20 - male - 1513099 - Bahrain vs Bhutan
2025-12-09 - international - T20 - male - 1513096 - Sierra Leone vs Zambia
2025-12-09 - international - T20 - male - 1513095 - Rwanda vs Nigeria
2025-12-09 - international - T20 - male - 1479576 - India vs South Africa
2025-12-09 - club - WBB - female - 1494566 - Perth Scorchers vs Melbourne Stars
2025-12-09 - club - NPL - male - 1511005 - Sudur Paschim Royals vs Biratnagar Kings
2025-12-09 - club - ILT - male - 1501326 - Desert Vipers vs MI Emirates
2025-12-08 - international - T20 - male - 1513094 - Nigeria vs Zambia
2025-12-08 - international - T20 - male - 1513093 - Rwanda vs Sierra Leone
2025-12-08 - club - ILT - male - 1501325 - Gulf Giants vs Desert Vipers
2025-12-07 - international - T20 - male - 1514477 - Croatia vs Spain
2025-12-07 - international - T20 - male - 1514476 - Spain vs Croatia
2025-12-07 - international - T20 - male - 1513092 - Zambia vs Rwanda
2025-12-07 - international - T20 - male - 1513091 - Sierra Leone vs Nigeria
2025-12-07 - international - T20 - female - 1514511 - Oman vs Qatar
2025-12-07 - international - T20 - female - 1477592 - South Africa vs Ireland
2025-12-07 - club - WBB - female - 1494565 - Sydney Sixers vs Adelaide Strikers
2025-12-07 - club - NPL - male - 1511004 - Karnali Yaks vs Janakpur Bolts
2025-12-07 - club - ILT - male - 1501324 - Dubai Capitals vs Abu Dhabi Knight Riders
2025-12-07 - club - ILT - male - 1501323 - MI Emirates vs Sharjah Warriorz
2025-12-06 - international - T20 - male - 1514475 - Croatia vs Spain
2025-12-06 - international - T20 - male - 1514474 - Spain vs Croatia
2025-12-06 - international - T20 - male - 1513090 - Zambia vs Sierra Leone
2025-12-06 - international - T20 - male - 1513089 - Nigeria vs Rwanda
2025-12-06 - international - T20 - female - 1514510 - Bahrain vs Oman
2025-12-06 - international - ODI - male - 1479575 - South Africa vs India
2025-12-06 - club - WBB - female - 1494564 - Brisbane Heat vs Perth Scorchers
2025-12-06 - club - WBB - female - 1494563 - Melbourne Stars vs Sydney Thunder
2025-12-06 - club - NPL - male - 1511003 - Chitwan Rhinos vs Pokhara Avengers
2025-12-06 - club - NPL - male - 1511002 - Sudur Paschim Royals vs Biratnagar Kings
2025-12-06 - club - MLT - male - 1511638 - Tamil Union Cricket and Athletic Club vs Badureliya Sports Club
2025-12-06 - club - MLT - male - 1511637 - Ace Capital Cricket Club vs Kurunegala Youth Cricket Club
2025-12-06 - club - MLT - male - 1511636 - Moors Sports Club vs Burgher Recreation Club
2025-12-06 - club - MLT - male - 1511634 - Colombo Cricket Club vs Nugegoda Sports Welfare Club
2025-12-06 - club - MLT - male - 1511633 - Chilaw Marians Cricket Club vs Colts Cricket Club
2025-12-06 - club - ILT - male - 1501322 - Dubai Capitals vs Gulf Giants
2025-12-05 - international - T20 - male - 1514473 - Croatia vs Spain
2025-12-05 - international - T20 - male - 1513297 - Nigeria vs Sierra Leone
2025-12-05 - international - T20 - male - 1513088 - Zambia vs Rwanda
2025-12-05 - international - T20 - female - 1477591 - South Africa vs Ireland
2025-12-05 - club - WBB - female - 1494562 - Adelaide Strikers vs Hobart Hurricanes
2025-12-05 - club - WBB - female - 1494561 - Sydney Sixers vs Melbourne Renegades
2025-12-05 - club - SSH - male - 1495296 - Tasmania vs South Australia
2025-12-05 - club - SSH - male - 1495295 - New South Wales vs Queensland
2025-12-05 - club - PKS - male - 1499332 - Central Stags vs Canterbury
2025-12-05 - club - PKS - male - 1499331 - Northern Districts vs Otago Volts
2025-12-05 - club - PKS - male - 1499330 - Auckland Aces vs Wellington Firebirds
2025-12-05 - club - NPL - male - 1511001 - Janakpur Bolts vs Lumbini Lions
2025-12-05 - club - ILT - male - 1501321 - Abu Dhabi Knight Riders vs Desert Vipers
2025-12-04 - international - Test - male - 1455612 - England vs Australia
2025-12-04 - international - T20 - male - 1513087 - Sierra Leone vs Rwanda
2025-12-04 - international - T20 - male - 1513086 - Nigeria vs Zambia
2025-12-04 - club - SSH - male - 1495294 - Western Australia vs Victoria
2025-12-04 - club - NPL - male - 1511000 - Sudur Paschim Royals vs Chitwan Rhinos
2025-12-04 - club - NPL - male - 1510999 - Kathmandu Gorkhas vs Pokhara Avengers
2025-12-04 - club - ILT - male - 1501320 - MI Emirates vs Gulf Giants
2025-12-03 - international - ODI - male - 1479574 - India vs South Africa
2025-12-03 - club - WBB - female - 1494560 - Sydney Thunder vs Brisbane Heat
2025-12-03 - club - WBB - female - 1494559 - Sydney Sixers vs Melbourne Stars
2025-12-03 - club - NPL - male - 1510998 - Biratnagar Kings vs Lumbini Lions
2025-12-03 - club - ILT - male - 1501319 - Abu Dhabi Knight Riders vs Sharjah Warriorz
2025-12-02 - international - Test - male - 1491732 - New Zealand vs West Indies
2025-12-02 - international - T20 - male - 1506016 - Ireland vs Bangladesh
2025-12-02 - club - WBB - female - 1494558 - Perth Scorchers vs Melbourne Renegades
2025-12-02 - club - ODC - male - 1495324 - Victoria vs Western Australia
2025-12-02 - club - NPL - male - 1510997 - Pokhara Avengers vs Karnali Yaks
2025-12-02 - club - NPL - male - 1510996 - Chitwan Rhinos vs Janakpur Bolts
2025-12-02 - club - ILT - male - 1501318 - Dubai Capitals vs Desert Vipers
2025-12-01 - club - WBB - female - 1494557 - Hobart Hurricanes vs Melbourne Stars
2025-11-30 - international - T20 - male - 1512002 - Thailand vs Bahrain
2025-11-30 - international - T20 - male - 1511997 - Argentina vs Brazil
2025-11-30 - international - T20 - male - 1511996 - Argentina vs Brazil
2025-11-30 - international - T20 - female - 1510315 - Myanmar vs Singapore
2025-11-30 - international - T20 - female - 1510312 - Papua New Guinea vs Tanzania
2025-11-30 - international - T20 - female - 1510311 - Scotland vs Thailand
2025-11-30 - international - T20 - female - 1510310 - United Arab Emirates vs Namibia
2025-11-30 - international - T20 - female - 1510309 - Uganda vs Netherlands
2025-11-30 - international - ODI - male - 1479573 - India vs South Africa
2025-11-30 - club - WBB - female - 1494556 - Sydney Thunder vs Sydney Sixers
2025-11-30 - club - WBB - female - 1494555 - Brisbane Heat vs Adelaide Strikers
2025-11-30 - club - NPL - male - 1510995 - Karnali Yaks vs Kathmandu Gorkhas
2025-11-29 - international - T20 - male - 1511994 - Brazil vs Argentina
2025-11-29 - international - T20 - male - 1506015 - Ireland vs Bangladesh
2025-11-29 - international - T20 - male - 1502054 - Sri Lanka vs Pakistan
2025-11-29 - international - T20 - female - 1510314 - Singapore vs Myanmar
2025-11-29 - club - WBB - female - 1494554 - Perth Scorchers vs Hobart Hurricanes
2025-11-29 - club - WBB - female - 1494553 - Melbourne Stars vs Melbourne Renegades
2025-11-29 - club - NPL - male - 1510994 - Janakpur Bolts vs Sudur Paschim Royals
2025-11-29 - club - NPL - male - 1510993 - Pokhara Avengers vs Lumbini Lions
2025-11-28 - international - T20 - male - 1511993 - Brazil vs Argentina
2025-11-28 - international - T20 - female - 1510308 - Netherlands vs Scotland
2025-11-28 - international - T20 - female - 1510307 - Papua New Guinea vs Namibia
2025-11-28 - international - T20 - female - 1510306 - Tanzania vs Uganda
2025-11-28 - international - T20 - female - 1510305 - United Arab Emirates vs Thailand
2025-11-28 - club - WBB - female - 1494552 - Adelaide Strikers vs Sydney Thunder
2025-11-28 - club - NPL - male - 1510992 - Karnali Yaks vs Biratnagar Kings
2025-11-28 - club - NPL - male - 1510991 - Kathmandu Gorkhas vs Chitwan Rhinos
2025-11-27 - international - T20 - male - 1512000 - Thailand vs Bahrain
2025-11-27 - international - T20 - male - 1506014 - Ireland vs Bangladesh
2025-11-27 - international - T20 - male - 1502053 - Sri Lanka vs Pakistan
2025-11-27 - international - T20 - female - 1510313 - Singapore vs Myanmar
2025-11-27 - club - WBB - female - 1494550 - Melbourne Renegades vs Perth Scorchers
2025-11-27 - club - NPL - male - 1510990 - Pokhara Avengers vs Janakpur Bolts
2025-11-27 - club - NPL - male - 1510989 - Lumbini Lions vs Sudur Paschim Royals
2025-11-26 - international - T20 - female - 1510304 - Papua New Guinea vs Scotland
2025-11-26 - international - T20 - female - 1510303 - Netherlands vs Namibia
2025-11-26 - international - T20 - female - 1510302 - Uganda vs Thailand
2025-11-26 - international - T20 - female - 1510301 - Tanzania vs United Arab Emirates
2025-11-26 - club - WBB - female - 1494549 - Melbourne Stars vs Hobart Hurricanes
2025-11-26 - club - PKS - male - 1499329 - Canterbury vs Otago Volts
2025-11-26 - club - PKS - male - 1499328 - Wellington Firebirds vs Central Stags
2025-11-26 - club - PKS - male - 1499327 - Auckland Aces vs Northern Districts
2025-11-26 - club - NPL - male - 1510988 - Chitwan Rhinos vs Biratnagar Kings
2025-11-25 - international - T20 - male - 1511999 - Bahrain vs Malaysia
2025-11-25 - international - T20 - male - 1502052 - Zimbabwe vs Sri Lanka
2025-11-25 - international - T20 - female - 1510300 - Papua New Guinea vs Netherlands
2025-11-25 - international - T20 - female - 1510299 - Namibia vs Scotland
2025-11-25 - international - T20 - female - 1510298 - Uganda vs United Arab Emirates
2025-11-25 - international - T20 - female - 1510297 - Thailand vs Tanzania
2025-11-25 - club - WBB - female - 1494548 - Brisbane Heat vs Adelaide Strikers
2025-11-25 - club - NPL - male - 1510987 - Kathmandu Gorkhas vs Lumbini Lions
2025-11-24 - international - T20 - male - 1511998 - Thailand vs Malaysia
2025-11-24 - club - NPL - male - 1510986 - Sudur Paschim Royals vs Karnali Yaks
2025-11-24 - club - NPL - male - 1510985 - Biratnagar Kings vs Janakpur Bolts
2025-11-23 - international - T20 - male - 1502051 - Pakistan vs Zimbabwe
2025-11-23 - international - T20 - female - 1510296 - Thailand vs Namibia
2025-11-23 - international - T20 - female - 1510295 - United Arab Emirates vs Scotland
2025-11-23 - international - T20 - female - 1510294 - Uganda vs Papua New Guinea
2025-11-23 - international - T20 - female - 1510293 - Tanzania vs Netherlands
2025-11-23 - club - WBB - female - 1494547 - Melbourne Stars vs Brisbane Heat
2025-11-23 - club - WBB - female - 1494546 - Sydney Thunder vs Melbourne Renegades
2025-11-22 - international - Test - male - 1479572 - South Africa vs India
2025-11-22 - international - T20 - male - 1502050 - Sri Lanka vs Pakistan
2025-11-22 - international - ODI - male - 1491730 - West Indies vs New Zealand
2025-11-22 - club - WBB - female - 1494545 - Perth Scorchers vs Adelaide Strikers
2025-11-22 - club - WBB - female - 1494544 - Sydney Sixers vs Hobart Hurricanes
2025-11-22 - club - SSH - male - 1495293 - Western Australia vs South Australia
2025-11-22 - club - SSH - male - 1495292 - New South Wales vs Tasmania
2025-11-22 - club - SSH - male - 1495291 - Victoria vs Queensland
2025-11-22 - club - NPL - male - 1510984 - Kathmandu Gorkhas vs Biratnagar Kings
2025-11-22 - club - NPL - male - 1510983 - Lumbini Lions vs Karnali Yaks
2025-11-21 - international - Test - male - 1455611 - England vs Australia
2025-11-21 - international - T20 - male - 1510180 - Indonesia vs Bahrain
2025-11-21 - international - T20 - female - 1510292 - Scotland vs Tanzania
2025-11-21 - international - T20 - female - 1510291 - Namibia vs Uganda
2025-11-21 - international - T20 - female - 1510290 - Papua New Guinea vs Thailand
2025-11-21 - international - T20 - female - 1510289 - United Arab Emirates vs Netherlands
2025-11-21 - club - WBB - female - 1494543 - Sydney Thunder vs Brisbane Heat
2025-11-21 - club - NPL - male - 1510982 - Sudur Paschim Royals vs Pokhara Avengers
2025-11-20 - international - T20 - male - 1502049 - Zimbabwe vs Sri Lanka
2025-11-20 - international - T20 - female - 1510288 - Scotland vs Uganda
2025-11-20 - international - T20 - female - 1510287 - Namibia vs Tanzania
2025-11-20 - international - T20 - female - 1510286 - Papua New Guinea vs United Arab Emirates
2025-11-20 - international - T20 - female - 1510285 - Thailand vs Netherlands
2025-11-20 - club - WBB - female - 1494542 - Melbourne Stars vs Sydney Sixers
2025-11-20 - club - WBB - female - 1494541 - Melbourne Renegades vs Hobart Hurricanes
2025-11-20 - club - NPL - male - 1510981 - Chitwan Rhinos vs Lumbini Lions
2025-11-19 - international - Test - male - 1506013 - Bangladesh vs Ireland
2025-11-19 - international - T20 - male - 1510179 - Bahrain vs Indonesia
2025-11-19 - international - ODI - male - 1491729 - West Indies vs New Zealand
2025-11-19 - club - WBB - female - 1494540 - Perth Scorchers vs Sydney Thunder
2025-11-19 - club - NPL - male - 1510980 - Sudur Paschim Royals vs Kathmandu Gorkhas
2025-11-18 - international - T20 - male - 1510178 - Bahrain vs Indonesia
2025-11-18 - international - T20 - male - 1502048 - Zimbabwe vs Pakistan
2025-11-18 - club - WBB - female - 1494539 - Adelaide Strikers vs Hobart Hurricanes
2025-11-18 - club - PKS - male - 1499326 - Northern Districts vs Canterbury
2025-11-18 - club - PKS - male - 1499325 - Otago Volts vs Wellington Firebirds
2025-11-18 - club - PKS - male - 1499324 - Auckland Aces vs Central Stags
2025-11-18 - club - NPL - male - 1510979 - Biratnagar Kings vs Pokhara Avengers
2025-11-18 - club - NPL - male - 1510978 - Karnali Yaks vs Chitwan Rhinos
2025-11-17 - international - T20 - female - 1510284 - Papua New Guinea vs Thailand
2025-11-17 - international - T20 - female - 1510283 - Namibia vs Scotland
2025-11-17 - club - NPL - male - 1510977 - Janakpur Bolts vs Kathmandu Gorkhas
2025-11-16 - international - T20 - male - 1509859 - United Arab Emirates vs Oman
2025-11-16 - international - ODI - male - 1502169 - Sri Lanka vs Pakistan
2025-11-16 - international - ODI - male - 1491728 - New Zealand vs West Indies
2025-11-16 - club - WBB - female - 1494538 - Melbourne Stars vs Melbourne Renegades
2025-11-16 - club - WBB - female - 1494537 - Adelaide Strikers vs Perth Scorchers
2025-11-15 - international - T20 - female - 1510282 - Thailand vs Scotland
2025-11-15 - international - T20 - female - 1510281 - Namibia vs Papua New Guinea
2025-11-15 - club - WBB - female - 1494536 - Sydney Sixers vs Sydney Thunder
2025-11-15 - club - WBB - female - 1494535 - Hobart Hurricanes vs Brisbane Heat
2025-11-15 - club - ODC - male - 1495323 - South Australia vs Tasmania
2025-11-14 - international - Test - male - 1479571 - South Africa vs India
2025-11-14 - international - T20 - male - 1508280 - Myanmar vs Timor-Leste
2025-11-14 - international - T20 - female - 1510280 - Thailand vs Namibia
2025-11-14 - international - T20 - female - 1510279 - Scotland vs Papua New Guinea
2025-11-14 - international - ODI - male - 1502168 - Sri Lanka vs Pakistan
2025-11-14 - club - WBB - female - 1494534 - Melbourne Renegades vs Adelaide Strikers
2025-11-14 - club - WBB - female - 1494533 - Melbourne Stars vs Perth Scorchers
2025-11-13 - international - T20 - male - 1510725 - Hong Kong vs Qatar
2025-11-13 - international - T20 - male - 1508279 - Myanmar vs Indonesia
2025-11-13 - international - T20 - male - 1508278 - Timor-Leste vs Indonesia
2025-11-13 - international - T20 - male - 1491727 - West Indies vs New Zealand
2025-11-13 - club - WBB - female - 1494532 - Sydney Sixers vs Hobart Hurricanes
2025-11-12 - international - T20 - male - 1510724 - Qatar vs Hong Kong
2025-11-12 - international - T20 - male - 1508277 - Myanmar vs Timor-Leste
2025-11-12 - club - WBB - female - 1494531 - Perth Scorchers vs Brisbane Heat
2025-11-11 - international - Test - male - 1506012 - Ireland vs Bangladesh
2025-11-11 - international - T20 - male - 1508276 - Timor-Leste vs Indonesia
2025-11-11 - international - T20 - male - 1508275 - Myanmar vs Indonesia
2025-11-11 - international - ODI - male - 1502167 - Pakistan vs Sri Lanka
2025-11-11 - club - WBB - female - 1494530 - Sydney Thunder vs Melbourne Renegades
2025-11-11 - club - SSH - male - 1495290 - Queensland vs Western Australia
2025-11-10 - international - T20 - male - 1491726 - West Indies vs New Zealand
2025-11-10 - club - WBB - female - 1494529 - Melbourne Stars vs Adelaide Strikers
2025-11-10 - club - SSH - male - 1495289 - Tasmania vs South Australia
2025-11-10 - club - SSH - male - 1495288 - Victoria vs New South Wales
2025-11-09 - international - T20 - male - 1508274 - Timor-Leste vs Myanmar
2025-11-09 - international - T20 - male - 1491725 - New Zealand vs West Indies
2025-11-09 - club - WBB - female - 1494528 - Perth Scorchers vs Sydney Sixers
2025-11-09 - club - WBB - female - 1494527 - Sydney Thunder vs Hobart Hurricanes
2025-11-09 - club - WBB - female - 1494526 - Brisbane Heat vs Melbourne Renegades
2025-11-08 - international - T20 - male - 1508273 - Indonesia vs Myanmar
2025-11-08 - international - T20 - male - 1508272 - Timor-Leste vs Indonesia
2025-11-08 - international - T20 - male - 1478911 - India vs Australia
2025-11-08 - international - ODI - male - 1501900 - South Africa vs Pakistan
2025-11-07 - international - T20 - male - 1508271 - Timor-Leste vs Myanmar
2025-11-06 - international - T20 - male - 1508270 - Timor-Leste vs Indonesia
2025-11-06 - international - T20 - male - 1508269 - Myanmar vs Indonesia
2025-11-06 - international - T20 - male - 1491724 - New Zealand vs West Indies
2025-11-06 - international - T20 - male - 1478910 - India vs Australia
2025-11-06 - international - ODI - male - 1501899 - Pakistan vs South Africa
2025-11-05 - international - T20 - male - 1491723 - West Indies vs New Zealand
2025-11-05 - international - T20 - female - 1506671 - Canada vs Tanzania
2025-11-05 - international - T20 - female - 1506670 - Tanzania vs Canada
2025-11-05 - international - ODI - male - 1507889 - Nepal vs United Arab Emirates
2025-11-04 - international - T20 - female - 1506669 - Canada vs Tanzania
2025-11-04 - international - ODI - male - 1501898 - South Africa vs Pakistan
2025-11-03 - international - T20 - male - 1506447 - Bulgaria vs Cyprus
2025-11-03 - international - T20 - male - 1506446 - Bulgaria vs Cyprus
2025-11-03 - international - ODI - male - 1507888 - United States of America vs United Arab Emirates
2025-11-03 - club - ODC - male - 1495322 - Queensland vs New South Wales
2025-11-02 - international - T20 - male - 1506445 - Cyprus vs Bulgaria
2025-11-02 - international - T20 - male - 1506444 - Bulgaria vs Cyprus
2025-11-02 - international - T20 - male - 1478909 - Australia vs India
2025-11-02 - international - ODI - female - 1490443 - India vs South Africa
2025-11-01 - international - T20 - male - 1506443 - Bulgaria vs Serbia
2025-11-01 - international - T20 - male - 1506442 - Serbia vs Bulgaria
2025-11-01 - international - T20 - male - 1501897 - South Africa vs Pakistan
2025-11-01 - international - ODI - male - 1507887 - Nepal vs United States of America
2025-11-01 - international - ODI - male - 1491722 - England vs New Zealand
2025-10-31 - international - T20 - male - 1506441 - Cyprus vs Serbia
2025-10-31 - international - T20 - male - 1506440 - Cyprus vs Serbia
2025-10-31 - international - T20 - male - 1505127 - Bangladesh vs West Indies
2025-10-31 - international - T20 - male - 1501896 - South Africa vs Pakistan
2025-10-31 - international - T20 - male - 1478908 - India vs Australia
2025-10-30 - international - T20 - male - 1507418 - Panama vs Mexico
2025-10-30 - international - ODI - male - 1507886 - Nepal vs United Arab Emirates
2025-10-30 - international - ODI - female - 1490442 - Australia vs India
2025-10-29 - international - T20 - male - 1505126 - West Indies vs Bangladesh
2025-10-29 - international - T20 - male - 1478907 - India vs Australia
2025-10-29 - international - ODI - male - 1491721 - England vs New Zealand
2025-10-29 - international - ODI - female - 1490441 - South Africa vs England
2025-10-28 - international - T20 - male - 1501895 - South Africa vs Pakistan
2025-10-28 - international - ODI - male - 1507885 - United Arab Emirates vs United States of America
2025-10-28 - club - SSH - male - 1495287 - South Australia vs Western Australia
2025-10-28 - club - SSH - male - 1495286 - Victoria vs Tasmania
2025-10-28 - club - SSH - male - 1495285 - New South Wales vs Queensland
2025-10-27 - international - T20 - male - 1505125 - West Indies vs Bangladesh
2025-10-26 - international - T20 - female - 1506668 - Uganda vs Canada
2025-10-26 - international - ODI - male - 1507884 - United States of America vs Nepal
2025-10-26 - international - ODI - male - 1491720 - England vs New Zealand
2025-10-26 - international - ODI - female - 1490440 - Bangladesh vs India
2025-10-26 - international - ODI - female - 1490439 - New Zealand vs England
2025-10-25 - international - ODI - male - 1478906 - Australia vs India
2025-10-25 - international - ODI - female - 1490438 - South Africa vs Australia
2025-10-24 - international - T20 - female - 1506667 - Uganda vs Canada
2025-10-24 - international - ODI - female - 1490437 - Pakistan vs Sri Lanka
2025-10-23 - international - T20 - male - 1491719 - New Zealand vs England
2025-10-23 - international - T20 - female - 1506666 - Uganda vs Canada
2025-10-23 - international - ODI - male - 1505124 - Bangladesh vs West Indies
2025-10-23 - international - ODI - male - 1478905 - India vs Australia
2025-10-23 - international - ODI - female - 1490436 - India vs New Zealand
2025-10-22 - international - ODI - female - 1490435 - England vs Australia
2025-10-21 - international - T20 - female - 1506665 - Canada vs Uganda
2025-10-21 - international - ODI - male - 1505123 - Bangladesh vs West Indies
2025-10-21 - international - ODI - female - 1490434 - South Africa vs Pakistan
2025-10-20 - international - Test - male - 1501894 - Pakistan vs South Africa
2025-10-20 - international - T20 - male - 1491718 - England vs New Zealand
2025-10-20 - international - T20 - female - 1506664 - Canada vs Uganda
2025-10-20 - international - ODI - female - 1490433 - Sri Lanka vs Bangladesh
2025-10-20 - club - ODC - male - 1495321 - Queensland vs South Australia
2025-10-20 - club - ODC - male - 1495320 - Western Australia vs Tasmania
2025-10-20 - club - ODC - male - 1495319 - Victoria vs New South Wales
2025-10-19 - international - T20 - male - 1506439 - Austria vs Romania
2025-10-19 - international - T20 - male - 1506438 - Romania vs Austria
2025-10-19 - international - ODI - male - 1478904 - India vs Australia
2025-10-19 - international - ODI - female - 1506453 - Papua New Guinea vs United Arab Emirates
2025-10-19 - international - ODI - female - 1490432 - England vs India
2025-10-18 - international - T20 - male - 1506437 - Austria vs Romania
2025-10-18 - international - T20 - male - 1506436 - Romania vs Austria
2025-10-18 - international - T20 - male - 1491717 - England vs New Zealand
2025-10-18 - international - ODI - male - 1505122 - Bangladesh vs West Indies
2025-10-18 - international - ODI - female - 1490431 - Pakistan vs New Zealand
2025-10-17 - international - T20 - male - 1503470 - Nepal vs Samoa
2025-10-17 - international - T20 - male - 1503469 - Japan vs Oman
2025-10-17 - international - ODI - female - 1506452 - United Arab Emirates vs Papua New Guinea
2025-10-17 - international - ODI - female - 1490430 - Sri Lanka vs South Africa
2025-10-16 - international - T20 - male - 1503468 - Samoa vs Qatar
2025-10-16 - international - T20 - male - 1503467 - Japan vs United Arab Emirates
2025-10-16 - international - ODI - female - 1490429 - Bangladesh vs Australia
2025-10-15 - international - T20 - male - 1503466 - Nepal vs Oman
2025-10-15 - international - T20 - male - 1503465 - United Arab Emirates vs Samoa
2025-10-15 - international - T20 - male - 1503464 - Japan vs Qatar
2025-10-15 - international - ODI - female - 1506451 - United Arab Emirates vs Papua New Guinea
2025-10-15 - international - ODI - female - 1490428 - England vs Pakistan
2025-10-15 - club - SSH - male - 1495284 - South Australia vs Queensland
2025-10-15 - club - SSH - male - 1495283 - Tasmania vs Western Australia
2025-10-15 - club - SSH - male - 1495282 - Victoria vs New South Wales
2025-10-14 - international - ODI - female - 1490427 - Sri Lanka vs New Zealand
2025-10-13 - international - T20 - male - 1503463 - Nepal vs Qatar
2025-10-13 - international - T20 - male - 1503462 - United Arab Emirates vs Oman
2025-10-13 - international - ODI - female - 1506450 - Papua New Guinea vs United Arab Emirates
2025-10-13 - international - ODI - female - 1490426 - Bangladesh vs South Africa
2025-10-12 - international - Test - male - 1501893 - Pakistan vs South Africa
2025-10-12 - international - T20 - male - 1503461 - Japan vs Samoa
2025-10-12 - international - T20 - male - 1503460 - Nepal vs United Arab Emirates
2025-10-12 - international - T20 - male - 1503459 - Oman vs Qatar
2025-10-12 - international - T20 - female - 1506190 - Norway vs Bulgaria
2025-10-12 - international - T20 - female - 1506189 - Austria vs Norway
2025-10-12 - international - ODI - female - 1490425 - India vs Australia
2025-10-11 - international - T20 - male - 1487824 - South Africa vs Namibia
2025-10-11 - international - T20 - female - 1506188 - Norway vs Romania
2025-10-11 - international - T20 - female - 1506187 - Bulgaria vs Austria
2025-10-11 - international - T20 - female - 1506186 - Norway vs Turkey
2025-10-11 - international - ODI - female - 1490424 - England vs Sri Lanka
2025-10-10 - international - Test - male - 1479570 - India vs West Indies
2025-10-10 - international - T20 - male - 1503458 - Oman vs Papua New Guinea
2025-10-10 - international - T20 - male - 1503457 - Japan vs Nepal
2025-10-10 - international - T20 - male - 1503456 - Malaysia vs United Arab Emirates
2025-10-10 - international - T20 - female - 1506185 - Romania vs Bulgaria
2025-10-10 - international - T20 - female - 1506184 - Romania vs Turkey
2025-10-10 - international - T20 - female - 1506183 - Austria vs Turkey
2025-10-10 - international - ODI - female - 1490423 - New Zealand vs Bangladesh
2025-10-09 - international - T20 - male - 1503455 - Papua New Guinea vs Samoa
2025-10-09 - international - T20 - male - 1503454 - Kuwait vs Japan
2025-10-09 - international - T20 - male - 1503453 - Malaysia vs Qatar
2025-10-09 - international - T20 - female - 1506182 - Turkey vs Bulgaria
2025-10-09 - international - T20 - female - 1506181 - Romania vs Austria
2025-10-09 - international - ODI - female - 1490422 - India vs South Africa
2025-10-09 - club - ODC - male - 1495318 - New South Wales vs Western Australia
2025-10-09 - club - ODC - male - 1495317 - South Australia vs Victoria
2025-10-09 - club - ODC - male - 1495316 - Queensland vs Tasmania
2025-10-08 - international - T20 - male - 1503452 - Nepal vs Kuwait
2025-10-08 - international - T20 - male - 1503451 - Qatar vs United Arab Emirates
2025-10-08 - international - T20 - male - 1503450 - Samoa vs Oman
2025-10-08 - international - T20 - female - 1505118 - Malaysia vs Nepal
2025-10-08 - international - ODI - female - 1490421 - Australia vs Pakistan
2025-10-07 - international - T20 - female - 1505117 - Malaysia vs Nepal
2025-10-07 - international - ODI - female - 1490420 - Bangladesh vs England
2025-10-06 - international - T20 - female - 1503566 - United Arab Emirates vs Zimbabwe
2025-10-06 - international - ODI - female - 1490419 - New Zealand vs South Africa
2025-10-05 - international - T20 - female - 1505116 - Malaysia vs Nepal
2025-10-05 - international - T20 - female - 1503565 - United Arab Emirates vs Zimbabwe
2025-10-05 - international - ODI - female - 1490418 - India vs Pakistan
2025-10-04 - international - T20 - male - 1502762 - Namibia vs Zimbabwe
2025-10-04 - international - T20 - male - 1502761 - Uganda vs Nigeria
2025-10-04 - international - T20 - male - 1502760 - Malawi vs Botswana
2025-10-04 - international - T20 - male - 1502759 - Kenya vs Tanzania
2025-10-04 - international - T20 - male - 1491716 - New Zealand vs Australia
2025-10-04 - international - T20 - female - 1505115 - Malaysia vs Nepal
2025-10-04 - club - SSH - male - 1495281 - New South Wales vs Western Australia
2025-10-04 - club - SSH - male - 1495280 - South Australia vs Victoria
2025-10-04 - club - SSH - male - 1495279 - Tasmania vs Queensland
2025-10-03 - international - T20 - male - 1491715 - Australia vs New Zealand
2025-10-03 - international - ODI - female - 1490416 - South Africa vs England
2025-10-02 - international - Test - male - 1479569 - West Indies vs India
2025-10-02 - international - T20 - male - 1502758 - Uganda vs Malawi
2025-10-02 - international - T20 - male - 1502757 - Kenya vs Zimbabwe
2025-10-02 - international - T20 - male - 1502756 - Nigeria vs Botswana
2025-10-02 - international - T20 - male - 1502755 - Namibia vs Tanzania
2025-10-02 - international - T20 - female - 1505114 - Malaysia vs Nepal
2025-10-02 - international - ODI - female - 1503564 - United Arab Emirates vs Zimbabwe
2025-10-02 - international - ODI - female - 1490415 - Pakistan vs Bangladesh
2025-10-01 - international - T20 - male - 1491714 - New Zealand vs Australia
2025-10-01 - international - ODI - female - 1490414 - Australia vs New Zealand
2025-09-30 - international - T20 - male - 1502754 - Nigeria vs Kenya
2025-09-30 - international - T20 - male - 1502753 - Malawi vs Namibia
2025-09-30 - international - T20 - male - 1502752 - Botswana vs Uganda
2025-09-30 - international - T20 - male - 1502751 - Zimbabwe vs Tanzania
2025-09-30 - international - T20 - male - 1489970 - Nepal vs West Indies
2025-09-30 - international - ODI - female - 1503563 - Zimbabwe vs United Arab Emirates
2025-09-30 - international - ODI - female - 1490413 - India vs Sri Lanka
2025-09-29 - international - T20 - male - 1504941 - Kuwait vs Oman
2025-09-29 - international - T20 - male - 1489969 - Nepal vs West Indies
2025-09-28 - international - T20 - male - 1502750 - Malawi vs Kenya
2025-09-28 - international - T20 - male - 1502749 - Zimbabwe vs Botswana
2025-09-28 - international - T20 - male - 1502748 - Tanzania vs Uganda
2025-09-28 - international - T20 - male - 1502747 - Namibia vs Nigeria
2025-09-28 - international - T20 - male - 1496938 - Pakistan vs India
2025-09-28 - international - ODI - female - 1503562 - United Arab Emirates vs Zimbabwe
2025-09-27 - international - T20 - male - 1489968 - Nepal vs West Indies
2025-09-26 - international - T20 - male - 1502746 - Botswana vs Tanzania
2025-09-26 - international - T20 - male - 1502745 - Uganda vs Zimbabwe
2025-09-26 - international - T20 - male - 1502744 - Malawi vs Nigeria
2025-09-26 - international - T20 - male - 1502743 - Namibia vs Kenya
2025-09-26 - international - T20 - male - 1496937 - India vs Sri Lanka
2025-09-26 - international - ODI - female - 1503561 - United Arab Emirates vs Zimbabwe
2025-09-25 - international - T20 - male - 1496936 - Pakistan vs Bangladesh
2025-09-24 - international - T20 - male - 1496935 - India vs Bangladesh
2025-09-24 - club - ODC - male - 1495315 - Western Australia vs South Australia
2025-09-24 - club - CCH - male - 1461949 - Glamorgan vs Lancashire
2025-09-24 - club - CCH - male - 1461948 - Middlesex vs Gloucestershire
2025-09-24 - club - CCH - male - 1461947 - Derbyshire vs Kent
2025-09-24 - club - CCH - male - 1461946 - Leicestershire vs Northamptonshire
2025-09-24 - club - CCH - male - 1461893 - Durham vs Yorkshire
2025-09-24 - club - CCH - male - 1461892 - Worcestershire vs Sussex
2025-09-24 - club - CCH - male - 1461891 - Surrey vs Hampshire
2025-09-24 - club - CCH - male - 1461890 - Warwickshire vs Nottinghamshire
2025-09-24 - club - CCH - male - 1461889 - Somerset vs Essex
2025-09-23 - international - T20 - male - 1496934 - Sri Lanka vs Pakistan
2025-09-22 - international - ODI - female - 1500389 - South Africa vs Pakistan
2025-09-21 - international - T20 - male - 1496933 - Pakistan vs India
2025-09-21 - international - T20 - male - 1448362 - Ireland vs England
2025-09-21 - club - WOD - female - 1462401 - Hampshire vs Lancashire
2025-09-21 - club - ODC - male - 1495314 - Western Australia vs Queensland
2025-09-21 - club - CPL - male - 1478005 - Guyana Amazon Warriors vs Trinbago Knight Riders
2025-09-20 - international - T20 - male - 1496932 - Sri Lanka vs Bangladesh
2025-09-20 - international - ODI - female - 1488250 - Australia vs India
2025-09-20 - club - RLC - male - 1462032 - Hampshire vs Worcestershire
2025-09-20 - club - ODC - male - 1495313 - New South Wales vs South Australia
2025-09-19 - international - T20 - male - 1496931 - India vs Oman
2025-09-19 - international - ODI - female - 1500388 - South Africa vs Pakistan
2025-09-19 - club - ODC - male - 1495312 - Tasmania vs Victoria
2025-09-19 - club - CPL - male - 1478004 - Trinbago Knight Riders vs St Lucia Kings
2025-09-18 - international - T20 - male - 1502166 - Namibia vs Zimbabwe
2025-09-17 - international - T20 - male - 1496929 - Pakistan vs United Arab Emirates
2025-09-17 - international - T20 - male - 1448360 - Ireland vs England
2025-09-17 - international - ODI - female - 1488249 - India vs Australia
2025-09-17 - club - WOD - female - 1462400 - Surrey vs Hampshire
2025-09-17 - club - WOD - female - 1462399 - Lancashire vs The Blaze
2025-09-17 - club - WCL - female - 1489958 - Guyana Amazon Warriors vs Barbados Royals
2025-09-17 - club - ODC - male - 1495311 - Queensland vs Victoria
2025-09-17 - club - CPL - male - 1478003 - Guyana Amazon Warriors vs St Lucia Kings
2025-09-16 - international - T20 - male - 1502165 - Namibia vs Zimbabwe
2025-09-16 - international - ODI - female - 1500387 - Pakistan vs South Africa
2025-09-16 - club - WCL - female - 1489957 - Trinbago Knight Riders vs Barbados Royals
2025-09-16 - club - ODC - male - 1495310 - New South Wales vs Tasmania
2025-09-16 - club - CPL - male - 1478002 - Antigua and Barbuda Falcons vs Trinbago Knight Riders
2025-09-15 - international - T20 - male - 1502164 - Zimbabwe vs Namibia
2025-09-15 - international - T20 - male - 1496927 - Hong Kong vs Sri Lanka
2025-09-15 - international - T20 - male - 1496926 - United Arab Emirates vs Oman
2025-09-15 - international - T20 - female - 1499803 - Vanuatu vs Papua New Guinea
2025-09-15 - international - T20 - female - 1499802 - Japan vs Indonesia
2025-09-15 - international - T20 - female - 1499801 - Cook Islands vs Philippines
2025-09-15 - international - T20 - female - 1499800 - Samoa vs Fiji
2025-09-15 - club - CCH - male - 1461945 - Glamorgan vs Derbyshire
2025-09-15 - club - CCH - male - 1461944 - Northamptonshire vs Gloucestershire
2025-09-15 - club - CCH - male - 1461943 - Middlesex vs Lancashire
2025-09-15 - club - CCH - male - 1461942 - Leicestershire vs Kent
2025-09-15 - club - CCH - male - 1461888 - Somerset vs Hampshire
2025-09-15 - club - CCH - male - 1461887 - Nottinghamshire vs Surrey
2025-09-15 - club - CCH - male - 1461886 - Yorkshire vs Sussex
2025-09-15 - club - CCH - male - 1461885 - Worcestershire vs Durham
2025-09-15 - club - CCH - male - 1461884 - Essex vs Warwickshire
2025-09-14 - international - T20 - male - 1501506 - Eswatini vs Mozambique
2025-09-14 - international - T20 - male - 1496925 - Pakistan vs India
2025-09-14 - international - T20 - female - 1500868 - Luxembourg vs Switzerland
2025-09-14 - international - T20 - female - 1500867 - Austria vs Luxembourg
2025-09-14 - international - ODI - female - 1488248 - India vs Australia
2025-09-14 - club - WCL - female - 1489956 - Barbados Royals vs Guyana Amazon Warriors
2025-09-14 - club - CPL - male - 1478001 - Guyana Amazon Warriors vs Barbados Royals
2025-09-13 - international - T20 - male - 1501505 - Eswatini vs Mozambique
2025-09-13 - international - T20 - male - 1501504 - Eswatini vs Mozambique
2025-09-13 - international - T20 - male - 1496924 - Bangladesh vs Sri Lanka
2025-09-13 - international - T20 - female - 1500866 - Austria vs Switzerland
2025-09-13 - international - T20 - female - 1499799 - Vanuatu vs Japan
2025-09-13 - international - T20 - female - 1499798 - Indonesia vs Papua New Guinea
2025-09-13 - international - T20 - female - 1499797 - Philippines vs Fiji
2025-09-13 - international - T20 - female - 1499796 - Samoa vs Cook Islands
2025-09-13 - club - WOD - female - 1462398 - Warwickshire vs Somerset
2025-09-13 - club - WOD - female - 1462396 - Essex vs The Blaze
2025-09-13 - club - WOD - female - 1462395 - Surrey vs Durham
2025-09-13 - club - WCL - female - 1489955 - Trinbago Knight Riders vs Guyana Amazon Warriors
2025-09-13 - club - NTB - male - 1460886 - Hampshire vs Somerset
2025-09-13 - club - NTB - male - 1460885 - Northamptonshire vs Hampshire
2025-09-13 - club - NTB - male - 1460884 - Somerset vs Lancashire
2025-09-13 - club - CPL - male - 1478000 - St Lucia Kings vs Guyana Amazon Warriors
2025-09-12 - international - T20 - male - 1501503 - Eswatini vs Mozambique
2025-09-12 - international - T20 - male - 1501502 - Eswatini vs Mozambique
2025-09-12 - international - T20 - male - 1496923 - Pakistan vs Oman
2025-09-12 - international - T20 - male - 1448358 - England vs South Africa
2025-09-12 - international - T20 - female - 1500864 - Switzerland vs Luxembourg
2025-09-12 - international - T20 - female - 1499795 - Samoa vs Papua New Guinea
2025-09-12 - international - T20 - female - 1499794 - Vanuatu vs Fiji
2025-09-12 - international - T20 - female - 1499792 - Indonesia vs Cook Islands
2025-09-12 - club - CPL - male - 1477999 - Trinbago Knight Riders vs Barbados Royals
2025-09-11 - international - T20 - male - 1496922 - Hong Kong vs Bangladesh
2025-09-11 - club - CPL - male - 1477998 - St Kitts and Nevis Patriots vs Barbados Royals
2025-09-10 - international - T20 - male - 1496921 - United Arab Emirates vs India
2025-09-10 - international - T20 - male - 1448357 - South Africa vs England
2025-09-10 - international - T20 - female - 1499791 - Cook Islands vs Vanuatu
2025-09-10 - international - T20 - female - 1499790 - Papua New Guinea vs Philippines
2025-09-10 - international - T20 - female - 1499789 - Indonesia vs Fiji
2025-09-10 - international - T20 - female - 1499788 - Japan vs Samoa
2025-09-10 - club - WOD - female - 1462393 - Surrey vs Essex
2025-09-10 - club - WOD - female - 1462392 - Warwickshire vs Lancashire
2025-09-10 - club - WCL - female - 1489954 - Barbados Royals vs Trinbago Knight Riders
2025-09-10 - club - CPL - male - 1477997 - Guyana Amazon Warriors vs Antigua and Barbuda Falcons
2025-09-09 - international - T20 - female - 1499787 - Philippines vs Samoa
2025-09-09 - international - T20 - female - 1499786 - Vanuatu vs Indonesia
2025-09-09 - international - T20 - female - 1499785 - Papua New Guinea vs Japan
2025-09-09 - international - T20 - female - 1499784 - Cook Islands vs Fiji
2025-09-09 - club - WOD - female - 1462394 - Durham vs The Blaze
2025-09-08 - club - CCH - male - 1461941 - Kent vs Lancashire
2025-09-08 - club - CCH - male - 1461940 - Glamorgan vs Northamptonshire
2025-09-08 - club - CCH - male - 1461939 - Derbyshire vs Middlesex
2025-09-08 - club - CCH - male - 1461938 - Gloucestershire vs Leicestershire
2025-09-08 - club - CCH - male - 1461883 - Worcestershire vs Nottinghamshire
2025-09-08 - club - CCH - male - 1461882 - Hampshire vs Sussex
2025-09-08 - club - CCH - male - 1461881 - Surrey vs Warwickshire
2025-09-08 - club - CCH - male - 1461880 - Somerset vs Yorkshire
2025-09-08 - club - CCH - male - 1461879 - Durham vs Essex
2025-09-07 - international - T20 - male - 1492825 - Zimbabwe vs Sri Lanka
2025-09-07 - international - T20 - female - 1499783 - Czech Republic vs Estonia
2025-09-07 - international - ODI - male - 1448356 - England vs South Africa
2025-09-07 - club - WOD - female - 1462390 - Essex vs Warwickshire
2025-09-07 - club - WOD - female - 1462389 - Surrey vs Lancashire
2025-09-07 - club - WOD - female - 1462388 - The Blaze vs Somerset
2025-09-07 - club - WOD - female - 1462387 - Durham vs Hampshire
2025-09-07 - club - WCL - female - 1489953 - Guyana Amazon Warriors vs Barbados Royals
2025-09-07 - club - CPL - male - 1477996 - St Kitts and Nevis Patriots vs Guyana Amazon Warriors
2025-09-07 - club - CPL - male - 1477995 - Barbados Royals vs St Lucia Kings
2025-09-06 - international - T20 - male - 1492824 - Sri Lanka vs Zimbabwe
2025-09-06 - international - T20 - female - 1499782 - Estonia vs Czech Republic
2025-09-06 - international - T20 - female - 1499781 - Czech Republic vs Estonia
2025-09-06 - international - T20 - female - 1499780 - Japan vs Fiji
2025-09-06 - international - T20 - female - 1498726 - Namibia vs Zimbabwe
2025-09-06 - international - T20 - female - 1498725 - Rwanda vs Kenya
2025-09-06 - international - T20 - female - 1498724 - Nigeria vs Sierra Leone
2025-09-06 - international - T20 - female - 1498723 - Tanzania vs Uganda
2025-09-06 - club - WCL - female - 1489952 - Guyana Amazon Warriors vs Trinbago Knight Riders
2025-09-06 - club - NTB - male - 1460883 - Birmingham Bears vs Somerset
2025-09-06 - club - NTB - male - 1460882 - Kent vs Lancashire
2025-09-06 - club - CPL - male - 1477994 - Trinbago Knight Riders vs Guyana Amazon Warriors
2025-09-05 - international - T20 - female - 1499779 - Japan vs Fiji
2025-09-05 - club - NTB - male - 1460881 - Hampshire vs Durham
2025-09-05 - club - CPL - male - 1477993 - Barbados Royals vs Antigua and Barbuda Falcons
2025-09-04 - international - T20 - male - 1497877 - Pakistan vs United Arab Emirates
2025-09-04 - international - T20 - female - 1498722 - Rwanda vs Sierra Leone
2025-09-04 - international - T20 - female - 1498721 - Tanzania vs Namibia
2025-09-04 - international - T20 - female - 1498720 - Kenya vs Nigeria
2025-09-04 - international - T20 - female - 1498719 - Uganda vs Zimbabwe
2025-09-04 - international - ODI - male - 1498185 - Scotland vs Namibia
2025-09-04 - international - ODI - male - 1448355 - South Africa vs England
2025-09-04 - club - WOD - female - 1462385 - The Blaze vs Surrey
2025-09-04 - club - WOD - female - 1462384 - Lancashire vs Somerset
2025-09-04 - club - WOD - female - 1462383 - Hampshire vs Essex
2025-09-04 - club - CPL - male - 1477992 - Barbados Royals vs Guyana Amazon Warriors
2025-09-03 - international - T20 - male - 1498664 - Bangladesh vs Netherlands
2025-09-03 - international - T20 - male - 1492823 - Zimbabwe vs Sri Lanka
2025-09-03 - international - T20 - female - 1498718 - Nigeria vs Zimbabwe
2025-09-03 - international - T20 - female - 1498717 - Kenya vs Uganda
2025-09-03 - international - T20 - female - 1498716 - Namibia vs Sierra Leone
2025-09-03 - international - T20 - female - 1498715 - Tanzania vs Rwanda
2025-09-03 - club - NTB - male - 1460880 - Northamptonshire vs Surrey
2025-09-03 - club - CPL - male - 1477991 - Trinbago Knight Riders vs St Lucia Kings
2025-09-02 - international - T20 - female - 1500638 - Jersey vs Isle of Man
2025-09-02 - international - ODI - male - 1498184 - Namibia vs Canada
2025-09-02 - international - ODI - male - 1448354 - England vs South Africa
2025-09-01 - international - T20 - male - 1498663 - Netherlands vs Bangladesh
2025-09-01 - international - T20 - female - 1500636 - Brazil vs Isle of Man
2025-09-01 - international - T20 - female - 1498714 - Rwanda vs Uganda
2025-09-01 - international - T20 - female - 1498713 - Nigeria vs Namibia
2025-09-01 - international - T20 - female - 1498712 - Tanzania vs Kenya
2025-09-01 - international - T20 - female - 1498711 - Sierra Leone vs Zimbabwe
2025-09-01 - club - CPL - male - 1477990 - Trinbago Knight Riders vs St Kitts and Nevis Patriots
2025-08-31 - international - T20 - female - 1500635 - Isle of Man vs Brazil
2025-08-31 - international - T20 - female - 1499030 - Sweden vs Finland
2025-08-31 - international - T20 - female - 1499029 - Germany vs Denmark
2025-08-31 - international - T20 - female - 1499028 - Germany vs Sweden
2025-08-31 - international - T20 - female - 1499027 - Norway vs Denmark
2025-08-31 - international - T20 - female - 1498710 - Tanzania vs Uganda
2025-08-31 - international - T20 - female - 1498709 - Zimbabwe vs Namibia
2025-08-31 - international - T20 - female - 1498708 - Kenya vs Rwanda
2025-08-31 - international - T20 - female - 1498707 - Nigeria vs Sierra Leone
2025-08-31 - international - ODM - male - 1497111 - Denmark vs Kenya
2025-08-31 - international - ODM - male - 1497110 - Qatar vs Jersey
2025-08-31 - international - ODI - male - 1498183 - Canada vs Scotland
2025-08-31 - international - ODI - male - 1492822 - Zimbabwe vs Sri Lanka
2025-08-31 - club - RLC - male - 1462031 - Hampshire vs Yorkshire
2025-08-31 - club - RLC - male - 1462030 - Worcestershire vs Somerset
2025-08-31 - club - HND - male - 1471035 - Oval Invincibles vs Trent Rockets
2025-08-31 - club - HND - female - 1471069 - Southern Brave vs Northern Superchargers
2025-08-31 - club - CPL - male - 1477989 - Antigua and Barbuda Falcons vs St Lucia Kings
2025-08-30 - international - T20 - male - 1498691 - Switzerland vs Guernsey
2025-08-30 - international - T20 - male - 1498690 - Guernsey vs Switzerland
2025-08-30 - international - T20 - male - 1498662 - Netherlands vs Bangladesh
2025-08-30 - international - T20 - male - 1497874 - Pakistan vs United Arab Emirates
2025-08-30 - international - T20 - female - 1499026 - Germany vs Norway
2025-08-30 - international - T20 - female - 1499025 - Finland vs Denmark
2025-08-30 - international - T20 - female - 1499024 - Sweden vs Denmark
2025-08-30 - international - T20 - female - 1499023 - Finland vs Norway
2025-08-30 - international - ODM - male - 1497109 - Papua New Guinea vs Qatar
2025-08-30 - international - ODM - male - 1497108 - Kuwait vs Kenya
2025-08-30 - club - HND - male - 1471034 - Northern Superchargers vs Trent Rockets
2025-08-30 - club - HND - female - 1471068 - Northern Superchargers vs London Spirit
2025-08-30 - club - CPL - male - 1477988 - Guyana Amazon Warriors vs Trinbago Knight Riders
2025-08-29 - international - T20 - female - 1499022 - Sweden vs Norway
2025-08-29 - international - T20 - female - 1499021 - Finland vs Germany
2025-08-29 - international - ODI - male - 1492821 - Sri Lanka vs Zimbabwe
2025-08-29 - club - CPL - male - 1477987 - Barbados Royals vs Trinbago Knight Riders
2025-08-28 - international - ODM - male - 1497107 - Jersey vs Papua New Guinea
2025-08-28 - international - ODM - male - 1497106 - Denmark vs Kuwait
2025-08-28 - club - RLC - male - 1462029 - Gloucestershire vs Somerset
2025-08-28 - club - RLC - male - 1462028 - Hampshire vs Middlesex
2025-08-28 - club - HND - male - 1471033 - Southern Brave vs Welsh Fire
2025-08-28 - club - HND - female - 1471067 - Southern Brave vs Welsh Fire
2025-08-28 - club - CPL - male - 1477986 - St Kitts and Nevis Patriots vs St Lucia Kings
2025-08-27 - international - T20 - female - 1498217 - Ireland vs Italy
2025-08-27 - international - T20 - female - 1498216 - Netherlands vs Germany
2025-08-27 - international - ODM - male - 1497105 - Kenya vs Papua New Guinea
2025-08-27 - international - ODM - male - 1497104 - Qatar vs Denmark
2025-08-27 - international - ODI - male - 1498181 - Canada vs Namibia
2025-08-27 - club - IPO - male - 1478058 - North-West Warriors vs Leinster Lightning
2025-08-27 - club - HND - male - 1471032 - Birmingham Phoenix vs Trent Rockets
2025-08-27 - club - HND - female - 1471066 - Birmingham Phoenix vs Trent Rockets
2025-08-27 - club - CPL - male - 1477985 - Antigua and Barbuda Falcons vs Trinbago Knight Riders
2025-08-26 - international - T20 - female - 1498215 - Netherlands vs Ireland
2025-08-26 - international - T20 - female - 1498214 - Germany vs Italy
2025-08-26 - club - RLC - male - 1462027 - Surrey vs Worcestershire
2025-08-26 - club - RLC - male - 1462026 - Sussex vs Warwickshire
2025-08-26 - club - RLC - male - 1462025 - Northamptonshire vs Somerset
2025-08-26 - club - RLC - male - 1462024 - Lancashire vs Middlesex
2025-08-26 - club - RLC - male - 1462023 - Yorkshire vs Kent
2025-08-26 - club - RLC - male - 1462022 - Gloucestershire vs Hampshire
2025-08-26 - club - RLC - male - 1462021 - Leicestershire vs Glamorgan
2025-08-26 - club - RLC - male - 1462020 - Essex vs Derbyshire
2025-08-26 - club - HND - male - 1471031 - Northern Superchargers vs Manchester Originals
2025-08-26 - club - HND - female - 1471065 - Manchester Originals vs Northern Superchargers
2025-08-26 - club - CPL - male - 1477984 - Guyana Amazon Warriors vs St Lucia Kings
2025-08-25 - international - ODM - male - 1497103 - Jersey vs Denmark
2025-08-25 - club - HND - male - 1471030 - London Spirit vs Oval Invincibles
2025-08-25 - club - HND - female - 1471064 - Oval Invincibles vs London Spirit
2025-08-24 - international - T20 - male - 1498699 - Belgium vs Austria
2025-08-24 - international - T20 - male - 1498698 - Belgium vs Austria
2025-08-24 - international - T20 - female - 1498213 - Italy vs Netherlands
2025-08-24 - international - T20 - female - 1498212 - Ireland vs Germany
2025-08-24 - international - ODM - male - 1497102 - Papua New Guinea vs Kuwait
2025-08-24 - international - ODM - male - 1497101 - Kenya vs Qatar
2025-08-24 - international - ODI - male - 1478903 - Australia vs South Africa
2025-08-24 - club - RLC - male - 1462019 - Sussex vs Yorkshire
2025-08-24 - club - RLC - male - 1462018 - Surrey vs Nottinghamshire
2025-08-24 - club - RLC - male - 1462017 - Northamptonshire vs Middlesex
2025-08-24 - club - RLC - male - 1462016 - Worcestershire vs Leicestershire
2025-08-24 - club - RLC - male - 1462015 - Kent vs Somerset
2025-08-24 - club - RLC - male - 1462014 - Derbyshire vs Hampshire
2025-08-24 - club - RLC - male - 1462013 - Essex vs Gloucestershire
2025-08-24 - club - RLC - male - 1462012 - Durham vs Warwickshire
2025-08-24 - club - HND - male - 1471029 - Manchester Originals vs Birmingham Phoenix
2025-08-24 - club - HND - male - 1471028 - Welsh Fire vs Trent Rockets
2025-08-24 - club - HND - female - 1471063 - Birmingham Phoenix vs Manchester Originals
2025-08-24 - club - HND - female - 1471062 - Trent Rockets vs Welsh Fire
2025-08-24 - club - CPL - male - 1477982 - St Kitts and Nevis Patriots vs Antigua and Barbuda Falcons
2025-08-23 - international - T20 - male - 1498697 - Austria vs Belgium
2025-08-23 - international - T20 - male - 1498696 - Belgium vs Austria
2025-08-23 - international - T20 - female - 1498211 - Netherlands vs Germany
2025-08-23 - international - T20 - female - 1498210 - Ireland vs Italy
2025-08-23 - international - ODM - male - 1497100 - Kuwait vs Jersey
2025-08-23 - club - HND - male - 1471027 - London Spirit vs Southern Brave
2025-08-23 - club - HND - male - 1471026 - Northern Superchargers vs Oval Invincibles
2025-08-23 - club - HND - female - 1471061 - London Spirit vs Southern Brave
2025-08-23 - club - HND - female - 1471060 - Oval Invincibles vs Northern Superchargers
2025-08-23 - club - CPL - male - 1477981 - Trinbago Knight Riders vs St Lucia Kings
2025-08-22 - international - T20 - male - 1499014 - Romania vs Czech Republic
2025-08-22 - international - T20 - male - 1499013 - Romania vs Czech Republic
2025-08-22 - international - ODM - male - 1497099 - Denmark vs Papua New Guinea
2025-08-22 - international - ODI - male - 1478902 - South Africa vs Australia
2025-08-22 - club - RLC - male - 1462011 - Yorkshire vs Durham
2025-08-22 - club - RLC - male - 1462010 - Glamorgan vs Worcestershire
2025-08-22 - club - RLC - male - 1462009 - Gloucestershire vs Nottinghamshire
2025-08-22 - club - RLC - male - 1462008 - Lancashire vs Warwickshire
2025-08-22 - club - RLC - male - 1462007 - Surrey vs Derbyshire
2025-08-22 - club - HND - male - 1471025 - Birmingham Phoenix vs Welsh Fire
2025-08-22 - club - HND - female - 1471059 - Welsh Fire vs Birmingham Phoenix
2025-08-22 - club - CPL - male - 1477980 - Guyana Amazon Warriors vs Antigua and Barbuda Falcons
2025-08-21 - international - T20 - male - 1499012 - Romania vs Czech Republic
2025-08-21 - international - T20 - male - 1499011 - Czech Republic vs Romania
2025-08-21 - international - T20 - female - 1498209 - Germany vs Italy
2025-08-21 - international - T20 - female - 1498208 - Netherlands vs Ireland
2025-08-21 - international - ODM - male - 1497098 - Kenya vs Jersey
2025-08-21 - international - ODM - male - 1497097 - Kuwait vs Qatar
2025-08-21 - club - RLC - male - 1462006 - Somerset vs Sussex
2025-08-21 - club - RLC - male - 1462005 - Northamptonshire vs Kent
2025-08-21 - club - HND - male - 1471024 - Trent Rockets vs Oval Invincibles
2025-08-21 - club - HND - female - 1471058 - Oval Invincibles vs Trent Rockets
2025-08-21 - club - CPL - male - 1477979 - St Kitts and Nevis Patriots vs Barbados Royals
2025-08-20 - international - T20 - female - 1498207 - Germany vs Ireland
2025-08-20 - international - T20 - female - 1498206 - Netherlands vs Italy
2025-08-20 - club - RLC - male - 1462004 - Leicestershire vs Derbyshire
2025-08-20 - club - RLC - male - 1462003 - Lancashire vs Durham
2025-08-20 - club - RLC - male - 1462002 - Hampshire vs Nottinghamshire
2025-08-20 - club - RLC - male - 1462001 - Essex vs Glamorgan
2025-08-20 - club - IPO - male - 1478057 - North-West Warriors vs Munster Reds
2025-08-20 - club - IPO - male - 1478056 - Northern Knights vs Leinster Lightning
2025-08-20 - club - HND - male - 1471023 - London Spirit vs Northern Superchargers
2025-08-20 - club - HND - male - 1471022 - Southern Brave vs Welsh Fire
2025-08-20 - club - HND - female - 1471057 - London Spirit vs Northern Superchargers
2025-08-20 - club - HND - female - 1471056 - Welsh Fire vs Southern Brave
2025-08-20 - club - CPL - male - 1477978 - Antigua and Barbuda Falcons vs Trinbago Knight Riders
2025-08-19 - international - ODI - male - 1478901 - South Africa vs Australia
2025-08-19 - club - RLC - male - 1462000 - Kent vs Middlesex
2025-08-19 - club - HND - male - 1471021 - Manchester Originals vs Trent Rockets
2025-08-19 - club - HND - female - 1471055 - Trent Rockets vs Manchester Originals
2025-08-19 - club - CPL - male - 1477977 - St Lucia Kings vs St Kitts and Nevis Patriots
2025-08-18 - club - RLC - male - 1461999 - Surrey vs Hampshire
2025-08-18 - club - HND - male - 1471020 - Southern Brave vs Oval Invincibles
2025-08-18 - club - HND - female - 1471054 - Southern Brave vs Oval Invincibles
2025-08-17 - international - T20 - male - 1498192 - Norway vs Hungary
2025-08-17 - international - T20 - male - 1498191 - Sweden vs Hungary
2025-08-17 - international - T20 - male - 1496827 - Sweden vs Norway
2025-08-17 - club - RLC - male - 1461998 - Worcestershire vs Gloucestershire
2025-08-17 - club - RLC - male - 1461997 - Somerset vs Warwickshire
2025-08-17 - club - RLC - male - 1461996 - Northamptonshire vs Sussex
2025-08-17 - club - RLC - male - 1461995 - Middlesex vs Yorkshire
2025-08-17 - club - RLC - male - 1461994 - Essex vs Leicestershire
2025-08-17 - club - RLC - male - 1461993 - Kent vs Lancashire
2025-08-17 - club - RLC - male - 1461992 - Glamorgan vs Nottinghamshire
2025-08-17 - club - HND - male - 1471019 - London Spirit vs Birmingham Phoenix
2025-08-17 - club - HND - male - 1471018 - Manchester Originals vs Northern Superchargers
2025-08-17 - club - HND - female - 1471053 - London Spirit vs Birmingham Phoenix
2025-08-17 - club - HND - female - 1471052 - Manchester Originals vs Northern Superchargers
2025-08-17 - club - CPL - male - 1477975 - Trinbago Knight Riders vs St Kitts and Nevis Patriots
2025-08-16 - international - T20 - male - 1478900 - South Africa vs Australia
2025-08-16 - international - T20 - female - 1498205 - Singapore vs Cambodia
2025-08-16 - club - HND - male - 1471017 - Oval Invincibles vs Welsh Fire
2025-08-16 - club - HND - male - 1471016 - Southern Brave vs Trent Rockets
2025-08-16 - club - HND - female - 1471051 - Oval Invincibles vs Welsh Fire
2025-08-16 - club - HND - female - 1471050 - Trent Rockets vs Southern Brave
2025-08-16 - club - CPL - male - 1477974 - Barbados Royals vs Antigua and Barbuda Falcons
2025-08-15 - club - RLC - male - 1461991 - Middlesex vs Warwickshire
2025-08-15 - club - RLC - male - 1461990 - Lancashire vs Sussex
2025-08-15 - club - RLC - male - 1461989 - Leicestershire vs Hampshire
2025-08-15 - club - RLC - male - 1461988 - Glamorgan vs Gloucestershire
2025-08-15 - club - RLC - male - 1461987 - Essex vs Surrey
2025-08-15 - club - RLC - male - 1461986 - Northamptonshire vs Durham
2025-08-15 - club - RLC - male - 1461985 - Derbyshire vs Worcestershire
2025-08-15 - club - HND - male - 1471015 - Northern Superchargers vs Birmingham Phoenix
2025-08-15 - club - HND - female - 1471049 - Birmingham Phoenix vs Northern Superchargers
2025-08-15 - club - CPL - male - 1477973 - St Kitts and Nevis Patriots vs Guyana Amazon Warriors
2025-08-14 - international - T20 - male - 1498689 - Guernsey vs Papua New Guinea
2025-08-14 - international - T20 - female - 1498204 - Singapore vs Cambodia
2025-08-14 - club - RLC - male - 1461984 - Yorkshire vs Somerset
2025-08-14 - club - HND - male - 1471014 - London Spirit vs Trent Rockets
2025-08-14 - club - HND - female - 1471048 - Trent Rockets vs London Spirit
2025-08-14 - club - CPL - male - 1477972 - Antigua and Barbuda Falcons vs St Kitts and Nevis Patriots
2025-08-13 - international - T20 - female - 1498203 - Singapore vs Cambodia
2025-08-13 - club - RLC - male - 1461983 - Hampshire vs Worcestershire
2025-08-13 - club - RLC - male - 1461982 - Warwickshire vs Kent
2025-08-13 - club - RLC - male - 1461981 - Glamorgan vs Surrey
2025-08-13 - club - RLC - male - 1461980 - Leicestershire vs Nottinghamshire
2025-08-13 - club - RLC - male - 1461979 - Durham vs Middlesex
2025-08-13 - club - IPO - male - 1478055 - North-West Warriors vs Northern Knights
2025-08-13 - club - IPO - male - 1478054 - Munster Reds vs Leinster Lightning
2025-08-13 - club - HND - male - 1471013 - Welsh Fire vs Manchester Originals
2025-08-13 - club - HND - male - 1471012 - Southern Brave vs Northern Superchargers
2025-08-13 - club - HND - female - 1471047 - Welsh Fire vs Manchester Originals
2025-08-13 - club - HND - female - 1471046 - Northern Superchargers vs Southern Brave
2025-08-12 - international - T20 - male - 1478899 - South Africa vs Australia
2025-08-12 - international - ODI - male - 1472530 - West Indies vs Pakistan
2025-08-12 - club - RLC - male - 1461978 - Lancashire vs Yorkshire
2025-08-12 - club - HND - male - 1471011 - Oval Invincibles vs Birmingham Phoenix
2025-08-12 - club - HND - female - 1471045 - Oval Invincibles vs Birmingham Phoenix
2025-08-11 - club - HND - male - 1471010 - Manchester Originals vs London Spirit
2025-08-11 - club - HND - female - 1471044 - Manchester Originals vs London Spirit
2025-08-10 - international - T20 - male - 1496826 - Norway vs Austria
2025-08-10 - international - T20 - male - 1496825 - Sweden vs France
2025-08-10 - international - T20 - male - 1478898 - Australia vs South Africa
2025-08-10 - international - T20 - female - 1476994 - Ireland vs Pakistan
2025-08-10 - international - ODI - male - 1472529 - Pakistan vs West Indies
2025-08-10 - club - RLC - male - 1461977 - Warwickshire vs Northamptonshire
2025-08-10 - club - RLC - male - 1461976 - Somerset vs Lancashire
2025-08-10 - club - RLC - male - 1461975 - Sussex vs Middlesex
2025-08-10 - club - RLC - male - 1461974 - Kent vs Durham
2025-08-10 - club - RLC - male - 1461973 - Leicestershire vs Gloucestershire
2025-08-10 - club - RLC - male - 1461972 - Worcestershire vs Essex
2025-08-10 - club - RLC - male - 1461971 - Derbyshire vs Nottinghamshire
2025-08-10 - club - HND - male - 1471009 - Northern Superchargers vs Trent Rockets
2025-08-10 - club - HND - male - 1471008 - Birmingham Phoenix vs Southern Brave
2025-08-10 - club - HND - female - 1471043 - Trent Rockets vs Northern Superchargers
2025-08-10 - club - HND - female - 1471042 - Southern Brave vs Birmingham Phoenix
2025-08-09 - international - T20 - male - 1496824 - France vs Austria
2025-08-09 - international - T20 - male - 1496823 - Norway vs Sweden
2025-08-09 - club - HND - male - 1471007 - London Spirit vs Welsh Fire
2025-08-09 - club - HND - male - 1471006 - Manchester Originals vs Oval Invincibles
2025-08-09 - club - HND - female - 1471041 - London Spirit vs Welsh Fire
2025-08-09 - club - HND - female - 1471040 - Manchester Originals vs Oval Invincibles
2025-08-08 - international - T20 - male - 1496831 - Cyprus vs Croatia
2025-08-08 - international - T20 - male - 1496830 - Croatia vs Cyprus
2025-08-08 - international - T20 - male - 1496822 - Norway vs France
2025-08-08 - international - T20 - male - 1496821 - Sweden vs Austria
2025-08-08 - international - T20 - female - 1476993 - Pakistan vs Ireland
2025-08-08 - international - ODI - male - 1472528 - West Indies vs Pakistan
2025-08-08 - club - RLC - male - 1461970 - Gloucestershire vs Surrey
2025-08-08 - club - RLC - male - 1461969 - Durham vs Somerset
2025-08-08 - club - RLC - male - 1461968 - Yorkshire vs Northamptonshire
2025-08-08 - club - HND - male - 1471005 - Birmingham Phoenix vs Trent Rockets
2025-08-08 - club - HND - female - 1471039 - Birmingham Phoenix vs Trent Rockets
2025-08-07 - international - Test - male - 1478873 - Zimbabwe vs New Zealand
2025-08-07 - international - T20 - male - 1496829 - Croatia vs Cyprus
2025-08-07 - international - T20 - male - 1496828 - Cyprus vs Croatia
2025-08-07 - club - RLC - male - 1461967 - Kent vs Sussex
2025-08-07 - club - RLC - male - 1461966 - Worcestershire vs Nottinghamshire
2025-08-07 - club - RLC - male - 1461965 - Essex vs Hampshire
2025-08-07 - club - HND - male - 1471004 - Welsh Fire vs Northern Superchargers
2025-08-07 - club - HND - female - 1471038 - Northern Superchargers vs Welsh Fire
2025-08-06 - international - T20 - female - 1476992 - Ireland vs Pakistan
2025-08-06 - club - RLC - male - 1461963 - Surrey vs Leicestershire
2025-08-06 - club - RLC - male - 1461962 - Middlesex vs Somerset
2025-08-06 - club - HND - male - 1471003 - Manchester Originals vs Southern Brave
2025-08-06 - club - HND - female - 1471037 - Manchester Originals vs Southern Brave
2025-08-05 - club - RLC - male - 1461961 - Warwickshire vs Yorkshire
2025-08-05 - club - RLC - male - 1461960 - Nottinghamshire vs Essex
2025-08-05 - club - RLC - male - 1461958 - Gloucestershire vs Derbyshire
2025-08-05 - club - RLC - male - 1461957 - Hampshire vs Glamorgan
2025-08-05 - club - RLC - male - 1461956 - Durham vs Sussex
2025-08-05 - club - HND - male - 1471002 - London Spirit vs Oval Invincibles
2025-08-05 - club - HND - female - 1471036 - London Spirit vs Oval Invincibles
2025-08-03 - international - T20 - male - 1494775 - Switzerland vs Estonia
2025-08-03 - international - T20 - male - 1494774 - Switzerland vs Estonia
2025-08-03 - international - T20 - male - 1472527 - Pakistan vs West Indies
2025-08-02 - international - T20 - male - 1494773 - Switzerland vs Estonia
2025-08-02 - international - T20 - male - 1472526 - Pakistan vs West Indies
2025-07-31 - international - Test - male - 1448353 - India vs England
2025-07-31 - international - T20 - male - 1472525 - Pakistan vs West Indies
2025-07-30 - international - Test - male - 1478872 - Zimbabwe vs New Zealand
2025-07-30 - club - WOD - female - 1462382 - Warwickshire vs Surrey
2025-07-30 - club - WOD - female - 1462381 - Durham vs Somerset
2025-07-30 - club - WOD - female - 1462380 - Lancashire vs Essex
2025-07-30 - club - WOD - female - 1462379 - Hampshire vs The Blaze
2025-07-30 - club - MCL - male - 1490286 - Colombo Cricket Club vs Police Sports Club
2025-07-29 - club - CCH - male - 1461937 - Leicestershire vs Kent
2025-07-29 - club - CCH - male - 1461936 - Glamorgan vs Lancashire
2025-07-29 - club - CCH - male - 1461935 - Middlesex vs Gloucestershire
2025-07-29 - club - CCH - male - 1461934 - Derbyshire vs Northamptonshire
2025-07-29 - club - CCH - male - 1461878 - Somerset vs Nottinghamshire
2025-07-29 - club - CCH - male - 1461877 - Hampshire vs Worcestershire
2025-07-29 - club - CCH - male - 1461876 - Sussex vs Yorkshire
2025-07-29 - club - CCH - male - 1461875 - Essex vs Warwickshire
2025-07-29 - club - CCH - male - 1461874 - Durham vs Surrey
2025-07-28 - international - T20 - male - 1472524 - West Indies vs Australia
2025-07-28 - international - ODI - female - 1476991 - Zimbabwe vs Ireland
2025-07-27 - international - T20 - male - 1495661 - Austria vs Romania
2025-07-27 - international - T20 - male - 1495660 - Hungary vs Luxembourg
2025-07-27 - international - T20 - male - 1495465 - Bahrain vs Malawi
2025-07-27 - international - T20 - male - 1494772 - Estonia vs Finland
2025-07-27 - international - T20 - male - 1494584 - Nigeria vs Kenya
2025-07-27 - international - T20 - male - 1494111 - Uganda vs United Arab Emirates
2025-07-27 - club - WTB - female - 1461047 - Warwickshire vs Surrey
2025-07-27 - club - WTB - female - 1461045 - Warwickshire vs The Blaze
2025-07-27 - club - MCL - male - 1490285 - Colombo Cricket Club vs Tamil Union Cricket and Athletic Club
2025-07-26 - international - T20 - male - 1495659 - Austria vs Luxembourg
2025-07-26 - international - T20 - male - 1495658 - Hungary vs Austria
2025-07-26 - international - T20 - male - 1495657 - Romania vs Luxembourg
2025-07-26 - international - T20 - male - 1495464 - Rwanda vs Malawi
2025-07-26 - international - T20 - male - 1494771 - Finland vs Estonia
2025-07-26 - international - T20 - male - 1494113 - United Arab Emirates vs Nigeria
2025-07-26 - international - T20 - male - 1494102 - Hong Kong vs Malaysia
2025-07-26 - international - T20 - male - 1478871 - New Zealand vs South Africa
2025-07-26 - international - T20 - male - 1472523 - West Indies vs Australia
2025-07-26 - international - T20 - female - 1494143 - Rwanda vs Sierra Leone
2025-07-26 - international - T20 - female - 1494142 - Mozambique vs Cameroon
2025-07-26 - international - T20 - female - 1494141 - Lesotho vs Eswatini
2025-07-26 - international - T20 - female - 1494140 - Botswana vs Malawi
2025-07-26 - international - ODI - female - 1476990 - Ireland vs Zimbabwe
2025-07-25 - international - T20 - male - 1495656 - Hungary vs Luxembourg
2025-07-25 - international - T20 - male - 1495655 - Hungary vs Romania
2025-07-25 - international - T20 - male - 1495654 - Romania vs Austria
2025-07-25 - international - T20 - male - 1495463 - Malawi vs Bahrain
2025-07-25 - international - T20 - male - 1495462 - Bahrain vs Rwanda
2025-07-25 - international - T20 - male - 1494114 - Kenya vs Uganda
2025-07-25 - international - T20 - male - 1472522 - West Indies vs Australia
2025-07-25 - club - MCL - male - 1490284 - Colts Cricket Club vs Police Sports Club
2025-07-24 - international - T20 - male - 1494101 - Hong Kong vs Singapore
2025-07-24 - international - T20 - male - 1494100 - Samoa vs Malaysia
2025-07-24 - international - T20 - male - 1491905 - Pakistan vs Bangladesh
2025-07-24 - international - T20 - male - 1478870 - New Zealand vs Zimbabwe
2025-07-24 - international - T20 - female - 1494139 - Malawi vs Sierra Leone
2025-07-24 - international - T20 - female - 1494138 - Lesotho vs Mozambique
2025-07-24 - international - T20 - female - 1494137 - Rwanda vs Botswana
2025-07-24 - international - T20 - female - 1494136 - Cameroon vs Eswatini
2025-07-24 - club - WOD - female - 1462378 - The Blaze vs Warwickshire
2025-07-24 - club - WOD - female - 1462377 - Hampshire vs Surrey
2025-07-24 - club - WOD - female - 1462376 - Somerset vs Essex
2025-07-24 - club - WOD - female - 1462375 - Durham vs Lancashire
2025-07-23 - international - Test - male - 1448352 - India vs England
2025-07-23 - international - T20 - male - 1495461 - Bahrain vs Malawi
2025-07-23 - international - T20 - male - 1495460 - Rwanda vs Malawi
2025-07-23 - international - T20 - male - 1494769 - Saudi Arabia vs Qatar
2025-07-23 - international - T20 - male - 1494110 - Kenya vs United Arab Emirates
2025-07-23 - international - T20 - male - 1494099 - Malaysia vs Singapore
2025-07-23 - international - T20 - male - 1494098 - Samoa vs Hong Kong
2025-07-23 - international - T20 - female - 1494135 - Cameroon vs Rwanda
2025-07-23 - international - T20 - female - 1494134 - Botswana vs Sierra Leone
2025-07-23 - international - T20 - female - 1494133 - Mozambique vs Eswatini
2025-07-23 - international - T20 - female - 1494132 - Malawi vs Lesotho
2025-07-23 - international - T20 - female - 1476989 - Ireland vs Zimbabwe
2025-07-22 - international - T20 - male - 1495459 - Bahrain vs Rwanda
2025-07-22 - international - T20 - male - 1495458 - Malawi vs Rwanda
2025-07-22 - international - T20 - male - 1494768 - Qatar vs Saudi Arabia
2025-07-22 - international - T20 - male - 1494583 - Uganda vs Nigeria
2025-07-22 - international - T20 - male - 1494097 - Samoa vs Singapore
2025-07-22 - international - T20 - male - 1494096 - Hong Kong vs Malaysia
2025-07-22 - international - T20 - male - 1491904 - Bangladesh vs Pakistan
2025-07-22 - international - T20 - male - 1478869 - South Africa vs New Zealand
2025-07-22 - international - T20 - male - 1472521 - West Indies vs Australia
2025-07-22 - international - T20 - female - 1476988 - Ireland vs Zimbabwe
2025-07-22 - international - ODI - female - 1448404 - India vs England
2025-07-22 - club - CCH - male - 1461933 - Lancashire vs Gloucestershire
2025-07-22 - club - CCH - male - 1461932 - Leicestershire vs Derbyshire
2025-07-22 - club - CCH - male - 1461931 - Middlesex vs Northamptonshire
2025-07-22 - club - CCH - male - 1461930 - Kent vs Glamorgan
2025-07-22 - club - CCH - male - 1461873 - Worcestershire vs Warwickshire
2025-07-22 - club - CCH - male - 1461872 - Yorkshire vs Surrey
2025-07-22 - club - CCH - male - 1461871 - Sussex vs Essex
2025-07-22 - club - CCH - male - 1461870 - Nottinghamshire vs Hampshire
2025-07-22 - club - CCH - male - 1461869 - Durham vs Somerset
2025-07-21 - international - T20 - male - 1494767 - Saudi Arabia vs Qatar
2025-07-21 - international - T20 - male - 1494118 - Nigeria vs United Arab Emirates
2025-07-21 - international - T20 - male - 1494103 - Uganda vs Kenya
2025-07-21 - international - T20 - female - 1494131 - Cameroon vs Lesotho
2025-07-21 - international - T20 - female - 1494130 - Sierra Leone vs Eswatini
2025-07-21 - international - T20 - female - 1494129 - Rwanda vs Malawi
2025-07-21 - international - T20 - female - 1494128 - Mozambique vs Botswana
2025-07-21 - club - MCL - male - 1490253 - Burgher Recreation Club vs Kurunegala Youth Cricket Club
2025-07-21 - club - MCL - male - 1490252 - Colts Cricket Club vs Bloomfield Cricket and Athletic Club
2025-07-21 - club - MCL - male - 1490251 - Nugegoda Sports Welfare Club vs Colombo Cricket Club
2025-07-21 - club - MCL - male - 1490250 - Badureliya Sports Club vs Panadura Sports Club
2025-07-21 - club - MCL - male - 1490249 - Police Sports Club vs Tamil Union Cricket and Athletic Club
2025-07-21 - club - MCL - male - 1490248 - Ace Capital Cricket Club vs Chilaw Marians Cricket Club
2025-07-20 - international - T20 - male - 1495457 - Rwanda vs Bahrain
2025-07-20 - international - T20 - male - 1495456 - Malawi vs Bahrain
2025-07-20 - international - T20 - male - 1494095 - Samoa vs Malaysia
2025-07-20 - international - T20 - male - 1494094 - Hong Kong vs Singapore
2025-07-20 - international - T20 - male - 1491903 - Pakistan vs Bangladesh
2025-07-20 - international - T20 - male - 1478868 - Zimbabwe vs South Africa
2025-07-20 - international - T20 - male - 1472520 - West Indies vs Australia
2025-07-20 - international - T20 - female - 1494581 - Finland vs Switzerland
2025-07-20 - international - T20 - female - 1494580 - Estonia vs Finland
2025-07-20 - international - T20 - female - 1494127 - Sierra Leone vs Mozambique
2025-07-20 - international - T20 - female - 1494126 - Malawi vs Cameroon
2025-07-20 - international - T20 - female - 1494125 - Botswana vs Eswatini
2025-07-20 - international - T20 - female - 1494124 - Lesotho vs Rwanda
2025-07-20 - international - T20 - female - 1476987 - Zimbabwe vs Ireland
2025-07-19 - international - T20 - male - 1495455 - Malawi vs Rwanda
2025-07-19 - international - T20 - male - 1495454 - Malawi vs Bahrain
2025-07-19 - international - T20 - male - 1494766 - Qatar vs Saudi Arabia
2025-07-19 - international - T20 - male - 1494108 - Uganda vs United Arab Emirates
2025-07-19 - international - T20 - male - 1494093 - Hong Kong vs Samoa
2025-07-19 - international - T20 - male - 1494092 - Singapore vs Malaysia
2025-07-19 - international - T20 - female - 1494579 - Switzerland vs Estonia
2025-07-19 - international - T20 - female - 1494578 - Finland vs Switzerland
2025-07-19 - international - T20 - female - 1494577 - Estonia vs Finland
2025-07-19 - international - ODI - female - 1448403 - India vs England
2025-07-18 - international - T20 - male - 1495453 - Rwanda vs Bahrain
2025-07-18 - international - T20 - male - 1494116 - Uganda vs Nigeria
2025-07-18 - international - T20 - male - 1494091 - Singapore vs Samoa
2025-07-18 - international - T20 - male - 1494090 - Hong Kong vs Malaysia
2025-07-18 - international - T20 - male - 1478867 - Zimbabwe vs New Zealand
2025-07-18 - club - WTB - female - 1461044 - Surrey vs Warwickshire
2025-07-18 - club - WTB - female - 1461043 - Somerset vs Lancashire
2025-07-18 - club - WTB - female - 1461042 - The Blaze vs Hampshire
2025-07-18 - club - WTB - female - 1461041 - Essex vs Durham
2025-07-18 - club - NTB - male - 1460879 - Surrey vs Sussex
2025-07-18 - club - NTB - male - 1460878 - Somerset vs Gloucestershire
2025-07-18 - club - NTB - male - 1460877 - Lancashire vs Nottinghamshire
2025-07-18 - club - NTB - male - 1460876 - Leicestershire vs Yorkshire
2025-07-18 - club - NTB - male - 1460875 - Essex vs Kent
2025-07-18 - club - NTB - male - 1460874 - Glamorgan vs Middlesex
2025-07-18 - club - NTB - male - 1460873 - Northamptonshire vs Durham
2025-07-18 - club - NTB - male - 1460872 - Birmingham Bears vs Derbyshire
2025-07-17 - international - T20 - male - 1494115 - Kenya vs Nigeria
2025-07-17 - club - NTB - male - 1460871 - Lancashire vs Yorkshire
2025-07-17 - club - NTB - male - 1460870 - Worcestershire vs Nottinghamshire
2025-07-17 - club - NTB - male - 1460869 - Gloucestershire vs Sussex
2025-07-17 - club - NTB - male - 1460868 - Hampshire vs Essex
2025-07-17 - club - MCL - male - 1490247 - Burgher Recreation Club vs Moors Sports Club
2025-07-17 - club - MCL - male - 1490246 - Kurunegala Youth Cricket Club vs Nugegoda Sports Welfare Club
2025-07-17 - club - MCL - male - 1490245 - Colombo Cricket Club vs Bloomfield Cricket and Athletic Club
2025-07-17 - club - MCL - male - 1490244 - Nondescripts Cricket Club vs Badureliya Sports Club
2025-07-17 - club - MCL - male - 1490243 - Chilaw Marians Cricket Club vs Panadura Sports Club
2025-07-17 - club - MCL - male - 1490242 - Ace Capital Cricket Club vs Police Sports Club
2025-07-16 - international - T20 - male - 1485510 - Sri Lanka vs Bangladesh
2025-07-16 - international - T20 - male - 1478866 - New Zealand vs South Africa
2025-07-16 - international - ODI - female - 1448402 - England vs India
2025-07-16 - club - WTB - female - 1461040 - The Blaze vs Somerset
2025-07-16 - club - WTB - female - 1461039 - Essex vs Lancashire
2025-07-16 - club - NTB - male - 1460867 - Surrey vs Middlesex
2025-07-14 - international - T20 - male - 1478865 - Zimbabwe vs South Africa
2025-07-13 - international - T20 - male - 1492892 - Bahrain vs Tanzania
2025-07-13 - international - T20 - male - 1492891 - Germany vs Malawi
2025-07-13 - international - T20 - male - 1491610 - Gibraltar vs Bulgaria
2025-07-13 - international - T20 - male - 1490881 - South Korea vs Indonesia
2025-07-13 - international - T20 - male - 1490880 - Indonesia vs Philippines
2025-07-13 - international - T20 - male - 1485509 - Bangladesh vs Sri Lanka
2025-07-13 - club - WTB - female - 1461037 - Surrey vs Somerset
2025-07-13 - club - WTB - female - 1461036 - Lancashire vs Durham
2025-07-13 - club - WTB - female - 1461035 - Warwickshire vs Hampshire
2025-07-13 - club - WTB - female - 1461034 - The Blaze vs Essex
2025-07-13 - club - NTB - male - 1460865 - Yorkshire vs Derbyshire
2025-07-13 - club - NTB - male - 1460864 - Leicestershire vs Worcestershire
2025-07-13 - club - NTB - male - 1460863 - Surrey vs Somerset
2025-07-13 - club - NTB - male - 1460862 - Durham vs Lancashire
2025-07-13 - club - NTB - male - 1460861 - Middlesex vs Kent
2025-07-13 - club - NTB - male - 1460860 - Sussex vs Hampshire
2025-07-13 - club - NTB - male - 1460859 - Gloucestershire vs Glamorgan
2025-07-13 - club - NTB - male - 1460858 - Northamptonshire vs Birmingham Bears
2025-07-13 - club - MLC - male - 1482025 - MI New York vs Washington Freedom
2025-07-13 - club - MCL - male - 1490283 - Colts Cricket Club vs Burgher Recreation Club
2025-07-13 - club - MCL - male - 1490282 - Nugegoda Sports Welfare Club vs Moors Sports Club
2025-07-13 - club - MCL - male - 1490281 - Kurunegala Youth Cricket Club vs Colombo Cricket Club
2025-07-13 - club - MCL - male - 1490280 - Ace Capital Cricket Club vs Panadura Sports Club
2025-07-13 - club - MCL - male - 1490279 - Tamil Union Cricket and Athletic Club vs Badureliya Sports Club
2025-07-13 - club - MCL - male - 1490278 - Nondescripts Cricket Club vs Chilaw Marians Cricket Club
2025-07-12 - international - Test - male - 1472519 - Australia vs West Indies
2025-07-12 - international - T20 - male - 1492890 - Germany vs Tanzania
2025-07-12 - international - T20 - male - 1492889 - Malawi vs Bahrain
2025-07-12 - international - T20 - male - 1491609 - Turkey vs Gibraltar
2025-07-12 - international - T20 - male - 1491608 - Turkey vs Bulgaria
2025-07-12 - international - T20 - male - 1490879 - Philippines vs South Korea
2025-07-12 - international - T20 - male - 1490878 - Indonesia vs South Korea
2025-07-12 - international - T20 - female - 1448401 - India vs England
2025-07-11 - international - T20 - male - 1491607 - Gibraltar vs Bulgaria
2025-07-11 - international - T20 - male - 1491606 - Turkey vs Gibraltar
2025-07-11 - international - T20 - male - 1490480 - Italy vs Netherlands
2025-07-11 - international - T20 - male - 1490479 - Scotland vs Jersey
2025-07-11 - club - WTB - female - 1461033 - Warwickshire vs Somerset
2025-07-11 - club - WTB - female - 1461032 - Surrey vs The Blaze
2025-07-11 - club - WTB - female - 1461031 - Hampshire vs Durham
2025-07-11 - club - NTB - male - 1460857 - Birmingham Bears vs Worcestershire
2025-07-11 - club - NTB - male - 1460856 - Glamorgan vs Surrey
2025-07-11 - club - NTB - male - 1460855 - Durham vs Nottinghamshire
2025-07-11 - club - NTB - male - 1460854 - Northamptonshire vs Derbyshire
2025-07-11 - club - NTB - male - 1460853 - Middlesex vs Gloucestershire
2025-07-11 - club - NTB - male - 1460852 - Yorkshire vs Lancashire
2025-07-11 - club - NTB - male - 1460851 - Kent vs Somerset
2025-07-11 - club - NTB - male - 1460850 - Sussex vs Essex
2025-07-11 - club - MLC - male - 1482024 - Texas Super Kings vs MI New York
2025-07-10 - international - Test - male - 1448351 - England vs India
2025-07-10 - international - T20 - male - 1492888 - Malawi vs Germany
2025-07-10 - international - T20 - male - 1492887 - Tanzania vs Bahrain
2025-07-10 - international - T20 - male - 1491605 - Turkey vs Bulgaria
2025-07-10 - international - T20 - male - 1491604 - Bulgaria vs Gibraltar
2025-07-10 - international - T20 - male - 1490877 - Philippines vs South Korea
2025-07-10 - international - T20 - male - 1490876 - Indonesia vs Philippines
2025-07-10 - international - T20 - male - 1485508 - Bangladesh vs Sri Lanka
2025-07-10 - club - NTB - male - 1460849 - Northamptonshire vs Leicestershire
2025-07-10 - club - NTB - male - 1460848 - Hampshire vs Glamorgan
2025-07-10 - club - NTB - male - 1460847 - Worcestershire vs Derbyshire
2025-07-10 - club - IPT - male - 1478083 - Northern Knights vs Leinster Lightning
2025-07-10 - club - IPT - male - 1478082 - Munster Reds vs North-West Warriors
2025-07-09 - international - T20 - male - 1490875 - South Korea vs Indonesia
2025-07-09 - international - T20 - male - 1490874 - South Korea vs Philippines
2025-07-09 - international - T20 - male - 1490478 - Netherlands vs Guernsey
2025-07-09 - international - T20 - male - 1490477 - Italy vs Scotland
2025-07-09 - international - T20 - female - 1490861 - Turkey vs Greece
2025-07-09 - international - T20 - female - 1490860 - Bulgaria vs Serbia
2025-07-09 - international - T20 - female - 1448400 - England vs India
2025-07-09 - club - WTB - female - 1461030 - Hampshire vs Lancashire
2025-07-09 - club - WTB - female - 1461029 - Warwickshire vs Surrey
2025-07-09 - club - NTB - male - 1460846 - Sussex vs Kent
2025-07-09 - club - NTB - male - 1460845 - Middlesex vs Hampshire
2025-07-09 - club - NTB - male - 1460844 - Surrey vs Gloucestershire
2025-07-09 - club - NTB - male - 1460843 - Birmingham Bears vs Lancashire
2025-07-09 - club - MLC - male - 1482023 - San Francisco Unicorns vs MI New York
2025-07-09 - club - MCL - male - 1490277 - Colts Cricket Club vs Nugegoda Sports Welfare Club
2025-07-09 - club - MCL - male - 1490276 - Bloomfield Cricket and Athletic Club vs Burgher Recreation Club
2025-07-09 - club - MCL - male - 1490275 - Kurunegala Youth Cricket Club vs Moors Sports Club
2025-07-09 - club - MCL - male - 1490274 - Chilaw Marians Cricket Club vs Tamil Union Cricket and Athletic Club
2025-07-09 - club - MCL - male - 1490273 - Badureliya Sports Club vs Police Sports Club
2025-07-09 - club - IPT - male - 1478081 - North-West Warriors vs Leinster Lightning
2025-07-09 - club - IPT - male - 1478080 - Munster Reds vs Northern Knights
2025-07-08 - international - T20 - male - 1492879 - Bahrain vs Tanzania
2025-07-08 - international - T20 - male - 1490873 - Indonesia vs South Korea
2025-07-08 - international - T20 - male - 1490476 - Scotland vs Netherlands
2025-07-08 - international - T20 - male - 1490475 - Jersey vs Guernsey
2025-07-08 - international - T20 - female - 1490859 - Turkey vs Bulgaria
2025-07-08 - international - T20 - female - 1490858 - Serbia vs Greece
2025-07-08 - international - T20 - female - 1490857 - Greece vs Bulgaria
2025-07-08 - international - ODI - male - 1485507 - Sri Lanka vs Bangladesh
2025-07-08 - club - WTB - female - 1461028 - Essex vs Somerset
2025-07-08 - club - NTB - male - 1460842 - Somerset vs Essex
2025-07-08 - club - MCL - male - 1490272 - Panadura Sports Club vs Nondescripts Cricket Club
2025-07-08 - club - IPT - male - 1478079 - Northern Knights vs North-West Warriors
2025-07-08 - club - IPT - male - 1478078 - Munster Reds vs Leinster Lightning
2025-07-07 - international - T20 - male - 1492884 - Malawi vs Bahrain
2025-07-07 - international - T20 - male - 1492883 - Tanzania vs Germany
2025-07-07 - international - T20 - male - 1490872 - Indonesia vs Philippines
2025-07-07 - international - T20 - male - 1490871 - South Korea vs Philippines
2025-07-07 - international - T20 - female - 1490856 - Turkey vs Serbia
2025-07-07 - international - T20 - female - 1490855 - Bulgaria vs Serbia
2025-07-07 - international - T20 - female - 1490854 - Turkey vs Greece
2025-07-06 - international - Test - male - 1478864 - South Africa vs Zimbabwe
2025-07-06 - international - T20 - male - 1492881 - Bahrain vs Germany
2025-07-06 - international - T20 - male - 1490870 - Philippines vs Indonesia
2025-07-06 - club - WTB - female - 1461027 - Surrey vs Essex
2025-07-06 - club - WTB - female - 1461026 - Durham vs The Blaze
2025-07-06 - club - WTB - female - 1461025 - Warwickshire vs Lancashire
2025-07-06 - club - WTB - female - 1461024 - Somerset vs Hampshire
2025-07-06 - club - NTB - male - 1460841 - Surrey vs Essex
2025-07-06 - club - NTB - male - 1460840 - Leicestershire vs Nottinghamshire
2025-07-06 - club - NTB - male - 1460839 - Northamptonshire vs Worcestershire
2025-07-06 - club - NTB - male - 1460838 - Hampshire vs Somerset
2025-07-06 - club - NTB - male - 1460837 - Gloucestershire vs Middlesex
2025-07-06 - club - NTB - male - 1460836 - Kent vs Glamorgan
2025-07-06 - club - NTB - male - 1460835 - Durham vs Birmingham Bears
2025-07-06 - club - NTB - male - 1460834 - Yorkshire vs Derbyshire
2025-07-06 - club - MLC - male - 1482021 - Los Angeles Knight Riders vs San Francisco Unicorns
2025-07-06 - club - MLC - male - 1482020 - MI New York vs Washington Freedom
2025-07-05 - international - T20 - male - 1492880 - Malawi vs Germany
2025-07-05 - international - T20 - male - 1490472 - Guernsey vs Italy
2025-07-05 - international - T20 - male - 1490471 - Jersey vs Netherlands
2025-07-05 - international - T20 - female - 1490227 - Indonesia vs Singapore
2025-07-05 - international - ODI - male - 1485506 - Bangladesh vs Sri Lanka
2025-07-05 - club - WTB - female - 1461023 - Essex vs Lancashire
2025-07-05 - club - NTB - male - 1460833 - Hampshire vs Sussex
2025-07-05 - club - NTB - male - 1460832 - Lancashire vs Derbyshire
2025-07-05 - club - MLC - male - 1482019 - Texas Super Kings vs Seattle Orcas
2025-07-05 - club - MLC - male - 1482018 - MI New York vs Los Angeles Knight Riders
2025-07-05 - club - MCL - male - 1490270 - Colts Cricket Club vs Kurunegala Youth Cricket Club
2025-07-05 - club - MCL - male - 1490269 - Colombo Cricket Club vs Moors Sports Club
2025-07-05 - club - MCL - male - 1490268 - Police Sports Club vs Chilaw Marians Cricket Club
2025-07-05 - club - MCL - male - 1490267 - Panadura Sports Club vs Tamil Union Cricket and Athletic Club
2025-07-05 - club - MCL - male - 1490266 - Ace Capital Cricket Club vs Nondescripts Cricket Club
2025-07-04 - international - T20 - female - 1448399 - England vs India
2025-07-04 - club - WTB - female - 1461022 - The Blaze vs Hampshire
2025-07-04 - club - WTB - female - 1461021 - Durham vs Somerset
2025-07-04 - club - NTB - male - 1460831 - Yorkshire vs Worcestershire
2025-07-04 - club - NTB - male - 1460830 - Glamorgan vs Somerset
2025-07-04 - club - NTB - male - 1460829 - Northamptonshire vs Lancashire
2025-07-04 - club - NTB - male - 1460828 - Leicestershire vs Birmingham Bears
2025-07-04 - club - NTB - male - 1460827 - Sussex vs Kent
2025-07-04 - club - NTB - male - 1460826 - Gloucestershire vs Essex
2025-07-04 - club - NTB - male - 1460825 - Durham vs Nottinghamshire
2025-07-04 - club - MLC - male - 1482017 - Seattle Orcas vs Washington Freedom
2025-07-04 - club - MLC - male - 1482016 - San Francisco Unicorns vs Texas Super Kings
2025-07-03 - international - Test - male - 1472518 - Australia vs West Indies
2025-07-03 - international - T20 - female - 1490226 - Singapore vs Indonesia
2025-07-03 - club - MLC - male - 1482015 - Los Angeles Knight Riders vs MI New York
2025-07-02 - international - Test - male - 1448350 - India vs England
2025-07-02 - international - T20 - female - 1490225 - Singapore vs Indonesia
2025-07-02 - international - ODI - male - 1485505 - Sri Lanka vs Bangladesh
2025-07-02 - club - MLC - male - 1482014 - Texas Super Kings vs Washington Freedom
2025-07-02 - club - IPT - male - 1478075 - Leinster Lightning vs North-West Warriors
2025-07-02 - club - IPT - male - 1478074 - Munster Reds vs Northern Knights
2025-07-01 - international - T20 - female - 1448398 - India vs England
2025-07-01 - club - MLC - male - 1482013 - San Francisco Unicorns vs Seattle Orcas
2025-07-01 - club - MCL - male - 1490265 - Bloomfield Cricket and Athletic Club vs Kurunegala Youth Cricket Club
2025-07-01 - club - MCL - male - 1490264 - Moors Sports Club vs Colts Cricket Club
2025-07-01 - club - MCL - male - 1490263 - Burgher Recreation Club vs Colombo Cricket Club
2025-07-01 - club - MCL - male - 1490262 - Police Sports Club vs Panadura Sports Club
2025-07-01 - club - MCL - male - 1490261 - Tamil Union Cricket and Athletic Club vs Nondescripts Cricket Club
2025-07-01 - club - MCL - male - 1490260 - Badureliya Sports Club vs Ace Capital Cricket Club
2025-07-01 - club - IPT - male - 1478073 - Northern Knights vs Leinster Lightning
2025-07-01 - club - IPT - male - 1478072 - North-West Warriors vs Munster Reds
2025-06-29 - international - T20 - male - 1490890 - Hungary vs France
2025-06-29 - club - MLC - male - 1482012 - Texas Super Kings vs MI New York
2025-06-29 - club - CCH - male - 1461929 - Gloucestershire vs Glamorgan
2025-06-29 - club - CCH - male - 1461928 - Lancashire vs Derbyshire
2025-06-29 - club - CCH - male - 1461927 - Kent vs Northamptonshire
2025-06-29 - club - CCH - male - 1461926 - Middlesex vs Leicestershire
2025-06-29 - club - CCH - male - 1461868 - Warwickshire vs Sussex
2025-06-29 - club - CCH - male - 1461867 - Worcestershire vs Hampshire
2025-06-29 - club - CCH - male - 1461866 - Somerset vs Nottinghamshire
2025-06-29 - club - CCH - male - 1461865 - Surrey vs Durham
2025-06-29 - club - CCH - male - 1461864 - Essex vs Yorkshire
2025-06-28 - international - Test - male - 1478863 - South Africa vs Zimbabwe
2025-06-28 - international - T20 - male - 1490889 - Malta vs Romania
2025-06-28 - international - T20 - male - 1490888 - Belgium vs Austria
2025-06-28 - international - T20 - female - 1448397 - India vs England
2025-06-28 - club - MLC - male - 1482011 - Los Angeles Knight Riders vs Seattle Orcas
2025-06-28 - club - MLC - male - 1482010 - Washington Freedom vs San Francisco Unicorns
2025-06-27 - international - T20 - male - 1490887 - Hungary vs Romania
2025-06-27 - international - T20 - male - 1490886 - Belgium vs France
2025-06-27 - international - T20 - male - 1490885 - Hungary vs Austria
2025-06-27 - club - MLC - male - 1482009 - MI New York vs Seattle Orcas
2025-06-27 - club - MCL - male - 1490259 - Moors Sports Club vs Bloomfield Cricket and Athletic Club
2025-06-27 - club - MCL - male - 1490258 - Nugegoda Sports Welfare Club vs Burgher Recreation Club
2025-06-27 - club - MCL - male - 1490257 - Colts Cricket Club vs Colombo Cricket Club
2025-06-27 - club - MCL - male - 1490256 - Nondescripts Cricket Club vs Police Sports Club
2025-06-27 - club - MCL - male - 1490255 - Chilaw Marians Cricket Club vs Badureliya Sports Club
2025-06-27 - club - MCL - male - 1490254 - Ace Capital Cricket Club vs Tamil Union Cricket and Athletic Club
2025-06-26 - international - T20 - male - 1490884 - Belgium vs Malta
2025-06-26 - international - T20 - male - 1490882 - France vs Malta
2025-06-26 - club - MLC - male - 1482008 - Los Angeles Knight Riders vs Washington Freedom
2025-06-26 - club - IPT - male - 1478071 - Leinster Lightning vs Northern Knights
2025-06-26 - club - IPT - male - 1478070 - North-West Warriors vs Munster Reds
2025-06-25 - international - Test - male - 1485504 - Bangladesh vs Sri Lanka
2025-06-25 - international - Test - male - 1472517 - Australia vs West Indies
2025-06-25 - club - MLC - male - 1482007 - San Francisco Unicorns vs Seattle Orcas
2025-06-25 - club - IPT - male - 1478069 - Northern Knights vs Munster Reds
2025-06-25 - club - IPT - male - 1478068 - North-West Warriors vs Leinster Lightning
2025-06-24 - club - MLC - male - 1482006 - Texas Super Kings vs Los Angeles Knight Riders
2025-06-24 - club - IPT - male - 1478067 - Munster Reds vs Leinster Lightning
2025-06-24 - club - IPT - male - 1478066 - North-West Warriors vs Northern Knights
2025-06-23 - international - T20 - female - 1472539 - South Africa vs West Indies
2025-06-23 - club - MLC - male - 1482005 - San Francisco Unicorns vs MI New York
2025-06-22 - international - T20 - male - 1488336 - Cayman Islands vs Bahamas
2025-06-22 - international - T20 - male - 1487633 - Switzerland vs Luxembourg
2025-06-22 - international - T20 - male - 1486788 - Slovenia vs Hungary
2025-06-22 - international - T20 - female - 1472538 - South Africa vs West Indies
2025-06-22 - club - MLC - male - 1482004 - Texas Super Kings vs Washington Freedom
2025-06-22 - club - MLC - male - 1482003 - Seattle Orcas vs Los Angeles Knight Riders
2025-06-22 - club - CCH - male - 1461925 - Kent vs Lancashire
2025-06-22 - club - CCH - male - 1461924 - Gloucestershire vs Derbyshire
2025-06-22 - club - CCH - male - 1461923 - Glamorgan vs Leicestershire
2025-06-22 - club - CCH - male - 1461922 - Middlesex vs Northamptonshire
2025-06-22 - club - CCH - male - 1461863 - Nottinghamshire vs Yorkshire
2025-06-22 - club - CCH - male - 1461862 - Worcestershire vs Surrey
2025-06-22 - club - CCH - male - 1461861 - Somerset vs Warwickshire
2025-06-22 - club - CCH - male - 1461860 - Essex vs Hampshire
2025-06-22 - club - CCH - male - 1461859 - Sussex vs Durham
2025-06-21 - international - T20 - male - 1488335 - Bermuda vs Cayman Islands
2025-06-21 - international - T20 - male - 1488334 - Bahamas vs Canada
2025-06-21 - international - T20 - male - 1487632 - Switzerland vs Luxembourg
2025-06-21 - international - T20 - male - 1487631 - Switzerland vs Luxembourg
2025-06-21 - international - T20 - male - 1486787 - Hungary vs Slovenia
2025-06-21 - international - T20 - male - 1486786 - Hungary vs Slovenia
2025-06-21 - international - T20 - female - 1489047 - Papua New Guinea vs Samoa
2025-06-21 - club - MLC - male - 1482002 - MI New York vs Washington Freedom
2025-06-20 - international - Test - male - 1448349 - India vs England
2025-06-20 - international - T20 - male - 1485943 - Scotland vs Nepal
2025-06-20 - international - T20 - female - 1489046 - Papua New Guinea vs Vanuatu
2025-06-20 - international - T20 - female - 1472537 - South Africa vs West Indies
2025-06-20 - club - WTB - female - 1461020 - Durham vs Essex
2025-06-20 - club - WTB - female - 1461019 - Warwickshire vs The Blaze
2025-06-20 - club - NTB - male - 1460824 - Surrey vs Middlesex
2025-06-20 - club - NTB - male - 1460823 - Nottinghamshire vs Northamptonshire
2025-06-20 - club - NTB - male - 1460822 - Hampshire vs Gloucestershire
2025-06-20 - club - NTB - male - 1460821 - Glamorgan vs Somerset
2025-06-20 - club - NTB - male - 1460820 - Kent vs Essex
2025-06-20 - club - NTB - male - 1460819 - Durham vs Yorkshire
2025-06-20 - club - NTB - male - 1460818 - Lancashire vs Derbyshire
2025-06-20 - club - NTB - male - 1460817 - Worcestershire vs Birmingham Bears
2025-06-20 - club - MLC - male - 1482001 - Texas Super Kings vs San Francisco Unicorns
2025-06-19 - international - T20 - male - 1488333 - Canada vs Cayman Islands
2025-06-19 - international - T20 - male - 1488332 - Bermuda vs Bahamas
2025-06-19 - international - T20 - male - 1485941 - Netherlands vs Nepal
2025-06-19 - international - T20 - female - 1489045 - Vanuatu vs Samoa
2025-06-19 - club - WTB - female - 1461018 - Hampshire vs Somerset
2025-06-19 - club - WTB - female - 1461017 - Lancashire vs The Blaze
2025-06-19 - club - NTB - male - 1460816 - Somerset vs Hampshire
2025-06-19 - club - NTB - male - 1460815 - Middlesex vs Essex
2025-06-19 - club - NTB - male - 1460814 - Nottinghamshire vs Leicestershire
2025-06-19 - club - IPT - male - 1478065 - Munster Reds vs Leinster Lightning
2025-06-19 - club - IPT - male - 1478064 - Northern Knights vs North-West Warriors
2025-06-18 - international - T20 - male - 1488331 - Bahamas vs Canada
2025-06-18 - international - T20 - male - 1488330 - Cayman Islands vs Bermuda
2025-06-18 - international - T20 - male - 1485942 - Netherlands vs Scotland
2025-06-18 - club - WTB - female - 1461016 - Surrey vs Lancashire
2025-06-18 - club - WTB - female - 1461015 - Essex vs Warwickshire
2025-06-18 - club - NTB - male - 1460813 - Durham vs Worcestershire
2025-06-18 - club - NTB - male - 1460812 - Surrey vs Sussex
2025-06-18 - club - NTB - male - 1460811 - Kent vs Gloucestershire
2025-06-18 - club - MLC - male - 1482000 - Seattle Orcas vs MI New York
2025-06-18 - club - IPT - male - 1478063 - Munster Reds vs Northern Knights
2025-06-18 - club - IPT - male - 1478062 - North-West Warriors vs Leinster Lightning
2025-06-17 - international - Test - male - 1485503 - Bangladesh vs Sri Lanka
2025-06-17 - international - T20 - male - 1485940 - Scotland vs Nepal
2025-06-17 - international - T20 - female - 1489044 - Samoa vs Papua New Guinea
2025-06-17 - international - ODI - female - 1472536 - South Africa vs West Indies
2025-06-17 - club - WTB - female - 1461014 - Hampshire vs Surrey
2025-06-17 - club - NTB - male - 1460810 - Surrey vs Hampshire
2025-06-17 - club - MLC - male - 1481999 - Washington Freedom vs Los Angeles Knight Riders
2025-06-17 - club - IPT - male - 1478061 - Leinster Lightning vs Northern Knights
2025-06-17 - club - IPT - male - 1478060 - North-West Warriors vs Munster Reds
2025-06-16 - international - T20 - male - 1490239 - Cambodia vs Indonesia
2025-06-16 - international - T20 - male - 1488329 - Bahamas vs Bermuda
2025-06-16 - international - T20 - male - 1488328 - Canada vs Cayman Islands
2025-06-16 - international - T20 - male - 1485939 - Netherlands vs Nepal
2025-06-16 - international - T20 - female - 1489043 - Papua New Guinea vs Vanuatu
2025-06-16 - club - MLC - male - 1481998 - Texas Super Kings vs Seattle Orcas
2025-06-15 - international - T20 - male - 1488344 - Finland vs Norway
2025-06-15 - international - T20 - male - 1488343 - Sweden vs Norway
2025-06-15 - international - T20 - male - 1488327 - Cayman Islands vs Bahamas
2025-06-15 - international - T20 - male - 1488326 - Canada vs Bermuda
2025-06-15 - international - T20 - male - 1488325 - Indonesia vs Cambodia
2025-06-15 - international - T20 - male - 1488324 - Indonesia vs Cambodia
2025-06-15 - international - T20 - male - 1485938 - Scotland vs Netherlands
2025-06-15 - international - T20 - male - 1472516 - West Indies vs Ireland
2025-06-15 - international - T20 - female - 1489042 - Vanuatu vs Samoa
2025-06-15 - club - WTB - female - 1461013 - Somerset vs Durham
2025-06-15 - club - WTB - female - 1461012 - Essex vs Surrey
2025-06-15 - club - WTB - female - 1461011 - Warwickshire vs Hampshire
2025-06-15 - club - NTB - male - 1460809 - Yorkshire vs Durham
2025-06-15 - club - NTB - male - 1460808 - Kent vs Somerset
2025-06-15 - club - NTB - male - 1460807 - Worcestershire vs Leicestershire
2025-06-15 - club - NTB - male - 1460806 - Glamorgan vs Gloucestershire
2025-06-15 - club - MLC - male - 1481997 - MI New York vs San Francisco Unicorns
2025-06-15 - club - MLC - male - 1481996 - Texas Super Kings vs Los Angeles Knight Riders
2025-06-15 - club - MCT - male - 1485338 - Panadura Sports Club vs Colombo Cricket Club
2025-06-14 - international - T20 - male - 1488342 - Sweden vs Finland
2025-06-14 - international - T20 - male - 1488341 - Denmark vs Norway
2025-06-14 - international - T20 - male - 1488340 - Denmark vs Sweden
2025-06-14 - international - T20 - male - 1488339 - Finland vs Norway
2025-06-14 - international - T20 - male - 1488323 - Cambodia vs Indonesia
2025-06-14 - international - T20 - male - 1488322 - Cambodia vs Indonesia
2025-06-14 - international - T20 - female - 1487731 - Uganda vs Rwanda
2025-06-14 - international - ODI - female - 1472535 - South Africa vs West Indies
2025-06-14 - club - NTB - male - 1460805 - Sussex vs Glamorgan
2025-06-14 - club - NTB - male - 1460804 - Leicestershire vs Derbyshire
2025-06-14 - club - NTB - male - 1460803 - Birmingham Bears vs Nottinghamshire
2025-06-14 - club - MLC - male - 1481995 - Seattle Orcas vs Washington Freedom
2025-06-14 - club - MLC - male - 1481994 - San Francisco Unicorns vs Los Angeles Knight Riders
2025-06-13 - international - T20 - male - 1489585 - Canada vs Cayman Islands
2025-06-13 - international - T20 - male - 1489584 - Bermuda vs Bahamas
2025-06-13 - international - T20 - male - 1488338 - Denmark vs Finland
2025-06-13 - international - T20 - female - 1487729 - Tanzania vs Rwanda
2025-06-13 - international - T20 - female - 1487661 - Czech Republic vs Austria
2025-06-13 - international - T20 - female - 1487660 - Gibraltar vs Czech Republic
2025-06-13 - international - T20 - female - 1487655 - Netherlands vs United States of America
2025-06-13 - club - WTB - female - 1461010 - Somerset vs Lancashire
2025-06-13 - club - WTB - female - 1461009 - Durham vs The Blaze
2025-06-13 - club - NTB - male - 1460802 - Birmingham Bears vs Yorkshire
2025-06-13 - club - NTB - male - 1460801 - Worcestershire vs Lancashire
2025-06-13 - club - NTB - male - 1460800 - Essex vs Sussex
2025-06-13 - club - NTB - male - 1460799 - Derbyshire vs Nottinghamshire
2025-06-13 - club - NTB - male - 1460798 - Durham vs Northamptonshire
2025-06-13 - club - NTB - male - 1460797 - Hampshire vs Middlesex
2025-06-13 - club - NTB - male - 1460796 - Gloucestershire vs Somerset
2025-06-13 - club - MLC - male - 1481993 - Texas Super Kings vs MI New York
2025-06-13 - club - MCT - male - 1485337 - Moors Sports Club vs Colombo Cricket Club
2025-06-13 - club - MCT - male - 1485336 - Panadura Sports Club vs Nondescripts Cricket Club
2025-06-12 - international - T20 - male - 1489582 - Bermuda vs Cayman Islands
2025-06-12 - international - T20 - male - 1489581 - Canada vs Bahamas
2025-06-12 - international - T20 - male - 1488321 - Indonesia vs Cambodia
2025-06-12 - international - T20 - male - 1488320 - Indonesia vs Cambodia
2025-06-12 - international - T20 - female - 1487728 - Sierra Leone vs Brazil
2025-06-12 - international - T20 - female - 1487726 - Uganda vs Rwanda
2025-06-12 - international - T20 - female - 1487725 - Tanzania vs Cameroon
2025-06-12 - international - T20 - female - 1487658 - Austria vs Gibraltar
2025-06-12 - international - T20 - female - 1487654 - Netherlands vs United States of America
2025-06-12 - international - ODI - male - 1486777 - Scotland vs Netherlands
2025-06-12 - club - WTB - female - 1461008 - Hampshire vs Essex
2025-06-12 - club - NTB - male - 1460795 - Kent vs Surrey
2025-06-12 - club - NTB - male - 1460794 - Middlesex vs Somerset
2025-06-12 - club - NTB - male - 1460793 - Glamorgan vs Essex
2025-06-12 - club - MLC - male - 1481992 - San Francisco Unicorns vs Washington Freedom
2025-06-12 - club - MCT - male - 1485335 - Panadura Sports Club vs Colts Cricket Club
2025-06-12 - club - MCT - male - 1485334 - Moors Sports Club vs Bloomfield Cricket and Athletic Club
2025-06-11 - international - Test - male - 1449769 - Australia vs South Africa
2025-06-11 - international - T20 - male - 1488319 - Indonesia vs Cambodia
2025-06-11 - international - T20 - female - 1487723 - Brazil vs Cameroon
2025-06-11 - international - T20 - female - 1487722 - Rwanda vs Tanzania
2025-06-11 - international - T20 - female - 1487721 - Nigeria vs Uganda
2025-06-11 - international - T20 - female - 1487653 - Netherlands vs United States of America
2025-06-11 - international - ODI - female - 1472534 - South Africa vs West Indies
2025-06-11 - club - WTB - female - 1461007 - The Blaze vs Surrey
2025-06-11 - club - WTB - female - 1461006 - Durham vs Warwickshire
2025-06-11 - club - NTB - male - 1460792 - Yorkshire vs Nottinghamshire
2025-06-11 - club - NTB - male - 1460791 - Northamptonshire vs Birmingham Bears
2025-06-11 - club - NTB - male - 1460790 - Durham vs Derbyshire
2025-06-11 - club - MCT - male - 1485333 - Colombo Cricket Club vs Burgher Recreation Club
2025-06-11 - club - MCT - male - 1485332 - Tamil Union Cricket and Athletic Club vs Nondescripts Cricket Club
2025-06-10 - international - T20 - male - 1483736 - Norway vs Austria
2025-06-10 - international - T20 - male - 1483735 - Norway vs Czech Republic
2025-06-10 - international - T20 - male - 1448348 - England vs West Indies
2025-06-10 - international - T20 - female - 1487720 - Rwanda vs Brazil
2025-06-10 - international - T20 - female - 1487717 - Uganda vs Tanzania
2025-06-10 - international - ODI - male - 1486776 - Nepal vs Netherlands
2025-06-09 - international - T20 - male - 1483734 - Austria vs Czech Republic
2025-06-09 - international - T20 - male - 1483733 - Norway vs Austria
2025-06-09 - international - T20 - female - 1487652 - Netherlands vs United States of America
2025-06-08 - international - T20 - male - 1486791 - Serbia vs Slovenia
2025-06-08 - international - T20 - male - 1483732 - Norway vs Czech Republic
2025-06-08 - international - T20 - male - 1483731 - Czech Republic vs Austria
2025-06-08 - international - T20 - male - 1448347 - West Indies vs England
2025-06-08 - international - T20 - female - 1489041 - Mongolia vs Philippines
2025-06-08 - international - T20 - female - 1487715 - Nigeria vs Sierra Leone
2025-06-08 - international - T20 - female - 1487714 - Brazil vs Tanzania
2025-06-08 - international - T20 - female - 1487713 - Uganda vs Malawi
2025-06-08 - international - T20 - female - 1485415 - Japan vs Hong Kong
2025-06-08 - international - T20 - female - 1485414 - Philippines vs China
2025-06-08 - international - ODI - male - 1486775 - Scotland vs Nepal
2025-06-08 - club - WTB - female - 1461005 - Durham vs Surrey
2025-06-08 - club - WTB - female - 1461004 - Lancashire vs Warwickshire
2025-06-08 - club - NTB - male - 1460789 - Yorkshire vs Leicestershire
2025-06-08 - club - NTB - male - 1460788 - Sussex vs Glamorgan
2025-06-08 - club - NTB - male - 1460787 - Northamptonshire vs Lancashire
2025-06-08 - club - NTB - male - 1460786 - Hampshire vs Kent
2025-06-08 - club - NTB - male - 1460785 - Essex vs Middlesex
2025-06-08 - club - NTB - male - 1460784 - Birmingham Bears vs Derbyshire
2025-06-08 - club - MCT - male - 1485331 - Colts Cricket Club vs Police Sports Club
2025-06-08 - club - MCT - male - 1485330 - Badureliya Sports Club vs Moors Sports Club
2025-06-08 - club - MCT - male - 1485329 - Chilaw Marians Cricket Club vs Burgher Recreation Club
2025-06-08 - club - MCT - male - 1485328 - Bloomfield Cricket and Athletic Club vs Tamil Union Cricket and Athletic Club
2025-06-08 - club - MCT - male - 1485327 - Nondescripts Cricket Club vs Ace Capital Cricket Club
2025-06-08 - club - MCT - male - 1485326 - Panadura Sports Club vs Colombo Cricket Club
2025-06-07 - international - T20 - male - 1487815 - Jersey vs Guernsey
2025-06-07 - international - T20 - male - 1487814 - Guernsey vs Jersey
2025-06-07 - international - T20 - male - 1486790 - Slovenia vs Serbia
2025-06-07 - international - T20 - female - 1487712 - Nigeria vs Cameroon
2025-06-07 - international - T20 - female - 1487710 - Malawi vs Sierra Leone
2025-06-07 - international - T20 - female - 1487709 - Brazil vs Uganda
2025-06-07 - international - T20 - female - 1485413 - Mongolia vs Hong Kong
2025-06-07 - international - T20 - female - 1485412 - Japan vs Philippines
2025-06-07 - international - ODI - female - 1448396 - West Indies vs England
2025-06-07 - club - WTB - female - 1461002 - Lancashire vs Surrey
2025-06-07 - club - WTB - female - 1461001 - Durham vs Hampshire
2025-06-07 - club - NTB - male - 1460783 - Worcestershire vs Nottinghamshire
2025-06-06 - international - T20 - male - 1487813 - Jersey vs Guernsey
2025-06-06 - international - T20 - male - 1448346 - England vs West Indies
2025-06-06 - international - T20 - female - 1487708 - Rwanda vs Nigeria
2025-06-06 - international - T20 - female - 1487707 - Cameroon vs Malawi
2025-06-06 - international - T20 - female - 1487706 - Sierra Leone vs Uganda
2025-06-06 - international - T20 - female - 1485411 - Philippines vs Mongolia
2025-06-06 - international - T20 - female - 1485410 - Japan vs China
2025-06-06 - international - ODI - male - 1486774 - Scotland vs Netherlands
2025-06-06 - club - WTB - female - 1461000 - Essex vs The Blaze
2025-06-06 - club - WTB - female - 1460999 - Warwickshire vs Somerset
2025-06-06 - club - NTB - male - 1460782 - Northamptonshire vs Worcestershire
2025-06-06 - club - NTB - male - 1460781 - Sussex vs Somerset
2025-06-06 - club - NTB - male - 1460780 - Leicestershire vs Durham
2025-06-06 - club - NTB - male - 1460779 - Surrey vs Kent
2025-06-06 - club - NTB - male - 1460778 - Gloucestershire vs Hampshire
2025-06-06 - club - NTB - male - 1460777 - Essex vs Glamorgan
2025-06-06 - club - NTB - male - 1460776 - Derbyshire vs Nottinghamshire
2025-06-06 - club - NTB - male - 1460775 - Yorkshire vs Birmingham Bears
2025-06-06 - club - MCT - male - 1485325 - Nondescripts Cricket Club vs Panadura Sports Club
2025-06-06 - club - MCT - male - 1485324 - Nugegoda Sports Welfare Club vs Colts Cricket Club
2025-06-06 - club - MCT - male - 1485323 - Colombo Cricket Club vs Kurunegala Youth Cricket Club
2025-06-06 - club - MCT - male - 1485322 - Tamil Union Cricket and Athletic Club vs Chilaw Marians Cricket Club
2025-06-06 - club - MCT - male - 1485321 - Badureliya Sports Club vs Ace Capital Cricket Club
2025-06-06 - club - MCT - male - 1485320 - Police Sports Club vs Bloomfield Cricket and Athletic Club
2025-06-05 - international - T20 - female - 1487704 - Tanzania vs Nigeria
2025-06-05 - international - T20 - female - 1487703 - Rwanda vs Malawi
2025-06-05 - international - T20 - female - 1487702 - Cameroon vs Sierra Leone
2025-06-05 - international - T20 - female - 1485409 - Mongolia vs China
2025-06-05 - club - WTB - female - 1460998 - Surrey vs Hampshire
2025-06-05 - club - NTB - male - 1460774 - Surrey vs Hampshire
2025-06-05 - club - NTB - male - 1460773 - Kent vs Middlesex
2025-06-05 - club - MCT - male - 1485319 - Chilaw Marians Cricket Club vs Police Sports Club
2025-06-05 - club - MCT - male - 1485318 - Moors Sports Club vs Nondescripts Cricket Club
2025-06-05 - club - MCT - male - 1485317 - Tamil Union Cricket and Athletic Club vs Nugegoda Sports Welfare Club
2025-06-05 - club - MCT - male - 1485316 - Panadura Sports Club vs Badureliya Sports Club
2025-06-05 - club - MCT - male - 1485315 - Bloomfield Cricket and Athletic Club vs Burgher Recreation Club
2025-06-05 - club - MCT - male - 1485314 - Kurunegala Youth Cricket Club vs Ace Capital Cricket Club
2025-06-04 - international - T20 - female - 1487700 - Tanzania vs Malawi
2025-06-04 - international - T20 - female - 1487699 - Nigeria vs Brazil
2025-06-04 - international - T20 - female - 1487698 - Cameroon vs Uganda
2025-06-04 - international - T20 - female - 1487697 - Rwanda vs Sierra Leone
2025-06-04 - international - T20 - female - 1485407 - Philippines vs China
2025-06-04 - international - T20 - female - 1485406 - Hong Kong vs Japan
2025-06-04 - international - ODI - male - 1486773 - Netherlands vs Nepal
2025-06-04 - international - ODI - female - 1448395 - England vs West Indies
2025-06-04 - club - WTB - female - 1460997 - Lancashire vs Hampshire
2025-06-04 - club - WTB - female - 1460996 - Essex vs Warwickshire
2025-06-04 - club - NTB - male - 1460772 - Lancashire vs Leicestershire
2025-06-04 - club - NTB - male - 1460771 - Northamptonshire vs Derbyshire
2025-06-03 - international - T20 - female - 1487696 - Malawi vs Brazil
2025-06-03 - international - T20 - female - 1487695 - Tanzania vs Sierra Leone
2025-06-03 - international - T20 - female - 1487693 - Rwanda vs Cameroon
2025-06-03 - international - ODI - male - 1448345 - West Indies vs England
2025-06-03 - club - NTB - male - 1460770 - Surrey vs Glamorgan
2025-06-03 - club - IPL - male - 1473511 - Royal Challengers Bengaluru vs Punjab Kings
2025-06-02 - international - ODI - male - 1486772 - Scotland vs Nepal
2025-06-01 - international - T20 - male - 1486785 - Austria vs Switzerland
2025-06-01 - international - T20 - male - 1486224 - Belgium vs Portugal
2025-06-01 - international - T20 - male - 1483787 - Bangladesh vs Pakistan
2025-06-01 - international - ODI - male - 1448344 - West Indies vs England
2025-06-01 - club - WTB - female - 1460995 - Essex vs Somerset
2025-06-01 - club - WTB - female - 1460994 - Lancashire vs Durham
2025-06-01 - club - NTB - male - 1460769 - Sussex vs Gloucestershire
2025-06-01 - club - NTB - male - 1460768 - Leicestershire vs Northamptonshire
2025-06-01 - club - NTB - male - 1460767 - Middlesex vs Glamorgan
2025-06-01 - club - NTB - male - 1460766 - Essex vs Somerset
2025-06-01 - club - NTB - male - 1460765 - Worcestershire vs Yorkshire
2025-06-01 - club - NTB - male - 1460764 - Durham vs Lancashire
2025-06-01 - club - IPL - male - 1473510 - Mumbai Indians vs Punjab Kings
2025-05-31 - international - T20 - male - 1486784 - Austria vs Switzerland
2025-05-31 - international - T20 - male - 1485348 - Belgium vs Malta
2025-05-31 - international - T20 - male - 1485347 - Malta vs Portugal
2025-05-31 - international - T20 - male - 1485344 - Belgium vs Portugal
2025-05-31 - international - T20 - male - 1483789 - Austria vs Switzerland
2025-05-31 - club - WTB - female - 1460993 - Lancashire vs The Blaze
2025-05-31 - club - WTB - female - 1460992 - Warwickshire vs Durham
2025-05-31 - club - NTB - male - 1460763 - Lancashire vs Nottinghamshire
2025-05-31 - club - NTB - male - 1460762 - Birmingham Bears vs Durham
2025-05-30 - international - T20 - male - 1485346 - Malta vs Belgium
2025-05-30 - international - T20 - male - 1485345 - Malta vs Portugal
2025-05-30 - international - T20 - male - 1485343 - Belgium vs Portugal
2025-05-30 - international - T20 - male - 1483788 - Austria vs Switzerland
2025-05-30 - international - T20 - male - 1483786 - Pakistan vs Bangladesh
2025-05-30 - international - ODI - female - 1448394 - England vs West Indies
2025-05-30 - club - WTB - female - 1460991 - Somerset vs Surrey
2025-05-30 - club - WTB - female - 1460990 - Warwickshire vs The Blaze
2025-05-30 - club - WTB - female - 1460989 - Hampshire vs Essex
2025-05-30 - club - NTB - male - 1460761 - Northamptonshire vs Yorkshire
2025-05-30 - club - NTB - male - 1460760 - Surrey vs Somerset
2025-05-30 - club - NTB - male - 1460759 - Birmingham Bears vs Nottinghamshire
2025-05-30 - club - NTB - male - 1460758 - Derbyshire vs Leicestershire
2025-05-30 - club - NTB - male - 1460757 - Hampshire vs Essex
2025-05-30 - club - NTB - male - 1460756 - Kent vs Gloucestershire
2025-05-30 - club - IPL - male - 1473509 - Mumbai Indians vs Gujarat Titans
2025-05-29 - international - T20 - female - 1486102 - Isle of Man vs Germany
2025-05-29 - international - T20 - female - 1486101 - Sweden vs Jersey
2025-05-29 - international - T20 - female - 1486100 - Italy vs Spain
2025-05-29 - international - T20 - female - 1483811 - Switzerland vs Belgium
2025-05-29 - international - T20 - female - 1483810 - Belgium vs Switzerland
2025-05-29 - international - ODI - male - 1448343 - England vs West Indies
2025-05-29 - club - NTB - male - 1460755 - Sussex vs Middlesex
2025-05-29 - club - NTB - male - 1460754 - Lancashire vs Worcestershire
2025-05-29 - club - IPL - male - 1473508 - Punjab Kings vs Royal Challengers Bengaluru
2025-05-28 - international - T20 - male - 1483785 - Pakistan vs Bangladesh
2025-05-28 - international - T20 - female - 1486099 - Jersey vs Isle of Man
2025-05-28 - international - T20 - female - 1486098 - Germany vs Sweden
2025-05-28 - international - T20 - female - 1486097 - Isle of Man vs Spain
2025-05-28 - international - T20 - female - 1486096 - Italy vs Germany
2025-05-28 - international - T20 - female - 1483809 - Belgium vs Switzerland
2025-05-28 - international - T20 - female - 1483808 - Belgium vs Switzerland
2025-05-28 - club - MCT - male - 1485309 - Nugegoda Sports Welfare Club vs Chilaw Marians Cricket Club
2025-05-27 - international - ODI - male - 1482569 - United States of America vs Oman
2025-05-27 - club - IPL - male - 1473507 - Lucknow Super Giants vs Royal Challengers Bengaluru
2025-05-26 - international - T20 - female - 1486095 - Sweden vs Italy
2025-05-26 - international - T20 - female - 1486094 - Spain vs Jersey
2025-05-26 - international - T20 - female - 1486093 - Sweden vs Isle of Man
2025-05-26 - international - T20 - female - 1486092 - Germany vs Jersey
2025-05-26 - international - T20 - female - 1448393 - England vs West Indies
2025-05-26 - club - MCT - male - 1485307 - Tamil Union Cricket and Athletic Club vs Police Sports Club
2025-05-26 - club - MCT - male - 1485306 - Ace Capital Cricket Club vs Panadura Sports Club
2025-05-26 - club - IPL - male - 1473506 - Mumbai Indians vs Punjab Kings
2025-05-25 - international - T20 - female - 1486091 - Germany vs Spain
2025-05-25 - international - T20 - female - 1486090 - Isle of Man vs Italy
2025-05-25 - international - T20 - female - 1486089 - Sweden vs Spain
2025-05-25 - international - T20 - female - 1486088 - Jersey vs Italy
2025-05-25 - international - ODI - male - 1482568 - United States of America vs Canada
2025-05-25 - international - ODI - male - 1472513 - West Indies vs Ireland
2025-05-25 - club - PSL - male - 1475271 - Quetta Gladiators vs Lahore Qalandars
2025-05-25 - club - MCT - male - 1485301 - Kurunegala Youth Cricket Club vs Panadura Sports Club
2025-05-25 - club - MCT - male - 1485300 - Chilaw Marians Cricket Club vs Bloomfield Cricket and Athletic Club
2025-05-25 - club - MCT - male - 1485299 - Badureliya Sports Club vs Nondescripts Cricket Club
2025-05-25 - club - MCT - male - 1485298 - Nugegoda Sports Welfare Club vs Police Sports Club
2025-05-25 - club - MCT - male - 1485297 - Burgher Recreation Club vs Colts Cricket Club
2025-05-25 - club - MCT - male - 1485296 - Moors Sports Club vs Colombo Cricket Club
2025-05-25 - club - IPL - male - 1473505 - Sunrisers Hyderabad vs Kolkata Knight Riders
2025-05-25 - club - IPL - male - 1473504 - Chennai Super Kings vs Gujarat Titans
2025-05-24 - club - IPL - male - 1485779 - Punjab Kings vs Delhi Capitals
2025-05-23 - international - T20 - female - 1448392 - West Indies vs England
2025-05-23 - international - ODI - male - 1482567 - Canada vs Oman
2025-05-23 - international - ODI - male - 1472512 - West Indies vs Ireland
2025-05-23 - club - PSL - male - 1475270 - Lahore Qalandars vs Islamabad United
2025-05-23 - club - IPL - male - 1473503 - Sunrisers Hyderabad vs Royal Challengers Bengaluru
2025-05-23 - club - CCH - male - 1461921 - Derbyshire vs Kent
2025-05-23 - club - CCH - male - 1461920 - Northamptonshire vs Gloucestershire
2025-05-23 - club - CCH - male - 1461919 - Lancashire vs Leicestershire
2025-05-23 - club - CCH - male - 1461918 - Glamorgan vs Middlesex
2025-05-23 - club - CCH - male - 1461858 - Nottinghamshire vs Yorkshire
2025-05-23 - club - CCH - male - 1461857 - Warwickshire vs Worcestershire
2025-05-23 - club - CCH - male - 1461856 - Essex vs Surrey
2025-05-23 - club - CCH - male - 1461855 - Hampshire vs Sussex
2025-05-23 - club - CCH - male - 1461854 - Durham vs Somerset
2025-05-22 - international - Test - male - 1392691 - England vs Zimbabwe
2025-05-22 - club - PSL - male - 1475269 - Karachi Kings vs Lahore Qalandars
2025-05-22 - club - IPL - male - 1473502 - Lucknow Super Giants vs Gujarat Titans
2025-05-21 - international - T20 - male - 1486582 - Bangladesh vs United Arab Emirates
2025-05-21 - international - T20 - female - 1448391 - West Indies vs England
2025-05-21 - international - ODI - male - 1482566 - Oman vs United States of America
2025-05-21 - international - ODI - male - 1472511 - Ireland vs West Indies
2025-05-21 - club - PSL - male - 1475268 - Quetta Gladiators vs Islamabad United
2025-05-21 - club - IPL - male - 1473501 - Mumbai Indians vs Delhi Capitals
2025-05-20 - international - T20 - female - 1485778 - Thailand vs Nepal
2025-05-20 - club - WOD - female - 1462374 - Somerset vs The Blaze
2025-05-20 - club - IPL - male - 1473500 - Chennai Super Kings vs Rajasthan Royals
2025-05-19 - international - T20 - male - 1484052 - Bangladesh vs United Arab Emirates
2025-05-19 - international - T20 - female - 1483779 - United Arab Emirates vs Nepal
2025-05-19 - international - ODI - male - 1482565 - Oman vs Canada
2025-05-19 - club - WOD - female - 1462373 - Lancashire vs Durham
2025-05-19 - club - WOD - female - 1462372 - Warwickshire vs Hampshire
2025-05-19 - club - WOD - female - 1462371 - Surrey vs Essex
2025-05-19 - club - PSL - male - 1475267 - Islamabad United vs Karachi Kings
2025-05-19 - club - IPL - male - 1473499 - Lucknow Super Giants vs Sunrisers Hyderabad
2025-05-18 - international - T20 - male - 1486228 - Austria vs Slovenia
2025-05-18 - international - T20 - male - 1486227 - Slovenia vs Austria
2025-05-18 - international - T20 - female - 1483778 - Thailand vs United Arab Emirates
2025-05-18 - club - PSL - male - 1475266 - Lahore Qalandars vs Peshawar Zalmi
2025-05-18 - club - PSL - male - 1475265 - Multan Sultans vs Quetta Gladiators
2025-05-18 - club - IPL - male - 1473498 - Delhi Capitals vs Gujarat Titans
2025-05-18 - club - IPL - male - 1473497 - Punjab Kings vs Rajasthan Royals
2025-05-17 - international - T20 - male - 1486225 - Austria vs Slovenia
2025-05-17 - international - T20 - male - 1484051 - Bangladesh vs United Arab Emirates
2025-05-17 - international - ODI - male - 1482564 - United States of America vs Canada
2025-05-17 - club - PSL - male - 1475264 - Karachi Kings vs Peshawar Zalmi
2025-05-16 - international - T20 - female - 1483777 - Qatar vs Malaysia
2025-05-16 - international - T20 - female - 1483775 - Kuwait vs Bhutan
2025-05-16 - international - ODI - male - 1481535 - Scotland vs Netherlands
2025-05-16 - club - MCT - male - 1485295 - Tamil Union Cricket and Athletic Club vs Colts Cricket Club
2025-05-16 - club - MCT - male - 1485294 - Kurunegala Youth Cricket Club vs Nondescripts Cricket Club
2025-05-16 - club - MCT - male - 1485293 - Panadura Sports Club vs Moors Sports Club
2025-05-16 - club - MCT - male - 1485292 - Ace Capital Cricket Club vs Colombo Cricket Club
2025-05-16 - club - MCT - male - 1485291 - Nugegoda Sports Welfare Club vs Bloomfield Cricket and Athletic Club
2025-05-16 - club - MCT - male - 1485290 - Burgher Recreation Club vs Police Sports Club
2025-05-16 - club - CCH - male - 1461917 - Northamptonshire vs Glamorgan
2025-05-16 - club - CCH - male - 1461916 - Middlesex vs Leicestershire
2025-05-16 - club - CCH - male - 1461915 - Lancashire vs Derbyshire
2025-05-16 - club - CCH - male - 1461914 - Kent vs Gloucestershire
2025-05-16 - club - CCH - male - 1461853 - Worcestershire vs Essex
2025-05-16 - club - CCH - male - 1461852 - Hampshire vs Warwickshire
2025-05-16 - club - CCH - male - 1461851 - Yorkshire vs Surrey
2025-05-16 - club - CCH - male - 1461850 - Somerset vs Sussex
2025-05-16 - club - CCH - male - 1461849 - Nottinghamshire vs Durham
2025-05-15 - international - T20 - female - 1483773 - Bahrain vs Nepal
2025-05-15 - international - T20 - female - 1483772 - Thailand vs Bhutan
2025-05-15 - international - T20 - female - 1477677 - Bulgaria vs Estonia
2025-05-15 - international - T20 - female - 1477676 - Bulgaria vs Estonia
2025-05-15 - club - IPO - male - 1478053 - Northern Knights vs Munster Reds
2025-05-15 - club - IPO - male - 1478052 - Leinster Lightning vs North-West Warriors
2025-05-14 - international - T20 - male - 1482827 - Japan vs Cook Islands
2025-05-14 - international - ODI - male - 1481534 - United Arab Emirates vs Scotland
2025-05-14 - club - WOD - female - 1462370 - Lancashire vs Warwickshire
2025-05-14 - club - WOD - female - 1462369 - The Blaze vs Surrey
2025-05-14 - club - WOD - female - 1462368 - Essex vs Durham
2025-05-13 - international - T20 - male - 1482826 - Cook Islands vs Japan
2025-05-13 - international - T20 - female - 1483770 - Nepal vs Hong Kong
2025-05-13 - club - WOD - female - 1462367 - Hampshire vs Somerset
2025-05-13 - club - IPO - male - 1478051 - North-West Warriors vs Munster Reds
2025-05-13 - club - IPO - male - 1478050 - Northern Knights vs Leinster Lightning
2025-05-12 - international - T20 - female - 1483767 - Bahrain vs Hong Kong
2025-05-12 - international - T20 - female - 1483766 - Kuwait vs Bhutan
2025-05-12 - international - ODI - male - 1481533 - United Arab Emirates vs Netherlands
2025-05-11 - international - T20 - male - 1482825 - Japan vs Thailand
2025-05-11 - international - T20 - female - 1483073 - Greece vs Germany
2025-05-11 - international - T20 - female - 1483072 - Germany vs Greece
2025-05-11 - international - ODI - female - 1476986 - India vs Sri Lanka
2025-05-11 - club - WOD - female - 1462366 - Surrey vs Somerset
2025-05-11 - club - WOD - female - 1462365 - The Blaze vs Lancashire
2025-05-11 - club - WOD - female - 1462364 - Hampshire vs Essex
2025-05-11 - club - WOD - female - 1462363 - Warwickshire vs Durham
2025-05-10 - international - T20 - female - 1483765 - United Arab Emirates vs Qatar
2025-05-10 - international - T20 - female - 1483763 - Bahrain vs Nepal
2025-05-10 - international - T20 - female - 1483071 - Germany vs Greece
2025-05-10 - international - T20 - female - 1483070 - Germany vs Greece
2025-05-10 - international - ODI - male - 1481532 - Netherlands vs Scotland
2025-05-09 - international - T20 - male - 1482822 - Japan vs Cook Islands
2025-05-09 - international - T20 - male - 1482821 - Cook Islands vs Thailand
2025-05-09 - international - T20 - female - 1483762 - Malaysia vs United Arab Emirates
2025-05-09 - international - T20 - female - 1483760 - Kuwait vs Thailand
2025-05-09 - international - ODI - female - 1476985 - South Africa vs Sri Lanka
2025-05-09 - club - CCH - male - 1461913 - Glamorgan vs Kent
2025-05-09 - club - CCH - male - 1461912 - Northamptonshire vs Lancashire
2025-05-09 - club - CCH - male - 1461848 - Sussex vs Worcestershire
2025-05-09 - club - CCH - male - 1461847 - Nottinghamshire vs Hampshire
2025-05-09 - club - CCH - male - 1461846 - Warwickshire vs Surrey
2025-05-09 - club - CCH - male - 1461845 - Yorkshire vs Essex
2025-05-08 - international - T20 - male - 1482820 - Japan vs Thailand
2025-05-08 - international - ODI - male - 1481531 - United Arab Emirates vs Scotland
2025-05-08 - club - IPL - male - 1473495 - Punjab Kings vs Delhi Capitals
2025-05-07 - international - T20 - male - 1482830 - Malta vs Estonia
2025-05-07 - international - T20 - male - 1482819 - Thailand vs Cook Islands
2025-05-07 - international - ODI - female - 1476984 - India vs South Africa
2025-05-07 - club - WOD - female - 1462362 - Somerset vs Warwickshire
2025-05-07 - club - WOD - female - 1462361 - Surrey vs Lancashire
2025-05-07 - club - WOD - female - 1462360 - Durham vs Hampshire
2025-05-07 - club - PSL - male - 1475263 - Quetta Gladiators vs Islamabad United
2025-05-07 - club - IPO - male - 1478049 - North-West Warriors vs Northern Knights
2025-05-07 - club - IPO - male - 1478048 - Leinster Lightning vs Munster Reds
2025-05-07 - club - IPL - male - 1473494 - Kolkata Knight Riders vs Chennai Super Kings
2025-05-06 - international - T20 - male - 1482829 - Malta vs Estonia
2025-05-06 - international - T20 - male - 1482828 - Malta vs Estonia
2025-05-06 - international - T20 - female - 1483759 - Thailand vs United Arab Emirates
2025-05-06 - international - T20 - female - 1483758 - Hong Kong vs Kuwait
2025-05-06 - international - ODI - male - 1481530 - Netherlands vs United Arab Emirates
2025-05-06 - club - WOD - female - 1462359 - Essex vs The Blaze
2025-05-06 - club - IPL - male - 1473493 - Mumbai Indians vs Gujarat Titans
2025-05-05 - international - T20 - female - 1483943 - Bahrain vs Oman
2025-05-05 - international - T20 - female - 1483069 - Croatia vs Malta
2025-05-05 - international - T20 - female - 1483068 - Croatia vs Malta
2025-05-05 - club - PSL - male - 1475262 - Multan Sultans vs Peshawar Zalmi
2025-05-05 - club - IPL - male - 1473492 - Delhi Capitals vs Sunrisers Hyderabad
2025-05-04 - international - T20 - female - 1483757 - United Arab Emirates vs Kuwait
2025-05-04 - international - T20 - female - 1483756 - Thailand vs Hong Kong
2025-05-04 - international - T20 - female - 1483067 - Czech Republic vs Cyprus
2025-05-04 - international - ODI - male - 1421074 - United Arab Emirates vs Scotland
2025-05-04 - international - ODI - female - 1476983 - India vs Sri Lanka
2025-05-04 - club - WOD - female - 1462358 - Hampshire vs The Blaze
2025-05-04 - club - WOD - female - 1462357 - Surrey vs Warwickshire
2025-05-04 - club - WOD - female - 1462356 - Lancashire vs Essex
2025-05-04 - club - WOD - female - 1462355 - Durham vs Somerset
2025-05-04 - club - PSL - male - 1475261 - Lahore Qalandars vs Karachi Kings
2025-05-04 - club - IPL - male - 1473491 - Punjab Kings vs Lucknow Super Giants
2025-05-04 - club - IPL - male - 1473490 - Kolkata Knight Riders vs Rajasthan Royals
2025-05-03 - international - T20 - female - 1483942 - Oman vs Bahrain
2025-05-03 - international - T20 - female - 1483755 - Kuwait vs Thailand
2025-05-03 - international - T20 - female - 1483754 - United Arab Emirates vs Hong Kong
2025-05-03 - international - T20 - female - 1483066 - Czech Republic vs Cyprus
2025-05-03 - international - T20 - female - 1483065 - Czech Republic vs Cyprus
2025-05-03 - international - ODI - female - 1481713 - Zimbabwe vs United States of America
2025-05-03 - club - PSL - male - 1475260 - Islamabad United vs Quetta Gladiators
2025-05-03 - club - IPL - male - 1473489 - Royal Challengers Bengaluru vs Chennai Super Kings
2025-05-02 - international - T20 - male - 1482101 - Malaysia vs Saudi Arabia
2025-05-02 - international - T20 - male - 1482100 - Singapore vs Thailand
2025-05-02 - international - T20 - female - 1483941 - Bahrain vs Oman
2025-05-02 - international - T20 - female - 1483064 - Cyprus vs Czech Republic
2025-05-02 - international - T20 - female - 1483063 - Cyprus vs Czech Republic
2025-05-02 - international - ODI - female - 1476982 - South Africa vs Sri Lanka
2025-05-02 - club - PSL - male - 1475259 - Islamabad United vs Peshawar Zalmi
2025-05-02 - club - IPL - male - 1473488 - Gujarat Titans vs Sunrisers Hyderabad
2025-05-02 - club - CCH - male - 1461911 - Glamorgan vs Derbyshire
2025-05-02 - club - CCH - male - 1461910 - Lancashire vs Gloucestershire
2025-05-02 - club - CCH - male - 1461909 - Kent vs Middlesex
2025-05-02 - club - CCH - male - 1461908 - Leicestershire vs Northamptonshire
2025-05-02 - club - CCH - male - 1461844 - Essex vs Somerset
2025-05-02 - club - CCH - male - 1461843 - Durham vs Hampshire
2025-05-02 - club - CCH - male - 1461842 - Yorkshire vs Warwickshire
2025-05-01 - international - ODI - female - 1481712 - Zimbabwe vs United States of America
2025-05-01 - club - WOD - female - 1462352 - Essex vs Somerset
2025-05-01 - club - PSL - male - 1475258 - Lahore Qalandars vs Quetta Gladiators
2025-05-01 - club - PSL - male - 1475257 - Karachi Kings vs Multan Sultans
2025-05-01 - club - IPL - male - 1473487 - Mumbai Indians vs Rajasthan Royals
2025-04-30 - international - T20 - male - 1482098 - Malaysia vs Saudi Arabia
2025-04-30 - international - T20 - female - 1477673 - Sierra Leone vs Botswana
2025-04-30 - international - T20 - female - 1477672 - Mozambique vs Eswatini
2025-04-30 - club - WOD - female - 1462354 - The Blaze vs Warwickshire
2025-04-30 - club - WOD - female - 1462353 - Surrey vs Durham
2025-04-30 - club - WOD - female - 1462351 - Lancashire vs Hampshire
2025-04-30 - club - PSL - male - 1475256 - Lahore Qalandars vs Islamabad United
2025-04-30 - club - IPL - male - 1473486 - Chennai Super Kings vs Punjab Kings
2025-04-29 - international - T20 - male - 1482097 - Singapore vs Saudi Arabia
2025-04-29 - international - T20 - male - 1482096 - Malaysia vs Thailand
2025-04-29 - international - T20 - female - 1481711 - Zimbabwe vs United States of America
2025-04-29 - international - T20 - female - 1477675 - Mozambique vs Eswatini
2025-04-29 - international - T20 - female - 1477674 - Botswana vs Sierra Leone
2025-04-29 - international - T20 - female - 1477666 - Mozambique vs Sierra Leone
2025-04-29 - international - T20 - female - 1477664 - Eswatini vs Botswana
2025-04-29 - international - ODI - female - 1476981 - India vs South Africa
2025-04-29 - club - PSL - male - 1475255 - Multan Sultans vs Quetta Gladiators
2025-04-29 - club - IPL - male - 1473485 - Kolkata Knight Riders vs Delhi Capitals
2025-04-28 - international - Test - male - 1476410 - Zimbabwe vs Bangladesh
2025-04-28 - international - T20 - male - 1482095 - Singapore vs Malaysia
2025-04-28 - international - T20 - male - 1482094 - Saudi Arabia vs Thailand
2025-04-28 - club - IPL - male - 1473484 - Gujarat Titans vs Rajasthan Royals
2025-04-27 - international - T20 - male - 1481315 - Canada vs United States of America
2025-04-27 - international - T20 - female - 1481710 - Zimbabwe vs United States of America
2025-04-27 - international - T20 - female - 1477670 - Botswana vs Mozambique
2025-04-27 - international - T20 - female - 1477669 - Sierra Leone vs Eswatini
2025-04-27 - international - T20 - female - 1477668 - Sierra Leone vs Botswana
2025-04-27 - international - T20 - female - 1477667 - Mozambique vs Eswatini
2025-04-27 - international - ODI - female - 1476980 - Sri Lanka vs India
2025-04-27 - club - WOD - female - 1462350 - Somerset vs Lancashire
2025-04-27 - club - WOD - female - 1462349 - Hampshire vs Surrey
2025-04-27 - club - WOD - female - 1462348 - Warwickshire vs Essex
2025-04-27 - club - WOD - female - 1462347 - Durham vs The Blaze
2025-04-27 - club - PSL - male - 1475254 - Quetta Gladiators vs Peshawar Zalmi
2025-04-27 - club - IPL - male - 1473483 - Delhi Capitals vs Royal Challengers Bengaluru
2025-04-27 - club - IPL - male - 1473482 - Mumbai Indians vs Lucknow Super Giants
2025-04-26 - international - T20 - male - 1482093 - Singapore vs Thailand
2025-04-26 - international - T20 - male - 1482092 - Saudi Arabia vs Malaysia
2025-04-26 - international - T20 - male - 1481314 - Bermuda vs United States of America
2025-04-26 - international - T20 - male - 1481313 - Cayman Islands vs Canada
2025-04-26 - international - T20 - female - 1477671 - Eswatini vs Sierra Leone
2025-04-26 - international - T20 - female - 1477665 - Botswana vs Mozambique
2025-04-26 - international - T20 - female - 1477663 - Mozambique vs Sierra Leone
2025-04-26 - international - T20 - female - 1477662 - Botswana vs Eswatini
2025-04-26 - club - PSL - male - 1475253 - Multan Sultans vs Lahore Qalandars
2025-04-26 - club - IPL - male - 1473481 - Punjab Kings vs Kolkata Knight Riders
2025-04-25 - international - T20 - male - 1482091 - Saudi Arabia vs Singapore
2025-04-25 - international - T20 - male - 1482090 - Thailand vs Malaysia
2025-04-25 - international - T20 - female - 1481709 - Zimbabwe vs United States of America
2025-04-25 - club - PSL - male - 1475252 - Quetta Gladiators vs Karachi Kings
2025-04-25 - club - IPL - male - 1473480 - Chennai Super Kings vs Sunrisers Hyderabad
2025-04-25 - club - CCH - male - 1461907 - Derbyshire vs Middlesex
2025-04-25 - club - CCH - male - 1461906 - Gloucestershire vs Leicestershire
2025-04-25 - club - CCH - male - 1461841 - Worcestershire vs Durham
2025-04-25 - club - CCH - male - 1461840 - Somerset vs Surrey
2025-04-25 - club - CCH - male - 1461839 - Sussex vs Nottinghamshire
2025-04-24 - international - T20 - male - 1482089 - Malaysia vs Singapore
2025-04-24 - international - T20 - male - 1482088 - Saudi Arabia vs Thailand
2025-04-24 - international - T20 - male - 1481312 - Canada vs United States of America
2025-04-24 - international - T20 - male - 1481311 - Cayman Islands vs Bahamas
2025-04-24 - club - PSL - male - 1475251 - Lahore Qalandars vs Peshawar Zalmi
2025-04-24 - club - IPL - male - 1473479 - Royal Challengers Bengaluru vs Rajasthan Royals
2025-04-23 - international - T20 - male - 1481310 - Bahamas vs Bermuda
2025-04-23 - international - T20 - male - 1481309 - Canada vs Cayman Islands
2025-04-23 - club - WOD - female - 1462346 - Hampshire vs Warwickshire
2025-04-23 - club - WOD - female - 1462345 - The Blaze vs Lancashire
2025-04-23 - club - WOD - female - 1462344 - Surrey vs Somerset
2025-04-23 - club - WOD - female - 1462343 - Essex vs Durham
2025-04-23 - club - PSL - male - 1475250 - Multan Sultans vs Islamabad United
2025-04-23 - club - IPL - male - 1473478 - Sunrisers Hyderabad vs Mumbai Indians
2025-04-22 - club - PSL - male - 1475249 - Multan Sultans vs Lahore Qalandars
2025-04-22 - club - IPL - male - 1473477 - Lucknow Super Giants vs Delhi Capitals
2025-04-21 - international - T20 - male - 1481308 - Bermuda vs United States of America
2025-04-21 - international - T20 - male - 1481307 - Bahamas vs Canada
2025-04-21 - club - PSL - male - 1475248 - Peshawar Zalmi vs Karachi Kings
2025-04-21 - club - IPL - male - 1473476 - Gujarat Titans vs Kolkata Knight Riders
2025-04-20 - international - Test - male - 1476409 - Bangladesh vs Zimbabwe
2025-04-20 - international - T20 - male - 1481306 - Bermuda vs Cayman Islands
2025-04-20 - international - T20 - male - 1481305 - United States of America vs Bahamas
2025-04-20 - international - T20 - male - 1481301 - Turks and Caicos Island vs Costa Rica
2025-04-20 - club - PSL - male - 1475247 - Karachi Kings vs Islamabad United
2025-04-20 - club - IPL - male - 1473475 - Chennai Super Kings vs Mumbai Indians
2025-04-20 - club - IPL - male - 1473474 - Punjab Kings vs Royal Challengers Bengaluru
2025-04-19 - international - T20 - male - 1481304 - Bermuda vs Canada
2025-04-19 - international - T20 - male - 1481303 - United States of America vs Cayman Islands
2025-04-19 - international - T20 - male - 1481300 - Panama vs Mexico
2025-04-19 - international - T20 - male - 1481299 - Costa Rica vs Turks and Caicos Island
2025-04-19 - international - ODI - female - 1477023 - Thailand vs West Indies
2025-04-19 - international - ODI - female - 1477022 - Bangladesh vs Pakistan
2025-04-19 - club - PSL - male - 1475246 - Peshawar Zalmi vs Multan Sultans
2025-04-19 - club - IPL - male - 1473473 - Lucknow Super Giants vs Rajasthan Royals
2025-04-19 - club - IPL - male - 1473472 - Delhi Capitals vs Gujarat Titans
2025-04-18 - international - T20 - male - 1481298 - Turks and Caicos Island vs Mexico
2025-04-18 - international - T20 - male - 1481297 - Costa Rica vs Panama
2025-04-18 - international - ODI - female - 1477021 - Scotland vs Ireland
2025-04-18 - club - PSL - male - 1475245 - Karachi Kings vs Quetta Gladiators
2025-04-18 - club - IPL - male - 1473471 - Royal Challengers Bengaluru vs Punjab Kings
2025-04-18 - club - CCH - male - 1461905 - Derbyshire vs Northamptonshire
2025-04-18 - club - CCH - male - 1461904 - Gloucestershire vs Kent
2025-04-18 - club - CCH - male - 1461903 - Glamorgan vs Middlesex
2025-04-18 - club - CCH - male - 1461902 - Lancashire vs Leicestershire
2025-04-18 - club - CCH - male - 1461838 - Warwickshire vs Nottinghamshire
2025-04-18 - club - CCH - male - 1461837 - Somerset vs Hampshire
2025-04-18 - club - CCH - male - 1461836 - Essex vs Worcestershire
2025-04-18 - club - CCH - male - 1461835 - Yorkshire vs Durham
2025-04-18 - club - CCH - male - 1461834 - Sussex vs Surrey
2025-04-17 - international - T20 - male - 1481296 - Panama vs Turks and Caicos Island
2025-04-17 - international - T20 - male - 1481295 - Mexico vs Costa Rica
2025-04-17 - international - ODI - female - 1477020 - Pakistan vs Thailand
2025-04-17 - international - ODI - female - 1477019 - Bangladesh vs West Indies
2025-04-17 - club - IPL - male - 1473470 - Sunrisers Hyderabad vs Mumbai Indians
2025-04-16 - club - PSL - male - 1475244 - Islamabad United vs Multan Sultans
2025-04-16 - club - IPL - male - 1473469 - Delhi Capitals vs Rajasthan Royals
2025-04-15 - international - T20 - female - 1479934 - Namibia vs Uganda
2025-04-15 - international - ODI - female - 1477018 - Bangladesh vs Scotland
2025-04-15 - international - ODI - female - 1477017 - Ireland vs Thailand
2025-04-15 - club - PSL - male - 1475243 - Lahore Qalandars vs Karachi Kings
2025-04-15 - club - IPL - male - 1473468 - Punjab Kings vs Kolkata Knight Riders
2025-04-14 - international - T20 - female - 1479933 - Namibia vs Uganda
2025-04-14 - international - ODI - female - 1477016 - Pakistan vs West Indies
2025-04-14 - club - PSL - male - 1475242 - Islamabad United vs Peshawar Zalmi
2025-04-14 - club - IPL - male - 1473467 - Lucknow Super Giants vs Chennai Super Kings
2025-04-13 - international - T20 - male - 1479327 - Kuwait vs Nepal
2025-04-13 - international - T20 - male - 1479326 - Hong Kong vs Qatar
2025-04-13 - international - ODI - female - 1477015 - Ireland vs Bangladesh
2025-04-13 - international - ODI - female - 1477014 - Scotland vs Thailand
2025-04-13 - club - PSL - male - 1475241 - Lahore Qalandars vs Quetta Gladiators
2025-04-13 - club - IPL - male - 1473466 - Mumbai Indians vs Delhi Capitals
2025-04-13 - club - IPL - male - 1473465 - Rajasthan Royals vs Royal Challengers Bengaluru
2025-04-12 - international - T20 - male - 1479325 - Hong Kong vs Nepal
2025-04-12 - international - T20 - male - 1479324 - Qatar vs Kuwait
2025-04-12 - international - T20 - female - 1479932 - Namibia vs Uganda
2025-04-12 - international - T20 - female - 1477682 - Cook Islands vs Indonesia
2025-04-12 - club - PSL - male - 1475240 - Multan Sultans vs Karachi Kings
2025-04-12 - club - PSL - male - 1475239 - Quetta Gladiators vs Peshawar Zalmi
2025-04-12 - club - IPL - male - 1473464 - Punjab Kings vs Sunrisers Hyderabad
2025-04-12 - club - IPL - male - 1473463 - Gujarat Titans vs Lucknow Super Giants
2025-04-11 - international - T20 - female - 1479931 - Namibia vs Uganda
2025-04-11 - international - T20 - female - 1477681 - Cook Islands vs Philippines
2025-04-11 - international - ODI - female - 1477013 - West Indies vs Ireland
2025-04-11 - international - ODI - female - 1477012 - Scotland vs Pakistan
2025-04-11 - club - PSL - male - 1475238 - Lahore Qalandars vs Islamabad United
2025-04-11 - club - IPL - male - 1473462 - Chennai Super Kings vs Kolkata Knight Riders
2025-04-11 - club - CCH - male - 1461901 - Gloucestershire vs Glamorgan
2025-04-11 - club - CCH - male - 1461900 - Leicestershire vs Derbyshire
2025-04-11 - club - CCH - male - 1461899 - Northamptonshire vs Lancashire
2025-04-11 - club - CCH - male - 1461898 - Middlesex vs Kent
2025-04-11 - club - CCH - male - 1461833 - Yorkshire vs Worcestershire
2025-04-11 - club - CCH - male - 1461832 - Sussex vs Somerset
2025-04-11 - club - CCH - male - 1461831 - Surrey vs Hampshire
2025-04-11 - club - CCH - male - 1461830 - Nottinghamshire vs Essex
2025-04-11 - club - CCH - male - 1461829 - Durham vs Warwickshire
2025-04-10 - international - T20 - male - 1479323 - Hong Kong vs Qatar
2025-04-10 - international - T20 - male - 1479322 - Kuwait vs Nepal
2025-04-10 - international - T20 - female - 1477680 - Indonesia vs Philippines
2025-04-10 - international - ODI - female - 1477011 - Bangladesh vs Thailand
2025-04-10 - club - IPL - male - 1473461 - Royal Challengers Bengaluru vs Delhi Capitals
2025-04-09 - international - T20 - male - 1479321 - Hong Kong vs Kuwait
2025-04-09 - international - T20 - male - 1479320 - Qatar vs Nepal
2025-04-09 - international - T20 - male - 1478230 - Portugal vs Norway
2025-04-09 - international - T20 - female - 1479930 - Uganda vs Namibia
2025-04-09 - international - T20 - female - 1478413 - Norway vs Portugal
2025-04-09 - international - T20 - female - 1477679 - Cook Islands vs Indonesia
2025-04-09 - international - ODI - female - 1477010 - Scotland vs West Indies
2025-04-09 - international - ODI - female - 1477009 - Pakistan vs Ireland
2025-04-09 - club - IPL - male - 1473460 - Gujarat Titans vs Rajasthan Royals
2025-04-08 - international - T20 - male - 1478229 - Norway vs Portugal
2025-04-08 - international - T20 - female - 1479929 - Uganda vs Namibia
2025-04-08 - international - T20 - female - 1478412 - Portugal vs Norway
2025-04-08 - club - IPL - male - 1473459 - Punjab Kings vs Chennai Super Kings
2025-04-08 - club - IPL - male - 1473456 - Lucknow Super Giants vs Kolkata Knight Riders
2025-04-07 - international - T20 - male - 1478228 - Norway vs Portugal
2025-04-07 - international - T20 - female - 1478411 - Portugal vs Norway
2025-04-07 - club - IPL - male - 1473458 - Royal Challengers Bengaluru vs Mumbai Indians
2025-04-06 - club - IPL - male - 1473457 - Sunrisers Hyderabad vs Gujarat Titans
2025-04-05 - international - ODI - male - 1443556 - New Zealand vs Pakistan
2025-04-05 - club - IPL - male - 1473455 - Rajasthan Royals vs Punjab Kings
2025-04-05 - club - IPL - male - 1473454 - Delhi Capitals vs Chennai Super Kings
2025-04-04 - club - IPL - male - 1473453 - Lucknow Super Giants vs Mumbai Indians
2025-04-04 - club - CCH - male - 1461897 - Glamorgan vs Leicestershire
2025-04-04 - club - CCH - male - 1461896 - Middlesex vs Lancashire
2025-04-04 - club - CCH - male - 1461895 - Gloucestershire vs Derbyshire
2025-04-04 - club - CCH - male - 1461894 - Kent vs Northamptonshire
2025-04-04 - club - CCH - male - 1461828 - Durham vs Nottinghamshire
2025-04-04 - club - CCH - male - 1461827 - Sussex vs Warwickshire
2025-04-04 - club - CCH - male - 1461826 - Worcestershire vs Somerset
2025-04-04 - club - CCH - male - 1461825 - Yorkshire vs Hampshire
2025-04-04 - club - CCH - male - 1461824 - Essex vs Surrey
2025-04-03 - club - IPL - male - 1473452 - Kolkata Knight Riders vs Sunrisers Hyderabad
2025-04-02 - international - ODI - male - 1443555 - New Zealand vs Pakistan
2025-04-02 - club - IPL - male - 1473451 - Royal Challengers Bengaluru vs Gujarat Titans
2025-04-01 - club - IPL - male - 1473450 - Lucknow Super Giants vs Punjab Kings
2025-03-31 - club - IPL - male - 1473449 - Kolkata Knight Riders vs Mumbai Indians
2025-03-30 - club - IPL - male - 1473448 - Rajasthan Royals vs Chennai Super Kings
2025-03-30 - club - IPL - male - 1473447 - Sunrisers Hyderabad vs Delhi Capitals
2025-03-29 - international - ODI - male - 1443554 - New Zealand vs Pakistan
2025-03-29 - club - PKS - male - 1452160 - Northern Districts vs Otago Volts
2025-03-29 - club - PKS - male - 1452159 - Wellington Firebirds vs Canterbury
2025-03-29 - club - PKS - male - 1452158 - Auckland Aces vs Central Stags
2025-03-29 - club - IPL - male - 1473446 - Gujarat Titans vs Mumbai Indians
2025-03-28 - club - IPL - male - 1473445 - Royal Challengers Bengaluru vs Chennai Super Kings
2025-03-27 - club - IPL - male - 1473444 - Sunrisers Hyderabad vs Lucknow Super Giants
2025-03-26 - international - T20 - male - 1443553 - Pakistan vs New Zealand
2025-03-26 - international - T20 - female - 1443576 - Australia vs New Zealand
2025-03-26 - club - SSH - male - 1444522 - Queensland vs South Australia
2025-03-26 - club - IPL - male - 1473443 - Rajasthan Royals vs Kolkata Knight Riders
2025-03-25 - club - IPL - male - 1473442 - Punjab Kings vs Gujarat Titans
2025-03-24 - club - IPL - male - 1473441 - Lucknow Super Giants vs Delhi Capitals
2025-03-23 - international - T20 - male - 1476798 - Canada vs Namibia
2025-03-23 - international - T20 - male - 1443552 - New Zealand vs Pakistan
2025-03-23 - international - T20 - female - 1443575 - Australia vs New Zealand
2025-03-23 - club - IPL - male - 1473440 - Mumbai Indians vs Chennai Super Kings
2025-03-23 - club - IPL - male - 1473439 - Sunrisers Hyderabad vs Rajasthan Royals
2025-03-22 - international - T20 - male - 1476797 - Canada vs Namibia
2025-03-22 - club - IPL - male - 1473438 - Kolkata Knight Riders vs Royal Challengers Bengaluru
2025-03-21 - international - T20 - male - 1443551 - New Zealand vs Pakistan
2025-03-21 - international - T20 - female - 1443574 - New Zealand vs Australia
2025-03-21 - club - PKS - male - 1452157 - Otago Volts vs Auckland Aces
2025-03-21 - club - PKS - male - 1452156 - Central Stags vs Canterbury
2025-03-21 - club - PKS - male - 1452155 - Northern Districts vs Wellington Firebirds
2025-03-19 - international - T20 - male - 1476795 - Canada vs Namibia
2025-03-18 - international - T20 - male - 1443550 - Pakistan vs New Zealand
2025-03-18 - international - T20 - female - 1443573 - New Zealand vs Sri Lanka
2025-03-17 - international - T20 - male - 1475531 - Hong Kong vs Bahrain
2025-03-17 - international - T20 - female - 1474992 - United States of America vs Canada
2025-03-17 - international - T20 - female - 1474991 - Argentina vs Brazil
2025-03-16 - international - T20 - male - 1443549 - Pakistan vs New Zealand
2025-03-16 - international - T20 - female - 1476165 - Namibia vs Uganda
2025-03-16 - international - T20 - female - 1474990 - Argentina vs United States of America
2025-03-16 - international - T20 - female - 1443572 - Sri Lanka vs New Zealand
2025-03-15 - international - T20 - male - 1475530 - Malaysia vs Hong Kong
2025-03-15 - international - ODI - male - 1474414 - Namibia vs Canada
2025-03-15 - club - WPL - female - 1469319 - Mumbai Indians vs Delhi Capitals
2025-03-15 - club - SSH - male - 1444521 - Victoria vs Western Australia
2025-03-15 - club - SSH - male - 1444520 - South Australia vs Queensland
2025-03-15 - club - SSH - male - 1444519 - Tasmania vs New South Wales
2025-03-14 - international - T20 - male - 1475529 - Hong Kong vs Bahrain
2025-03-14 - international - T20 - female - 1476163 - Uganda vs Namibia
2025-03-14 - international - T20 - female - 1476162 - Hong Kong vs Nepal
2025-03-14 - international - T20 - female - 1474988 - United States of America vs Brazil
2025-03-14 - international - T20 - female - 1474987 - Canada vs Argentina
2025-03-14 - international - T20 - female - 1474429 - Vanuatu vs Samoa
2025-03-14 - international - T20 - female - 1443571 - New Zealand vs Sri Lanka
2025-03-13 - international - T20 - male - 1475528 - Bahrain vs Malaysia
2025-03-13 - international - T20 - female - 1476161 - Uganda vs Nepal
2025-03-13 - international - T20 - female - 1476160 - Hong Kong vs Namibia
2025-03-13 - international - T20 - female - 1474986 - Brazil vs Canada
2025-03-13 - international - T20 - female - 1474985 - United States of America vs Argentina
2025-03-13 - international - T20 - female - 1474422 - Fiji vs France
2025-03-13 - international - ODI - male - 1474413 - Namibia vs Netherlands
2025-03-13 - club - WPL - female - 1469318 - Mumbai Indians vs Gujarat Giants
2025-03-13 - club - PKS - male - 1452154 - Otago Volts vs Central Stags
2025-03-13 - club - PKS - male - 1452153 - Wellington Firebirds vs Canterbury
2025-03-13 - club - PKS - male - 1452152 - Auckland Aces vs Northern Districts
2025-03-12 - international - T20 - male - 1475527 - Hong Kong vs Malaysia
2025-03-12 - international - T20 - female - 1476159 - Uganda vs Hong Kong
2025-03-12 - international - T20 - female - 1476158 - Namibia vs Nepal
2025-03-12 - international - T20 - female - 1474427 - Vanuatu vs Fiji
2025-03-12 - international - T20 - female - 1474426 - France vs Samoa
2025-03-11 - international - T20 - male - 1475526 - Hong Kong vs Bahrain
2025-03-11 - international - T20 - female - 1474984 - Argentina vs Canada
2025-03-11 - international - T20 - female - 1474983 - United States of America vs Brazil
2025-03-11 - international - T20 - female - 1474424 - Vanuatu vs France
2025-03-11 - club - WPL - female - 1469317 - Royal Challengers Bengaluru vs Mumbai Indians
2025-03-10 - international - T20 - male - 1475525 - Malaysia vs Bahrain
2025-03-10 - international - T20 - female - 1476157 - Hong Kong vs Nepal
2025-03-10 - international - T20 - female - 1476156 - Uganda vs Namibia
2025-03-10 - international - T20 - female - 1474982 - Brazil vs Argentina
2025-03-10 - international - T20 - female - 1474981 - Canada vs United States of America
2025-03-10 - international - T20 - female - 1474423 - Vanuatu vs Samoa
2025-03-10 - club - WPL - female - 1469316 - Mumbai Indians vs Gujarat Giants
2025-03-09 - international - T20 - female - 1476155 - Namibia vs Hong Kong
2025-03-09 - international - T20 - female - 1476154 - Uganda vs Nepal
2025-03-09 - international - ODI - male - 1474411 - Canada vs Namibia
2025-03-09 - international - ODI - male - 1466428 - New Zealand vs India
2025-03-09 - international - ODI - female - 1443570 - New Zealand vs Sri Lanka
2025-03-08 - international - T20 - female - 1476153 - Nepal vs Namibia
2025-03-08 - international - T20 - female - 1476152 - Hong Kong vs Uganda
2025-03-08 - club - WPL - female - 1469315 - UP Warriorz vs Royal Challengers Bengaluru
2025-03-07 - international - ODI - male - 1474410 - Netherlands vs Namibia
2025-03-07 - international - ODI - female - 1443569 - New Zealand vs Sri Lanka
2025-03-07 - club - WPL - female - 1469314 - Delhi Capitals vs Gujarat Giants
2025-03-06 - club - WPL - female - 1469313 - UP Warriorz vs Mumbai Indians
2025-03-06 - club - SSH - male - 1444518 - Western Australia vs New South Wales
2025-03-06 - club - SSH - male - 1444517 - Queensland vs Tasmania
2025-03-06 - club - SSH - male - 1444516 - Victoria vs South Australia
2025-03-05 - international - ODI - male - 1466427 - New Zealand vs South Africa
2025-03-05 - club - PKS - male - 1452151 - Wellington Firebirds vs Otago Volts
2025-03-05 - club - PKS - male - 1452150 - Northern Districts vs Canterbury
2025-03-05 - club - PKS - male - 1452149 - Central Stags vs Auckland Aces
2025-03-05 - club - MLT - male - 1465865 - Bloomfield Cricket and Athletic Club vs Nondescripts Cricket Club
2025-03-04 - international - T20 - male - 1474263 - Singapore vs Bahrain
2025-03-04 - international - ODI - male - 1466426 - Australia vs India
2025-03-04 - international - ODI - female - 1443568 - Sri Lanka vs New Zealand
2025-03-03 - club - WPL - female - 1469312 - Gujarat Giants vs UP Warriorz
2025-03-02 - international - T20 - male - 1474262 - Singapore vs Bahrain
2025-03-02 - international - ODI - male - 1466425 - India vs New Zealand
2025-03-01 - international - T20 - male - 1474261 - Singapore vs Bahrain
2025-03-01 - international - ODI - male - 1466424 - England vs South Africa
2025-03-01 - club - WPL - female - 1469311 - Royal Challengers Bengaluru vs Delhi Capitals
2025-03-01 - club - ODC - male - 1444491 - South Australia vs Victoria
2025-02-28 - international - T20 - male - 1474260 - Bahrain vs Singapore
2025-02-28 - club - WPL - female - 1469310 - Mumbai Indians vs Delhi Capitals
2025-02-28 - club - MLT - male - 1465860 - Negombo Cricket Club vs Ragama Cricket Club
2025-02-28 - club - MLT - male - 1465859 - Badureliya Sports Club vs Bloomfield Cricket and Athletic Club
2025-02-28 - club - MLT - male - 1465858 - Chilaw Marians Cricket Club vs Colts Cricket Club
2025-02-28 - club - MLT - male - 1465857 - Panadura Sports Club vs Ace Capital Cricket Club
2025-02-27 - club - WPL - female - 1469309 - Royal Challengers Bengaluru vs Gujarat Giants
2025-02-26 - club - WPL - female - 1469308 - UP Warriorz vs Mumbai Indians
2025-02-25 - international - T20 - male - 1467706 - Zimbabwe vs Ireland
2025-02-25 - club - WPL - female - 1469307 - Gujarat Giants vs Delhi Capitals
2025-02-24 - international - T20 - male - 1471826 - Indonesia vs Bahrain
2025-02-24 - international - ODI - male - 1466419 - Bangladesh vs New Zealand
2025-02-24 - club - WPL - female - 1469306 - Royal Challengers Bengaluru vs UP Warriorz
2025-02-23 - international - T20 - male - 1473147 - Oman vs United States of America
2025-02-23 - international - T20 - male - 1471825 - Bahrain vs Indonesia
2025-02-23 - international - T20 - male - 1467705 - Ireland vs Zimbabwe
2025-02-23 - international - ODI - male - 1466418 - Pakistan vs India
2025-02-23 - club - ODC - male - 1444490 - Queensland vs Western Australia
2025-02-23 - club - ODC - male - 1444489 - South Australia vs Tasmania
2025-02-23 - club - ODC - male - 1444488 - New South Wales vs Victoria
2025-02-23 - club - MLT - male - 1465852 - Negombo Cricket Club vs Badureliya Sports Club
2025-02-22 - international - T20 - male - 1471824 - Bahrain vs Indonesia
2025-02-22 - international - T20 - male - 1467704 - Zimbabwe vs Ireland
2025-02-22 - international - ODI - male - 1466417 - England vs Australia
2025-02-22 - club - WPL - female - 1469305 - UP Warriorz vs Delhi Capitals
2025-02-21 - international - T20 - male - 1473146 - Oman vs United States of America
2025-02-21 - club - WPL - female - 1469304 - Royal Challengers Bengaluru vs Mumbai Indians
2025-02-21 - club - MLT - male - 1465864 - Colombo Cricket Club vs Burgher Recreation Club
2025-02-21 - club - MLT - male - 1465863 - Kandy Customs Cricket Club vs Moors Sports Club
2025-02-21 - club - MLT - male - 1465862 - Nugegoda Sports Welfare Club vs Tamil Union Cricket and Athletic Club
2025-02-20 - international - T20 - male - 1473145 - Oman vs United States of America
2025-02-20 - international - T20 - male - 1471823 - Indonesia vs Bahrain
2025-02-20 - international - ODI - male - 1466415 - Bangladesh vs India
2025-02-19 - international - T20 - male - 1471822 - Bahrain vs Indonesia
2025-02-19 - international - ODI - male - 1466414 - New Zealand vs Pakistan
2025-02-19 - club - WPL - female - 1469303 - UP Warriorz vs Delhi Capitals
2025-02-18 - international - ODI - male - 1468884 - United States of America vs Oman
2025-02-18 - international - ODI - male - 1467703 - Ireland vs Zimbabwe
2025-02-18 - club - WPL - female - 1469302 - Gujarat Giants vs Mumbai Indians
2025-02-18 - club - SSH - male - 1444515 - South Australia vs Tasmania
2025-02-18 - club - SSH - male - 1444514 - Queensland vs Western Australia
2025-02-18 - club - SSH - male - 1444513 - New South Wales vs Victoria
2025-02-17 - club - WPL - female - 1469301 - Delhi Capitals vs Royal Challengers Bengaluru
2025-02-16 - international - ODM - male - 1471842 - Tanzania vs Singapore
2025-02-16 - international - ODM - male - 1471841 - Hong Kong vs Italy
2025-02-16 - international - ODI - male - 1468883 - Namibia vs Oman
2025-02-16 - international - ODI - male - 1467702 - Zimbabwe vs Ireland
2025-02-16 - club - WPL - female - 1469300 - UP Warriorz vs Gujarat Giants
2025-02-15 - international - ODM - male - 1471840 - Bahrain vs Italy
2025-02-15 - international - ODM - male - 1471839 - Uganda vs Tanzania
2025-02-15 - club - WPL - female - 1469299 - Mumbai Indians vs Delhi Capitals
2025-02-14 - international - ODI - male - 1469168 - Sri Lanka vs Australia
2025-02-14 - international - ODI - male - 1468882 - United States of America vs Namibia
2025-02-14 - international - ODI - male - 1467701 - Zimbabwe vs Ireland
2025-02-14 - international - ODI - male - 1442223 - Pakistan vs New Zealand
2025-02-14 - club - WPL - female - 1469298 - Gujarat Giants vs Royal Challengers Bengaluru
2025-02-14 - club - MLT - male - 1465856 - Kandy Customs Cricket Club vs Colombo Cricket Club
2025-02-14 - club - MLT - male - 1465855 - Nugegoda Sports Welfare Club vs Burgher Recreation Club
2025-02-14 - club - MLT - male - 1465854 - Kurunegala Youth Cricket Club vs Moors Sports Club
2025-02-14 - club - MLT - male - 1465853 - Nondescripts Cricket Club vs Sinhalese Sports Club
2025-02-14 - club - MLT - male - 1465851 - Bloomfield Cricket and Athletic Club vs Panadura Sports Club
2025-02-14 - club - MLT - male - 1465850 - Ace Capital Cricket Club vs Police Sports Club
2025-02-13 - international - ODM - male - 1471838 - Uganda vs Hong Kong
2025-02-13 - international - ODM - male - 1471837 - Singapore vs Bahrain
2025-02-13 - club - ODC - male - 1444487 - Victoria vs Tasmania
2025-02-13 - club - ODC - male - 1444486 - South Australia vs Western Australia
2025-02-13 - club - ODC - male - 1444485 - Queensland vs New South Wales
2025-02-13 - club - MLT - male - 1465849 - Chilaw Marians Cricket Club vs Ragama Cricket Club
2025-02-12 - international - ODI - male - 1468881 - United States of America vs Oman
2025-02-12 - international - ODI - male - 1459908 - Sri Lanka vs Australia
2025-02-12 - international - ODI - male - 1442222 - South Africa vs Pakistan
2025-02-12 - international - ODI - male - 1439906 - India vs England
2025-02-10 - international - ODM - male - 1471834 - Singapore vs Uganda
2025-02-10 - international - ODM - male - 1471833 - Tanzania vs Bahrain
2025-02-10 - international - ODI - male - 1468880 - Namibia vs Oman
2025-02-10 - international - ODI - male - 1442221 - South Africa vs New Zealand
2025-02-09 - international - ODM - male - 1471832 - Bahrain vs Hong Kong
2025-02-09 - international - ODM - male - 1471831 - Singapore vs Italy
2025-02-09 - international - ODI - male - 1439905 - England vs India
2025-02-09 - club - ILT - male - 1462206 - Desert Vipers vs Dubai Capitals
2025-02-08 - international - ODI - male - 1468879 - United States of America vs Namibia
2025-02-08 - international - ODI - male - 1442220 - New Zealand vs Pakistan
2025-02-08 - club - SSH - male - 1444512 - Western Australia vs South Australia
2025-02-08 - club - SSH - male - 1444511 - Queensland vs New South Wales
2025-02-08 - club - SSH - male - 1444510 - Tasmania vs Victoria
2025-02-08 - club - SAT - male - 1449667 - MI Cape Town vs Sunrisers Eastern Cape
2025-02-07 - international - T20 - female - 1468731 - Nepal vs Thailand
2025-02-07 - international - ODM - male - 1471830 - Tanzania vs Italy
2025-02-07 - international - ODM - male - 1471829 - Uganda vs Bahrain
2025-02-07 - club - MLT - male - 1465848 - Nugegoda Sports Welfare Club vs Kandy Customs Cricket Club
2025-02-07 - club - MLT - male - 1465847 - Colombo Cricket Club vs Kurunegala Youth Cricket Club
2025-02-07 - club - MLT - male - 1465846 - Moors Sports Club vs Nondescripts Cricket Club
2025-02-07 - club - MLT - male - 1465845 - Chilaw Marians Cricket Club vs Badureliya Sports Club
2025-02-07 - club - MLT - male - 1465844 - Negombo Cricket Club vs Panadura Sports Club
2025-02-07 - club - MLT - male - 1465843 - Bloomfield Cricket and Athletic Club vs Ace Capital Cricket Club
2025-02-07 - club - MLT - male - 1465841 - Tamil Union Cricket and Athletic Club vs Sinhalese Sports Club
2025-02-07 - club - ILT - male - 1462205 - Sharjah Warriorz vs Desert Vipers
2025-02-07 - club - BPL - male - 1459582 - Chittagong Kings vs Fortune Barishal
2025-02-06 - international - Test - male - 1467700 - Ireland vs Zimbabwe
2025-02-06 - international - Test - male - 1459907 - Sri Lanka vs Australia
2025-02-06 - international - T20 - female - 1468732 - Thailand vs Netherlands
2025-02-06 - international - ODM - male - 1471828 - Singapore vs Hong Kong
2025-02-06 - international - ODI - male - 1439904 - England vs India
2025-02-06 - club - SAT - male - 1449666 - Paarl Royals vs Sunrisers Eastern Cape
2025-02-06 - club - ILT - male - 1462204 - MI Emirates vs Sharjah Warriorz
2025-02-05 - international - T20 - male - 1470191 - Austria vs Hungary
2025-02-05 - international - T20 - male - 1470190 - Malta vs Austria
2025-02-05 - international - T20 - female - 1468730 - Nepal vs Netherlands
2025-02-05 - club - SAT - male - 1449665 - Sunrisers Eastern Cape vs Joburg Super Kings
2025-02-05 - club - ODC - male - 1444484 - Tasmania vs New South Wales
2025-02-05 - club - ILT - male - 1462203 - Desert Vipers vs Dubai Capitals
2025-02-05 - club - BPL - male - 1459581 - Khulna Tigers vs Chittagong Kings
2025-02-04 - international - T20 - male - 1470189 - Malta vs Hungary
2025-02-04 - international - T20 - male - 1470188 - Hungary vs Austria
2025-02-04 - international - T20 - female - 1468728 - Thailand vs Nepal
2025-02-04 - club - SAT - male - 1449664 - MI Cape Town vs Paarl Royals
2025-02-03 - international - T20 - male - 1470187 - Malta vs Austria
2025-02-03 - international - T20 - male - 1470186 - Hungary vs Malta
2025-02-03 - international - T20 - female - 1468729 - Thailand vs Netherlands
2025-02-03 - club - ILT - male - 1462202 - Desert Vipers vs Dubai Capitals
2025-02-03 - club - BPL - male - 1459580 - Chittagong Kings vs Fortune Barishal
2025-02-03 - club - BPL - male - 1459579 - Rangpur Riders vs Khulna Tigers
2025-02-02 - international - T20 - male - 1439903 - India vs England
2025-02-02 - international - T20 - female - 1468727 - Netherlands vs Nepal
2025-02-02 - club - SSM - male - 1452620 - Canterbury vs Central Districts
2025-02-02 - club - SSM - female - 1452588 - Wellington vs Otago
2025-02-02 - club - SAT - male - 1449663 - MI Cape Town vs Pretoria Capitals
2025-02-02 - club - ILT - male - 1462201 - Dubai Capitals vs Abu Dhabi Knight Riders
2025-02-02 - club - ILT - male - 1462200 - MI Emirates vs Sharjah Warriorz
2025-02-01 - international - T20 - female - 1468725 - Nepal vs Thailand
2025-02-01 - club - SSM - male - 1452619 - Northern Districts vs Canterbury
2025-02-01 - club - SSM - female - 1452587 - Wellington vs Northern Districts
2025-02-01 - club - SAT - male - 1449662 - Durban's Super Giants vs Joburg Super Kings
2025-02-01 - club - SAT - male - 1449661 - Sunrisers Eastern Cape vs Paarl Royals
2025-02-01 - club - ILT - male - 1462199 - Abu Dhabi Knight Riders vs Gulf Giants
2025-02-01 - club - BPL - male - 1459578 - Chittagong Kings vs Fortune Barishal
2025-02-01 - club - BPL - male - 1459577 - Dhaka Capitals vs Khulna Tigers
2025-01-31 - international - T20 - male - 1439902 - India vs England
2025-01-31 - international - T20 - female - 1468726 - Netherlands vs Thailand
2025-01-31 - international - T20 - female - 1468404 - Bangladesh vs West Indies
2025-01-31 - club - SAT - male - 1449660 - MI Cape Town vs Pretoria Capitals
2025-01-31 - club - MLT - male - 1465840 - Kurunegala Youth Cricket Club vs Nugegoda Sports Welfare Club
2025-01-31 - club - MLT - male - 1465839 - Colombo Cricket Club vs Nondescripts Cricket Club
2025-01-31 - club - MLT - male - 1465838 - Tamil Union Cricket and Athletic Club vs Burgher Recreation Club
2025-01-31 - club - MLT - male - 1465836 - Chilaw Marians Cricket Club vs Panadura Sports Club
2025-01-31 - club - MLT - male - 1465835 - Ace Capital Cricket Club vs Negombo Cricket Club
2025-01-31 - club - MLT - male - 1465834 - Colts Cricket Club vs Ragama Cricket Club
2025-01-31 - club - ILT - male - 1462198 - Gulf Giants vs MI Emirates
2025-01-30 - international - Test - female - 1426629 - England vs Australia
2025-01-30 - international - T20 - female - 1468724 - Netherlands vs Nepal
2025-01-30 - club - SSM - female - 1452586 - Wellington vs Northern Districts
2025-01-30 - club - SAT - male - 1449659 - Paarl Royals vs Joburg Super Kings
2025-01-30 - club - MLT - male - 1465833 - Bloomfield Cricket and Athletic Club vs Police Sports Club
2025-01-30 - club - ILT - male - 1462197 - Abu Dhabi Knight Riders vs Sharjah Warriorz
2025-01-30 - club - BPL - male - 1459576 - Chittagong Kings vs Sylhet Strikers
2025-01-30 - club - BPL - male - 1459575 - Khulna Tigers vs Rangpur Riders
2025-01-29 - international - Test - male - 1459906 - Australia vs Sri Lanka
2025-01-29 - international - T20 - female - 1468403 - West Indies vs Bangladesh
2025-01-29 - club - SSM - male - 1452617 - Auckland vs Central Districts
2025-01-29 - club - SSM - female - 1452585 - Auckland vs Central Districts
2025-01-29 - club - SAT - male - 1449658 - Sunrisers Eastern Cape vs MI Cape Town
2025-01-29 - club - ILT - male - 1462196 - Gulf Giants vs Desert Vipers
2025-01-29 - club - BPL - male - 1459574 - Dhaka Capitals vs Fortune Barishal
2025-01-29 - club - BPL - male - 1459573 - Rangpur Riders vs Chittagong Kings
2025-01-28 - international - T20 - male - 1439901 - England vs India
2025-01-28 - club - SSM - male - 1452616 - Canterbury vs Northern Districts
2025-01-28 - club - SSM - female - 1452584 - Canterbury vs Northern Districts
2025-01-28 - club - SAT - male - 1449657 - Joburg Super Kings vs Pretoria Capitals
2025-01-28 - club - ILT - male - 1462195 - Dubai Capitals vs Sharjah Warriorz
2025-01-27 - international - T20 - female - 1468402 - Bangladesh vs West Indies
2025-01-27 - club - SSM - male - 1452615 - Auckland vs Wellington
2025-01-27 - club - SSM - female - 1452583 - Auckland vs Wellington
2025-01-27 - club - SAT - male - 1449656 - Durban's Super Giants vs Paarl Royals
2025-01-27 - club - ILT - male - 1462194 - MI Emirates vs Desert Vipers
2025-01-27 - club - BPL - male - 1459572 - Sylhet Strikers vs Durbar Rajshahi
2025-01-27 - club - BPL - male - 1459571 - Khulna Tigers vs Fortune Barishal
2025-01-27 - club - BBL - male - 1443100 - Sydney Thunder vs Hobart Hurricanes
2025-01-26 - club - SSM - male - 1452614 - Central Districts vs Canterbury
2025-01-26 - club - SSM - female - 1452582 - Canterbury vs Central Districts
2025-01-26 - club - SAT - male - 1449655 - Sunrisers Eastern Cape vs Joburg Super Kings
2025-01-26 - club - MLT - male - 1465828 - Ace Capital Cricket Club vs Chilaw Marians Cricket Club
2025-01-26 - club - ILT - male - 1462193 - Sharjah Warriorz vs Gulf Giants
2025-01-26 - club - ILT - male - 1462192 - Abu Dhabi Knight Riders vs Dubai Capitals
2025-01-26 - club - BPL - male - 1459570 - Durbar Rajshahi vs Rangpur Riders
2025-01-26 - club - BPL - male - 1459569 - Sylhet Strikers vs Fortune Barishal
2025-01-25 - international - Test - male - 1442219 - West Indies vs Pakistan
2025-01-25 - international - T20 - male - 1439900 - England vs India
2025-01-25 - international - T20 - female - 1426628 - Australia vs England
2025-01-25 - club - SSM - male - 1452613 - Otago vs Northern Districts
2025-01-25 - club - SSM - female - 1452581 - Northern Districts vs Otago
2025-01-25 - club - SAT - male - 1449654 - Durban's Super Giants vs MI Cape Town
2025-01-25 - club - SAT - male - 1449653 - Paarl Royals vs Pretoria Capitals
2025-01-25 - club - MLT - male - 1465831 - Kandy Customs Cricket Club vs Tamil Union Cricket and Athletic Club
2025-01-25 - club - ILT - male - 1462191 - MI Emirates vs Gulf Giants
2025-01-25 - club - ILT - male - 1462190 - Sharjah Warriorz vs Desert Vipers
2025-01-24 - international - ODI - female - 1468401 - Bangladesh vs West Indies
2025-01-24 - club - SSM - male - 1452612 - Wellington vs Canterbury
2025-01-24 - club - SSM - female - 1452580 - Canterbury vs Wellington
2025-01-24 - club - SAT - male - 1449652 - Sunrisers Eastern Cape vs Joburg Super Kings
2025-01-24 - club - MLT - male - 1465832 - Nugegoda Sports Welfare Club vs Nondescripts Cricket Club
2025-01-24 - club - MLT - male - 1465830 - Colombo Cricket Club vs Moors Sports Club
2025-01-24 - club - MLT - male - 1465829 - Sinhalese Sports Club vs Burgher Recreation Club
2025-01-24 - club - MLT - male - 1465827 - Badureliya Sports Club vs Colts Cricket Club
2025-01-24 - club - MLT - male - 1465826 - Bloomfield Cricket and Athletic Club vs Negombo Cricket Club
2025-01-24 - club - MLT - male - 1465825 - Police Sports Club vs Ragama Cricket Club
2025-01-24 - club - ILT - male - 1462189 - Abu Dhabi Knight Riders vs MI Emirates
2025-01-24 - club - BBL - male - 1443099 - Sydney Sixers vs Sydney Thunder
2025-01-23 - international - T20 - female - 1426627 - Australia vs England
2025-01-23 - club - SSM - male - 1452611 - Auckland vs Otago
2025-01-23 - club - SSM - female - 1452579 - Auckland vs Otago
2025-01-23 - club - SAT - male - 1449651 - Durban's Super Giants vs Paarl Royals
2025-01-23 - club - ILT - male - 1462188 - Gulf Giants vs Dubai Capitals
2025-01-23 - club - BPL - male - 1459568 - Sylhet Strikers vs Khulna Tigers
2025-01-23 - club - BPL - male - 1459567 - Durbar Rajshahi vs Rangpur Riders
2025-01-22 - international - T20 - male - 1439899 - England vs India
2025-01-22 - club - SSM - male - 1452610 - Canterbury vs Wellington
2025-01-22 - club - SSM - female - 1452578 - Wellington vs Canterbury
2025-01-22 - club - SAT - male - 1449650 - Sunrisers Eastern Cape vs Pretoria Capitals
2025-01-22 - club - ILT - male - 1462187 - Sharjah Warriorz vs Desert Vipers
2025-01-22 - club - BPL - male - 1459566 - Fortune Barishal vs Khulna Tigers
2025-01-22 - club - BPL - male - 1459565 - Chittagong Kings vs Dhaka Capitals
2025-01-22 - club - BBL - male - 1443098 - Sydney Thunder vs Melbourne Stars
2025-01-21 - international - ODI - female - 1468400 - Bangladesh vs West Indies
2025-01-21 - club - SAT - male - 1449649 - MI Cape Town vs Durban's Super Giants
2025-01-21 - club - ILT - male - 1462186 - MI Emirates vs Abu Dhabi Knight Riders
2025-01-21 - club - BBL - male - 1443097 - Hobart Hurricanes vs Sydney Sixers
2025-01-20 - international - T20 - female - 1426626 - Australia vs England
2025-01-20 - club - SSM - male - 1452608 - Auckland vs Wellington
2025-01-20 - club - SSM - female - 1452576 - Wellington vs Auckland
2025-01-20 - club - SAT - male - 1449648 - Joburg Super Kings vs Paarl Royals
2025-01-20 - club - ILT - male - 1462185 - Desert Vipers vs Dubai Capitals
2025-01-20 - club - BPL - male - 1459564 - Chittagong Kings vs Durbar Rajshahi
2025-01-20 - club - BPL - male - 1459563 - Dhaka Capitals vs Sylhet Strikers
2025-01-19 - international - ODI - female - 1468399 - Bangladesh vs West Indies
2025-01-19 - club - SSM - male - 1452607 - Canterbury vs Northern Districts
2025-01-19 - club - SSM - female - 1452575 - Northern Districts vs Canterbury
2025-01-19 - club - SAT - male - 1449647 - Durban's Super Giants vs Sunrisers Eastern Cape
2025-01-19 - club - MLT - male - 1465819 - Chilaw Marians Cricket Club vs Bloomfield Cricket and Athletic Club
2025-01-19 - club - ILT - male - 1462184 - Abu Dhabi Knight Riders vs Gulf Giants
2025-01-19 - club - ILT - male - 1462183 - Sharjah Warriorz vs MI Emirates
2025-01-19 - club - BPL - male - 1459562 - Khulna Tigers vs Durbar Rajshahi
2025-01-19 - club - BPL - male - 1459561 - Chittagong Kings vs Fortune Barishal
2025-01-19 - club - BBL - male - 1443096 - Melbourne Stars vs Hobart Hurricanes
2025-01-18 - club - SSM - male - 1452606 - Wellington vs Otago
2025-01-18 - club - SSM - female - 1452574 - Wellington vs Otago
2025-01-18 - club - SAT - male - 1449646 - Joburg Super Kings vs MI Cape Town
2025-01-18 - club - SAT - male - 1449645 - Pretoria Capitals vs Paarl Royals
2025-01-18 - club - MLT - male - 1465823 - Moors Sports Club vs Nugegoda Sports Welfare Club
2025-01-18 - club - ILT - male - 1462182 - Dubai Capitals vs Gulf Giants
2025-01-18 - club - ILT - male - 1462181 - Desert Vipers vs Abu Dhabi Knight Riders
2025-01-18 - club - BBL - male - 1443095 - Adelaide Strikers vs Perth Scorchers
2025-01-18 - club - BBL - male - 1443094 - Brisbane Heat vs Melbourne Renegades
2025-01-17 - international - Test - male - 1442218 - Pakistan vs West Indies
2025-01-17 - international - ODI - female - 1426625 - Australia vs England
2025-01-17 - club - SSM - male - 1452605 - Central Districts vs Canterbury
2025-01-17 - club - SSM - female - 1452573 - Canterbury vs Central Districts
2025-01-17 - club - SAT - male - 1449644 - Sunrisers Eastern Cape vs Durban's Super Giants
2025-01-17 - club - MLT - male - 1465824 - Kurunegala Youth Cricket Club vs Tamil Union Cricket and Athletic Club
2025-01-17 - club - MLT - male - 1465822 - Kandy Customs Cricket Club vs Burgher Recreation Club
2025-01-17 - club - MLT - male - 1465820 - Colts Cricket Club vs Panadura Sports Club
2025-01-17 - club - MLT - male - 1465818 - Ragama Cricket Club vs Badureliya Sports Club
2025-01-17 - club - MLT - male - 1465817 - Negombo Cricket Club vs Police Sports Club
2025-01-17 - club - ILT - male - 1462180 - Dubai Capitals vs Sharjah Warriorz
2025-01-17 - club - BPL - male - 1459560 - Rangpur Riders vs Chittagong Kings
2025-01-17 - club - BPL - male - 1459559 - Durbar Rajshahi vs Sylhet Strikers
2025-01-17 - club - BBL - male - 1443093 - Sydney Thunder vs Sydney Sixers
2025-01-16 - club - SSM - male - 1452604 - Northern Districts vs Otago
2025-01-16 - club - SSM - female - 1452572 - Otago vs Northern Districts
2025-01-16 - club - SAT - male - 1449643 - Pretoria Capitals vs Joburg Super Kings
2025-01-16 - club - ILT - male - 1462179 - MI Emirates vs Desert Vipers
2025-01-16 - club - BPL - male - 1459558 - Chittagong Kings vs Khulna Tigers
2025-01-16 - club - BPL - male - 1459557 - Dhaka Capitals vs Fortune Barishal
2025-01-16 - club - BBL - male - 1443092 - Brisbane Heat vs Hobart Hurricanes
2025-01-15 - international - ODI - female - 1459899 - India vs Ireland
2025-01-15 - club - SSM - male - 1452603 - Auckland vs Central Districts
2025-01-15 - club - SSM - female - 1452571 - Auckland vs Central Districts
2025-01-15 - club - SAT - male - 1449642 - MI Cape Town vs Paarl Royals
2025-01-15 - club - ILT - male - 1462178 - Abu Dhabi Knight Riders vs Sharjah Warriorz
2025-01-15 - club - BBL - male - 1443091 - Adelaide Strikers vs Sydney Sixers
2025-01-14 - international - ODI - female - 1426624 - Australia vs England
2025-01-14 - club - SSM - male - 1452602 - Otago vs Wellington
2025-01-14 - club - SSM - female - 1452570 - Wellington vs Otago
2025-01-14 - club - SAT - male - 1449641 - Joburg Super Kings vs Durban's Super Giants
2025-01-14 - club - SAT - male - 1449640 - Sunrisers Eastern Cape vs Pretoria Capitals
2025-01-14 - club - ILT - male - 1462177 - Gulf Giants vs Desert Vipers
2025-01-14 - club - BBL - male - 1443090 - Melbourne Renegades vs Hobart Hurricanes
2025-01-13 - club - SSM - male - 1452601 - Auckland vs Northern Districts
2025-01-13 - club - SSM - female - 1452569 - Northern Districts vs Auckland
2025-01-13 - club - SAT - male - 1449639 - MI Cape Town vs Paarl Royals
2025-01-13 - club - ILT - male - 1462176 - MI Emirates vs Dubai Capitals
2025-01-13 - club - BPL - male - 1459556 - Rangpur Riders vs Khulna Tigers
2025-01-13 - club - BPL - male - 1459555 - Chittagong Kings vs Sylhet Strikers
2025-01-13 - club - BBL - male - 1443089 - Sydney Thunder vs Perth Scorchers
2025-01-12 - international - ODI - female - 1459898 - India vs Ireland
2025-01-12 - international - ODI - female - 1426623 - England vs Australia
2025-01-12 - club - SSM - male - 1452600 - Central Districts vs Otago
2025-01-12 - club - SSM - female - 1452568 - Central Districts vs Otago
2025-01-12 - club - ILT - male - 1462175 - Gulf Giants vs Sharjah Warriorz
2025-01-12 - club - ILT - male - 1462174 - Abu Dhabi Knight Riders vs Desert Vipers
2025-01-12 - club - BPL - male - 1459554 - Dhaka Capitals vs Durbar Rajshahi
2025-01-12 - club - BPL - male - 1459553 - Sylhet Strikers vs Khulna Tigers
2025-01-12 - club - BBL - male - 1443088 - Melbourne Stars vs Melbourne Renegades
2025-01-11 - international - ODI - male - 1443548 - Sri Lanka vs New Zealand
2025-01-11 - club - SAT - male - 1449637 - MI Cape Town vs Joburg Super Kings
2025-01-11 - club - SAT - male - 1449636 - Sunrisers Eastern Cape vs Paarl Royals
2025-01-11 - club - ILT - male - 1462173 - Dubai Capitals vs MI Emirates
2025-01-11 - club - BBL - male - 1443087 - Adelaide Strikers vs Brisbane Heat
2025-01-11 - club - BBL - male - 1443086 - Sydney Sixers vs Perth Scorchers
2025-01-10 - international - ODI - female - 1459897 - Ireland vs India
2025-01-10 - club - SSM - male - 1452599 - Canterbury vs Auckland
2025-01-10 - club - SSM - female - 1452567 - Auckland vs Canterbury
2025-01-10 - club - SAT - male - 1449635 - Durban's Super Giants vs Pretoria Capitals
2025-01-10 - club - MLT - male - 1465816 - Nondescripts Cricket Club vs Tamil Union Cricket and Athletic Club
2025-01-10 - club - MLT - male - 1465815 - Burgher Recreation Club vs Kurunegala Youth Cricket Club
2025-01-10 - club - MLT - male - 1465814 - Nugegoda Sports Welfare Club vs Colombo Cricket Club
2025-01-10 - club - MLT - male - 1465813 - Kandy Customs Cricket Club vs Sinhalese Sports Club
2025-01-10 - club - MLT - male - 1465812 - Colts Cricket Club vs Ace Capital Cricket Club
2025-01-10 - club - MLT - male - 1465811 - Ragama Cricket Club vs Panadura Sports Club
2025-01-10 - club - MLT - male - 1465810 - Chilaw Marians Cricket Club vs Negombo Cricket Club
2025-01-10 - club - MLT - male - 1465809 - Badureliya Sports Club vs Police Sports Club
2025-01-10 - club - BPL - male - 1459552 - Dhaka Capitals vs Sylhet Strikers
2025-01-10 - club - BPL - male - 1459551 - Durbar Rajshahi vs Khulna Tigers
2025-01-10 - club - BBL - male - 1443085 - Sydney Thunder vs Hobart Hurricanes
2025-01-09 - club - SSM - male - 1452598 - Wellington vs Central Districts
2025-01-09 - club - SSM - female - 1452566 - Central Districts vs Wellington
2025-01-09 - club - SAT - male - 1449634 - MI Cape Town vs Sunrisers Eastern Cape
2025-01-09 - club - BPL - male - 1459550 - Dhaka Capitals vs Chittagong Kings
2025-01-09 - club - BPL - male - 1459549 - Fortune Barishal vs Rangpur Riders
2025-01-09 - club - BBL - male - 1443084 - Melbourne Stars vs Sydney Sixers
2025-01-08 - international - ODI - male - 1443547 - New Zealand vs Sri Lanka
2025-01-07 - club - SSM - male - 1452597 - Canterbury vs Otago
2025-01-07 - club - SSM - female - 1452565 - Otago vs Canterbury
2025-01-07 - club - BPL - male - 1459548 - Sylhet Strikers vs Fortune Barishal
2025-01-07 - club - BPL - male - 1459547 - Dhaka Capitals vs Rangpur Riders
2025-01-07 - club - BBL - male - 1443082 - Perth Scorchers vs Melbourne Renegades
2025-01-06 - club - SSM - male - 1452596 - Central Districts vs Northern Districts
2025-01-06 - club - SSM - female - 1452564 - Central Districts vs Northern Districts
2025-01-06 - club - BPL - male - 1459546 - Durbar Rajshahi vs Fortune Barishal
2025-01-06 - club - BPL - male - 1459545 - Sylhet Strikers vs Rangpur Riders
2025-01-06 - club - BBL - male - 1443081 - Sydney Thunder vs Brisbane Heat
2025-01-05 - international - ODI - male - 1443546 - Sri Lanka vs New Zealand
2025-01-05 - club - BBL - male - 1443080 - Adelaide Strikers vs Hobart Hurricanes
2025-01-04 - club - SSM - male - 1452595 - Wellington vs Central Districts
2025-01-04 - club - SSM - female - 1452563 - Wellington vs Central Districts
2025-01-04 - club - BBL - male - 1443079 - Melbourne Renegades vs Melbourne Stars
2025-01-03 - international - Test - male - 1432218 - South Africa vs Pakistan
2025-01-03 - international - Test - male - 1426559 - India vs Australia
2025-01-03 - club - SSM - male - 1452594 - Auckland vs Canterbury
2025-01-03 - club - SSM - female - 1452562 - Auckland vs Canterbury
2025-01-03 - club - MLT - male - 1465808 - Moors Sports Club vs Tamil Union Cricket and Athletic Club
2025-01-03 - club - MLT - male - 1465807 - Burgher Recreation Club vs Nondescripts Cricket Club
2025-01-03 - club - MLT - male - 1465806 - Kandy Customs Cricket Club vs Kurunegala Youth Cricket Club
2025-01-03 - club - MLT - male - 1465805 - Nugegoda Sports Welfare Club vs Sinhalese Sports Club
2025-01-03 - club - MLT - male - 1465804 - Colts Cricket Club vs Bloomfield Cricket and Athletic Club
2025-01-03 - club - MLT - male - 1465803 - Ace Capital Cricket Club vs Ragama Cricket Club
2025-01-03 - club - MLT - male - 1465802 - Badureliya Sports Club vs Panadura Sports Club
2025-01-03 - club - MLT - male - 1465801 - Chilaw Marians Cricket Club vs Police Sports Club
2025-01-03 - club - BPL - male - 1459544 - Khulna Tigers vs Dhaka Capitals
2025-01-03 - club - BPL - male - 1459543 - Chittagong Kings vs Durbar Rajshahi
2025-01-03 - club - BBL - male - 1443078 - Perth Scorchers vs Sydney Thunder
2025-01-02 - international - T20 - male - 1443545 - Sri Lanka vs New Zealand
2025-01-02 - club - BPL - male - 1459542 - Fortune Barishal vs Rangpur Riders
2025-01-02 - club - BPL - male - 1459541 - Dhaka Capitals vs Durbar Rajshahi
2025-01-02 - club - BBL - male - 1443076 - Melbourne Renegades vs Adelaide Strikers
2025-01-01 - club - SSM - male - 1452593 - Wellington vs Northern Districts
2025-01-01 - club - SSM - female - 1452561 - Wellington vs Northern Districts
2025-01-01 - club - BBL - male - 1443075 - Brisbane Heat vs Melbourne Stars
2025-01-01 - club - BBL - male - 1443074 - Hobart Hurricanes vs Sydney Sixers
